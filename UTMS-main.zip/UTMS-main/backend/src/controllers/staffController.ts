import { Response, NextFunction } from 'express'
import { AuthenticatedRequest } from '../middleware/auth.js'
import { staffService } from '../services/staffService.js'
import fs from 'fs'

export const staffController = {

  // RV.1 — List all applications (with optional ?status= filter)
  async listApplications(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const statusParam = req.query.status as string | undefined
      const statusFilter = statusParam ? statusParam.split(',') : undefined
      const apps = await staffService.getAllApplications(statusFilter)
      res.json({ success: true, data: apps })
    } catch (err) { next(err) }
  },

  // RV.1 — Get single application (with applicant info)
  async getApplication(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const app = await staffService.getApplicationById(req.params.id)
      res.json({ success: true, data: app })
    } catch (err) { next(err) }
  },

  // RV.1 — Update application status
  async updateStatus(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const { status, note } = req.body
      if (!status) return res.status(400).json({ success: false, message: 'status is required.' })
      const updated = await staffService.updateStatus(req.user!.userId, req.params.id, status, note)
      res.json({ success: true, data: updated })
    } catch (err) { next(err) }
  },

  // VD.1 — List documents for an application
  async listDocuments(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const docs = await staffService.getDocumentsByApplication(req.params.id)
      res.json({ success: true, data: docs })
    } catch (err) { next(err) }
  },

  // VD.1 — Verify a document
  async verifyDocument(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const doc = await staffService.verifyDocument(req.user!.userId, req.params.docId)
      res.json({ success: true, data: doc })
    } catch (err) { next(err) }
  },

  // VD.1 — Reject a document
  async rejectDocument(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const { reason } = req.body
      const doc = await staffService.rejectDocument(req.user!.userId, req.params.docId, reason)
      res.json({ success: true, data: doc })
    } catch (err) { next(err) }
  },

  // VD.1 — Download a document
  async downloadDocument(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const { filePath, fileName, mimeType } = await staffService.getDocumentFilePath(req.params.docId)
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ success: false, message: 'File not found on server.' })
      }
      res.setHeader('Content-Type', mimeType)
      res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(fileName)}"`)
      fs.createReadStream(filePath).pipe(res)
    } catch (err) { next(err) }
  },
}
