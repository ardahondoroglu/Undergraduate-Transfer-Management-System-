import { Response, NextFunction } from 'express'
import { notificationService } from '../services/notificationService.js'
import type { AuthenticatedRequest } from '../middleware/auth.js'

export const notificationController = {
  async getAll(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const notifs = await notificationService.getAll(req.user!.userId)
      res.json({ success: true, data: notifs })
    } catch (err) { next(err) }
  },

  async markAsRead(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const notif = await notificationService.markAsRead(req.user!.userId, req.params.id)
      res.json({ success: true, data: notif })
    } catch (err) { next(err) }
  },

  async markAllAsRead(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const result = await notificationService.markAllAsRead(req.user!.userId)
      res.json({ success: true, data: result })
    } catch (err) { next(err) }
  },
}
