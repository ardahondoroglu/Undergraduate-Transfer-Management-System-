import { Response, NextFunction } from 'express'
import { z } from 'zod'
import path from 'path'
import fs from 'fs'
import { documentService } from '../services/documentService.js'
import type { AuthenticatedRequest } from '../middleware/auth.js'

const DOC_TYPES = ['TRANSCRIPT', 'COURSE_DESCRIPTION', 'STUDENT_ID', 'ENGLISH_CERTIFICATE', 'PLACEMENT_RESULT', 'OTHER'] as const
const typeSchema = z.object({ type: z.enum(DOC_TYPES) })

export const documentController = {
  async upload(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded.' })
      const { type } = typeSchema.parse(req.body)

      const doc = await documentService.upload(req.user!.userId, req.params.applicationId, {
        type,
        fileName:  req.file.originalname,
        filePath:  req.file.path,
        fileSize:  req.file.size,
        mimeType:  req.file.mimetype,
      })
      res.status(201).json({ success: true, data: doc })
    } catch (err) { next(err) }
  },

  async getByApplication(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const docs = await documentService.getByApplication(req.user!.userId, req.params.applicationId)
      res.json({ success: true, data: docs })
    } catch (err) { next(err) }
  },

  async delete(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const result = await documentService.delete(req.user!.userId, req.params.id)
      res.json({ success: true, data: result })
    } catch (err) { next(err) }
  },

  async download(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const { filePath, fileName, mimeType } = await documentService.getFilePath(req.user!.userId, req.params.id)
      if (!fs.existsSync(filePath)) return res.status(404).json({ success: false, message: 'File not found on server.' })
      res.setHeader('Content-Type', mimeType)
      res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(fileName)}"`)
      res.sendFile(path.resolve(filePath))
    } catch (err) { next(err) }
  },
}
