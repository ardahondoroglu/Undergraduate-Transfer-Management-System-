import { Response, NextFunction } from 'express'
import { AuthenticatedRequest } from '../middleware/auth.js'
import { facultyBoardService } from '../services/facultyBoardService.js'

export const facultyBoardController = {

  // FB.1 — list applications
  async listApplications(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const statusParam = req.query.status as string | undefined
      const statusFilter = statusParam ? statusParam.split(',') : undefined
      const apps = await facultyBoardService.getAllApplications(statusFilter)
      res.json({ success: true, data: apps })
    } catch (err) { next(err) }
  },

  async getApplication(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const app = await facultyBoardService.getApplicationById(req.params.id)
      res.json({ success: true, data: app })
    } catch (err) { next(err) }
  },

  // FB.2 — approve / reject
  async updateStatus(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const { status, note } = req.body
      if (!status) return res.status(400).json({ success: false, message: 'status is required.' })
      const updated = await facultyBoardService.updateStatus(req.user!.userId, req.params.id, status, note)
      res.json({ success: true, data: updated })
    } catch (err) { next(err) }
  },
}
