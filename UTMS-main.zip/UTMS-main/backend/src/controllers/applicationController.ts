import { Response, NextFunction } from 'express'
import { z } from 'zod'
import { applicationService } from '../services/applicationService.js'
import type { AuthenticatedRequest } from '../middleware/auth.js'

const createSchema = z.object({
  transferType:       z.enum(['INTERNAL', 'EXTERNAL', 'DOUBLE_MAJOR', 'MINOR']),
  previousUniversity: z.string().min(2).max(200),
  currentProgram:     z.string().min(2).max(200),
  targetProgram:      z.string().min(2).max(200),
  currentGpa:         z.string().regex(/^\d+(\.\d{1,2})?$/).refine(v => parseFloat(v) >= 0 && parseFloat(v) <= 4, 'GPA must be between 0 and 4'),
  currentSemester:    z.number().int().min(1).max(12),
  targetSemester:     z.number().int().min(1).max(12),
  academicYear:       z.string().regex(/^\d{4}-\d{4}$/, 'Format: 2024-2025'),
  reasonForTransfer:  z.string().max(1000).optional(),
})

export const applicationController = {
  async create(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const body = createSchema.parse(req.body)
      const app = await applicationService.create(req.user!.userId, body)
      res.status(201).json({ success: true, data: app })
    } catch (err) { next(err) }
  },

  async getAll(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const apps = await applicationService.getAll(req.user!.userId)
      res.json({ success: true, data: apps })
    } catch (err) { next(err) }
  },

  async getById(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const app = await applicationService.getById(req.user!.userId, req.params.id)
      res.json({ success: true, data: app })
    } catch (err) { next(err) }
  },

  async update(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const body = createSchema.partial().parse(req.body)
      const app = await applicationService.update(req.user!.userId, req.params.id, body)
      res.json({ success: true, data: app })
    } catch (err) { next(err) }
  },

  async submit(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const app = await applicationService.submit(req.user!.userId, req.params.id)
      res.json({ success: true, data: app })
    } catch (err) { next(err) }
  },

  async withdraw(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const app = await applicationService.withdraw(req.user!.userId, req.params.id)
      res.json({ success: true, data: app })
    } catch (err) { next(err) }
  },
}
