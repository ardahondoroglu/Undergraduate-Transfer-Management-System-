import { Response, NextFunction } from 'express'
import { AuthenticatedRequest } from '../middleware/auth.js'
import { ydyoService } from '../services/ydyoService.js'

export const ydyoController = {

  // SFL.01 — list apps pending language check
  async listApplications(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const apps = await ydyoService.getAllApplications()
      res.json({ success: true, data: apps })
    } catch (err) { next(err) }
  },

  async getApplication(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const app = await ydyoService.getApplicationById(req.params.id)
      res.json({ success: true, data: app })
    } catch (err) { next(err) }
  },

  // SFL.02 — evaluate English proficiency (APPROVED / EXAM_REQUIRED / NOT_MET)
  async evaluate(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const { languageStatus, notes } = req.body
      if (!languageStatus) {
        return res.status(400).json({ success: false, message: 'languageStatus is required.' })
      }
      const updated = await ydyoService.evaluate(
        req.user!.userId,
        req.params.id,
        languageStatus,
        notes,
      )
      res.json({ success: true, data: updated })
    } catch (err) { next(err) }
  },

  // SFL.03 — record exam result
  async recordExamResult(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const { passed, score, notes } = req.body
      if (typeof passed !== 'boolean') {
        return res.status(400).json({ success: false, message: 'passed (boolean) is required.' })
      }
      const updated = await ydyoService.recordExamResult(
        req.user!.userId,
        req.params.id,
        passed,
        score,
        notes,
      )
      res.json({ success: true, data: updated })
    } catch (err) { next(err) }
  },
}
