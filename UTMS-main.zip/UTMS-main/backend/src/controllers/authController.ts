import { Request, Response, NextFunction } from 'express'
import { z } from 'zod'
import { authService } from '../services/authService.js'
import type { AuthenticatedRequest } from '../middleware/auth.js'

const registerSchema = z.object({
  firstName:     z.string().min(2).max(50),
  lastName:      z.string().min(2).max(50),
  email:         z.string().email(),
  studentNumber: z.string().min(6),
  password:      z.string().min(8).regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/, 'Must include uppercase, lowercase and number'),
})

const loginSchema = z.object({
  studentId: z.string().min(3),
  password:  z.string().min(1),
})

const forgotSchema = z.object({ email: z.string().email() })

const resetSchema = z.object({
  token:       z.string().min(1),
  newPassword: z.string().min(8).regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/, 'Must include uppercase, lowercase and number'),
})

export const authController = {
  async register(req: Request, res: Response, next: NextFunction) {
    try {
      console.log('[Register] attempt:', req.body?.email)
      const body = registerSchema.parse(req.body)
      const result = await authService.register(body)
      console.log('[Register] success:', body.email)
      res.status(201).json({ success: true, data: result, message: result.message })
    } catch (err) { next(err) }
  },

  async verifyEmail(req: Request, res: Response, next: NextFunction) {
    try {
      const token = String(req.query.token || '')
      if (!token) return res.status(400).json({ success: false, message: 'Token required' })
      const result = await authService.verifyEmail(token)
      res.json({ success: true, data: result })
    } catch (err) { next(err) }
  },

  async login(req: Request, res: Response, next: NextFunction) {
    try {
      const { studentId, password } = loginSchema.parse(req.body)
      const result = await authService.login(studentId, password, req.ip)
      res.json({ success: true, data: result })
    } catch (err) { next(err) }
  },

  async forgotPassword(req: Request, res: Response, next: NextFunction) {
    try {
      const { email } = forgotSchema.parse(req.body)
      const result = await authService.forgotPassword(email)
      res.json({ success: true, data: result, message: result.message })
    } catch (err) { next(err) }
  },

  async resetPassword(req: Request, res: Response, next: NextFunction) {
    try {
      const { token, newPassword } = resetSchema.parse(req.body)
      const result = await authService.resetPassword(token, newPassword)
      res.json({ success: true, data: result })
    } catch (err) { next(err) }
  },

  async getMe(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const user = await authService.getMe(req.user!.userId)
      res.json({ success: true, data: user })
    } catch (err) { next(err) }
  },

  logout(_req: Request, res: Response) {
    res.json({ success: true, message: 'Logged out.' })
  },
}
