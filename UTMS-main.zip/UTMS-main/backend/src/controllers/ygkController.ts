import { Response, NextFunction } from 'express'
import { AuthenticatedRequest } from '../middleware/auth.js'
import { ygkService } from '../services/ygkService.js'

export const ygkController = {

  // YE.1 / RK.1 / FF.1 — list applications in YGK scope
  async listApplications(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const statusParam = req.query.status as string | undefined
      const statusFilter = statusParam ? statusParam.split(',') : undefined
      const apps = await ygkService.getAllApplications(statusFilter)
      res.json({ success: true, data: apps })
    } catch (err) { next(err) }
  },

  async getApplication(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const app = await ygkService.getApplicationById(req.params.id)
      res.json({ success: true, data: app })
    } catch (err) { next(err) }
  },

  // YE.1, RK.1, FF.1 — status transitions
  async updateStatus(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const { status, note, evaluationScore, evaluationNotes } = req.body
      if (!status) return res.status(400).json({ success: false, message: 'status is required.' })
      const updated = await ygkService.updateStatus(
        req.user!.userId,
        req.params.id,
        status,
        note,
        evaluationScore != null ? Number(evaluationScore) : undefined,
        evaluationNotes,
      )
      res.json({ success: true, data: updated })
    } catch (err) { next(err) }
  },

  // CE.1 — course equivalencies
  async listEquivalencies(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const eqs = await ygkService.getCourseEquivalencies(req.params.id)
      res.json({ success: true, data: eqs })
    } catch (err) { next(err) }
  },

  async createEquivalency(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const eq = await ygkService.createCourseEquivalency(req.user!.userId, req.params.id, req.body)
      res.status(201).json({ success: true, data: eq })
    } catch (err) { next(err) }
  },

  async updateEquivalency(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const eq = await ygkService.updateCourseEquivalency(req.user!.userId, req.params.eqId, req.body)
      res.json({ success: true, data: eq })
    } catch (err) { next(err) }
  },

  async deleteEquivalency(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      await ygkService.deleteCourseEquivalency(req.user!.userId, req.params.eqId)
      res.json({ success: true, message: 'Deleted.' })
    } catch (err) { next(err) }
  },

  // RK.1 — ranked list
  async getRanking(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const rows = await ygkService.getRankedApplications()
      res.json({ success: true, data: rows })
    } catch (err) { next(err) }
  },

  // RK.1 — update manual ranking position
  async updateRanking(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const { rankingPosition, rankingJustification } = req.body
      if (rankingPosition == null) {
        return res.status(400).json({ success: false, message: 'rankingPosition is required.' })
      }
      const updated = await ygkService.updateRanking(
        req.user!.userId,
        req.params.id,
        Number(rankingPosition),
        rankingJustification,
      )
      res.json({ success: true, data: updated })
    } catch (err) { next(err) }
  },
}
