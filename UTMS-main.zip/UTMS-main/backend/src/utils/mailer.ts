const BREVO_API_KEY  = process.env.BREVO_API_KEY  || ''
const FROM_EMAIL     = process.env.EMAIL_FROM_ADDRESS || 'vedatdemir1907fb@gmail.com'
const FROM_NAME      = process.env.EMAIL_FROM_NAME    || 'UTMS'
const FRONTEND_URL   = process.env.FRONTEND_URL       || 'http://localhost:5173'

async function sendEmail(to: string, subject: string, htmlContent: string) {
  const res = await fetch('https://api.brevo.com/v3/smtp/email', {
    method:  'POST',
    headers: {
      'api-key':      BREVO_API_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      sender:      { name: FROM_NAME, email: FROM_EMAIL },
      to:          [{ email: to }],
      subject,
      htmlContent,
    }),
  })

  if (!res.ok) {
    const text = await res.text()
    throw new Error(`Brevo API error ${res.status}: ${text}`)
  }
}

export async function sendVerificationEmail(to: string, token: string) {
  const url = `${FRONTEND_URL}/verify-email?token=${token}`
  await sendEmail(
    to,
    'UTMS - E-posta adresinizi doğrulayın',
    `<div style="font-family:sans-serif;max-width:480px;margin:auto">
      <h2>E-posta Doğrulama</h2>
      <p>UTMS hesabınızı etkinleştirmek için aşağıdaki bağlantıya tıklayın. Bağlantı 30 dakika geçerlidir.</p>
      <a href="${url}" style="display:inline-block;padding:12px 24px;background:#1d4ed8;color:#fff;border-radius:6px;text-decoration:none;font-weight:600">
        E-postamı Doğrula
      </a>
      <p style="color:#6b7280;font-size:12px;margin-top:24px">Bu maili siz talep etmediyseniz görmezden gelebilirsiniz.</p>
    </div>`
  )
}

export async function sendPasswordResetEmail(to: string, token: string) {
  const url = `${FRONTEND_URL}/reset-password?token=${token}`
  await sendEmail(
    to,
    'UTMS - Şifre Sıfırlama',
    `<div style="font-family:sans-serif;max-width:480px;margin:auto">
      <h2>Şifre Sıfırlama</h2>
      <p>Şifrenizi sıfırlamak için aşağıdaki bağlantıya tıklayın. Bağlantı 60 dakika geçerlidir.</p>
      <a href="${url}" style="display:inline-block;padding:12px 24px;background:#1d4ed8;color:#fff;border-radius:6px;text-decoration:none;font-weight:600">
        Şifremi Sıfırla
      </a>
      <p style="color:#6b7280;font-size:12px;margin-top:24px">Bu maili siz talep etmediyseniz görmezden gelebilirsiniz.</p>
    </div>`
  )
}
