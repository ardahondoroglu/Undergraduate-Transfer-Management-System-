import jwt from 'jsonwebtoken'
import type { JwtPayload } from '../middleware/auth.js'

export function signToken(payload: JwtPayload): string {
  return jwt.sign(payload, process.env.JWT_SECRET!, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  } as jwt.SignOptions)
}
