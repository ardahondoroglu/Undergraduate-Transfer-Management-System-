import { db } from '../db/index.js'
import { auditLogs } from '../db/schema/index.js'

interface LogParams {
  userId?: string
  action: string
  entityType: string
  entityId?: string
  oldValue?: unknown
  newValue?: unknown
  ipAddress?: string
}

export async function writeAuditLog(params: LogParams) {
  try {
    await db.insert(auditLogs).values({
      userId:     params.userId,
      action:     params.action,
      entityType: params.entityType,
      entityId:   params.entityId,
      oldValue:   params.oldValue ? JSON.stringify(params.oldValue) : undefined,
      newValue:   params.newValue ? JSON.stringify(params.newValue) : undefined,
      ipAddress:  params.ipAddress,
    })
  } catch (err) {
    console.error('[AuditLog] Failed:', err)
  }
}
