import { Router } from 'express'
import { authenticate, authorize } from '../middleware/auth.js'
import { ydyoController } from '../controllers/ydyoController.js'

const router = Router()

router.use(authenticate, authorize('YDYO'))

// SFL.01 — list / get apps pending language check
router.get('/applications',               ydyoController.listApplications)
router.get('/applications/:id',           ydyoController.getApplication)

// SFL.02 — evaluate English proficiency
router.patch('/applications/:id/evaluate',     ydyoController.evaluate)

// SFL.03 — record exam result
router.patch('/applications/:id/exam-result',  ydyoController.recordExamResult)

export default router
