import { Router } from 'express'
import authRoutes from './auth.js'
import applicationRoutes from './applications.js'
import documentRoutes from './documents.js'
import notificationRoutes from './notifications.js'
import staffRoutes from './staff.js'
import ygkRoutes from './ygk.js'
import ydyoRoutes from './ydyo.js'
import facultyBoardRoutes from './facultyBoard.js'

const router = Router()

router.use('/auth',          authRoutes)
router.use('/applications',  applicationRoutes)
router.use('/notifications', notificationRoutes)
router.use('/staff',         staffRoutes)
router.use('/ygk',           ygkRoutes)
router.use('/ydyo',          ydyoRoutes)
router.use('/faculty',       facultyBoardRoutes)
router.use('/',              documentRoutes)

export default router
