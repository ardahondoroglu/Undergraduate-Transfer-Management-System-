import { Router } from 'express'
import { documentController } from '../controllers/documentController.js'
import { authenticate } from '../middleware/auth.js'
import { upload } from '../utils/upload.js'

const router = Router()
router.use(authenticate)

// Documents under an application
router.post('/applications/:applicationId/documents', upload.single('file'), documentController.upload)
router.get('/applications/:applicationId/documents', documentController.getByApplication)

// Individual document actions
router.delete('/documents/:id', documentController.delete)
router.get('/documents/:id/download', documentController.download)

export default router
