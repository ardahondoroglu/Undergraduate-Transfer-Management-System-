import { Router } from 'express'
import { authController } from '../controllers/authController.js'
import { authenticate } from '../middleware/auth.js'

const router = Router()

router.post('/register',        authController.register)
router.get('/verify-email',     authController.verifyEmail)
router.post('/login',           authController.login)
router.post('/forgot-password', authController.forgotPassword)
router.post('/reset-password',  authController.resetPassword)
router.post('/logout',          authenticate, authController.logout)
router.get('/me',               authenticate, authController.getMe)

export default router
