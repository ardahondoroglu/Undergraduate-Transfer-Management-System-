import { Router } from 'express'
import { authenticate, authorize } from '../middleware/auth.js'
import { staffController } from '../controllers/staffController.js'

const router = Router()

// All routes require OIDB_STAFF role
router.use(authenticate, authorize('OIDB_STAFF'))

// RV.1 — Application review
router.get('/applications',           staffController.listApplications)
router.get('/applications/:id',       staffController.getApplication)
router.patch('/applications/:id/status', staffController.updateStatus)

// VD.1 — Document verification
router.get('/applications/:id/documents',  staffController.listDocuments)
router.patch('/documents/:docId/verify',   staffController.verifyDocument)
router.patch('/documents/:docId/reject',   staffController.rejectDocument)
router.get('/documents/:docId/download',   staffController.downloadDocument)

export default router
