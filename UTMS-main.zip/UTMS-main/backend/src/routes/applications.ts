import { Router } from 'express'
import { applicationController } from '../controllers/applicationController.js'
import { authenticate } from '../middleware/auth.js'

const router = Router()

router.use(authenticate)

router.post('/',           applicationController.create)
router.get('/',            applicationController.getAll)
router.get('/:id',         applicationController.getById)
router.patch('/:id',       applicationController.update)
router.post('/:id/submit', applicationController.submit)
router.post('/:id/withdraw', applicationController.withdraw)

export default router
