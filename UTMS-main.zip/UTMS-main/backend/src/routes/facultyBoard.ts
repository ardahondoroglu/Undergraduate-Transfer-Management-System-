import { Router } from 'express'
import { authenticate, authorize } from '../middleware/auth.js'
import { facultyBoardController } from '../controllers/facultyBoardController.js'

const router = Router()

router.use(authenticate, authorize('FACULTY_BOARD'))

// FB.1 — list / get applications forwarded to faculty
router.get('/applications',              facultyBoardController.listApplications)
router.get('/applications/:id',          facultyBoardController.getApplication)

// FB.2 — approve or reject
router.patch('/applications/:id/status', facultyBoardController.updateStatus)

export default router
