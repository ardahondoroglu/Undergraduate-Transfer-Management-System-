import { Router } from 'express'
import { authenticate, authorize } from '../middleware/auth.js'
import { ygkController } from '../controllers/ygkController.js'

const router = Router()

router.use(authenticate, authorize('YGK'))

// Application review (YE.1, RK.1, FF.1)
router.get('/applications',                        ygkController.listApplications)
router.get('/applications/:id',                    ygkController.getApplication)
router.patch('/applications/:id/status',           ygkController.updateStatus)

// Course equivalencies (CE.1)
router.get('/applications/:id/equivalencies',      ygkController.listEquivalencies)
router.post('/applications/:id/equivalencies',     ygkController.createEquivalency)
router.patch('/equivalencies/:eqId',               ygkController.updateEquivalency)
router.delete('/equivalencies/:eqId',              ygkController.deleteEquivalency)

// Ranking view (RK.1)
router.get('/ranking',                             ygkController.getRanking)

// RK.1 — update manual ranking position
router.patch('/applications/:id/ranking',          ygkController.updateRanking)

export default router
