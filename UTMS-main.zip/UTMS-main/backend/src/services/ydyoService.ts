import { eq, inArray, desc } from 'drizzle-orm'
import { db } from '../db/index.js'
import { applications, users } from '../db/schema/index.js'
import { AppError } from '../middleware/errorHandler.js'
import { writeAuditLog } from '../utils/auditLog.js'
import { notificationService } from './notificationService.js'

type LanguageStatus = 'NOT_CHECKED' | 'APPROVED' | 'EXAM_REQUIRED' | 'NOT_MET'

const YDYO_STATUSES = ['PENDING_LANGUAGE_CHECK']

// Shared select columns for app + applicant join
const appCols = (u: typeof users, a: typeof applications) => ({
  id:                  a.id,
  applicantId:         a.applicantId,
  transferType:        a.transferType,
  previousUniversity:  a.previousUniversity,
  currentProgram:      a.currentProgram,
  targetProgram:       a.targetProgram,
  currentGpa:          a.currentGpa,
  currentSemester:     a.currentSemester,
  targetSemester:      a.targetSemester,
  academicYear:        a.academicYear,
  reasonForTransfer:   a.reasonForTransfer,
  status:              a.status,
  languageStatus:      a.languageStatus,
  languageNotes:       a.languageNotes,
  submittedAt:         a.submittedAt,
  createdAt:           a.createdAt,
  updatedAt:           a.updatedAt,
  applicantFirstName:  u.firstName,
  applicantLastName:   u.lastName,
  applicantEmail:      u.email,
  applicantStudentId:  u.studentId,
})

export const ydyoService = {

  // SFL.01 — list apps pending language check
  async getAllApplications() {
    return db
      .select(appCols(users, applications))
      .from(applications)
      .innerJoin(users, eq(applications.applicantId, users.id))
      .where(eq(applications.status, 'PENDING_LANGUAGE_CHECK'))
      .orderBy(desc(applications.updatedAt))
  },

  async getApplicationById(appId: string) {
    const [row] = await db
      .select(appCols(users, applications))
      .from(applications)
      .innerJoin(users, eq(applications.applicantId, users.id))
      .where(eq(applications.id, appId))
      .limit(1)
    if (!row) throw new AppError(404, 'Application not found.')
    if (row.status !== 'PENDING_LANGUAGE_CHECK') throw new AppError(403, 'Access denied.')
    return row
  },

  // SFL.02 — evaluate English proficiency
  async evaluate(ydyoUserId: string, appId: string, languageStatus: LanguageStatus, notes?: string) {
    const [app] = await db.select().from(applications).where(eq(applications.id, appId)).limit(1)
    if (!app) throw new AppError(404, 'Application not found.')
    if (app.status !== 'PENDING_LANGUAGE_CHECK') throw new AppError(400, 'Application is not pending language check.')

    // Determine next application status
    let nextStatus: string
    let notifTitle: string
    let notifMsg: string

    if (languageStatus === 'APPROVED') {
      nextStatus = 'ELIGIBLE'
      notifTitle = 'İngilizce Yeterlilik Onaylandı'
      notifMsg = 'İngilizce yeterlilik belgeniz YDYO tarafından onaylandı. Başvurunuz değerlendirme sürecine alınmıştır.'
    } else if (languageStatus === 'EXAM_REQUIRED') {
      nextStatus = 'PENDING_LANGUAGE_CHECK' // stays, awaiting exam
      notifTitle = 'İngilizce Sınavı Gerekiyor'
      notifMsg = notes
        ? `İngilizce yeterlilik için sınava girmeniz gerekmektedir. Not: ${notes}`
        : 'İngilizce yeterlilik için sınava girmeniz gerekmektedir. YDYO ile iletişime geçin.'
    } else if (languageStatus === 'NOT_MET') {
      nextStatus = 'INELIGIBLE'
      notifTitle = 'İngilizce Yeterlilik Sağlanamadı'
      notifMsg = notes
        ? `İngilizce yeterlilik şartını karşılayamadınız. Gerekçe: ${notes}`
        : 'İngilizce yeterlilik şartını karşılayamadınız.'
    } else {
      throw new AppError(400, 'Invalid language status.')
    }

    const [updated] = await db.update(applications)
      .set({
        languageStatus,
        languageNotes: notes ?? null,
        status: nextStatus as any,
        updatedAt: new Date(),
      })
      .where(eq(applications.id, appId))
      .returning()

    await writeAuditLog({
      userId: ydyoUserId,
      action: `LANGUAGE_EVALUATED_${languageStatus}`,
      entityType: 'APPLICATION',
      entityId: appId,
    })

    notificationService.create(app.applicantId, notifTitle, notifMsg).catch(() => {})
    return updated
  },

  // SFL.03 — record exam result (pass/fail)
  async recordExamResult(ydyoUserId: string, appId: string, passed: boolean, score?: number, notes?: string) {
    const [app] = await db.select().from(applications).where(eq(applications.id, appId)).limit(1)
    if (!app) throw new AppError(404, 'Application not found.')
    if (app.status !== 'PENDING_LANGUAGE_CHECK' || app.languageStatus !== 'EXAM_REQUIRED') {
      throw new AppError(400, 'Application is not awaiting exam result.')
    }

    const languageStatus: LanguageStatus = passed ? 'APPROVED' : 'NOT_MET'
    const nextStatus = passed ? 'ELIGIBLE' : 'INELIGIBLE'
    const examNote = score !== undefined
      ? `Sınav sonucu: ${score} — ${passed ? 'Geçti' : 'Kaldı'}${notes ? `. ${notes}` : ''}`
      : notes ?? (passed ? 'Sınav geçildi.' : 'Sınav başarısız.')

    const [updated] = await db.update(applications)
      .set({
        languageStatus,
        languageNotes: examNote,
        status: nextStatus as any,
        updatedAt: new Date(),
      })
      .where(eq(applications.id, appId))
      .returning()

    await writeAuditLog({
      userId: ydyoUserId,
      action: `EXAM_RESULT_RECORDED_${languageStatus}`,
      entityType: 'APPLICATION',
      entityId: appId,
    })

    notificationService.create(
      app.applicantId,
      passed ? 'İngilizce Sınavı Başarılı' : 'İngilizce Sınavı Başarısız',
      examNote
    ).catch(() => {})

    return updated
  },
}
