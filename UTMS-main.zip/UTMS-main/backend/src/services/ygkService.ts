import { eq, desc, inArray } from 'drizzle-orm'
import { db } from '../db/index.js'
import { applications, users, courseEquivalencies } from '../db/schema/index.js'
import { AppError } from '../middleware/errorHandler.js'
import { writeAuditLog } from '../utils/auditLog.js'
import { notificationService } from './notificationService.js'

type EquivalencyStatus = 'EQUIVALENT' | 'PARTIALLY_EQUIVALENT' | 'NOT_EQUIVALENT'

// Valid transitions YGK can make
const YGK_TRANSITIONS: Record<string, string[]> = {
  UNDER_YGK_EVALUATION: ['ACADEMICALLY_EVALUATED'],
  ACADEMICALLY_EVALUATED: ['RANKING_IN_PROGRESS'],
  RANKING_IN_PROGRESS: ['FORWARDED_TO_FACULTY'],
}

const STATUS_NOTIF: Record<string, { title: string; message: (note?: string) => string }> = {
  ACADEMICALLY_EVALUATED: {
    title: 'Akademik Değerlendirmeniz Tamamlandı',
    message: () => 'Başvurunuzun akademik değerlendirmesi YGK tarafından tamamlandı.',
  },
  RANKING_IN_PROGRESS: {
    title: 'Sıralama Sürecine Alındınız',
    message: () => 'Başvurunuz sıralama aşamasına geçirildi.',
  },
  FORWARDED_TO_FACULTY: {
    title: 'Başvurunuz Fakülte Kuruluna İletildi',
    message: () => 'Başvurunuz nihai karar için Fakülte Kuruluna yönlendirildi.',
  },
}

// ─── Application helpers ──────────────────────────────────────────────────────

const YGK_STATUSES = [
  'UNDER_YGK_EVALUATION',
  'ACADEMICALLY_EVALUATED',
  'RANKING_IN_PROGRESS',
  'FORWARDED_TO_FACULTY',
  'APPROVED',
  'REJECTED',
  'FINALIZED',
]

export const ygkService = {

  async getAllApplications(statusFilter?: string[]) {
    const statuses = (statusFilter && statusFilter.length > 0
      ? statusFilter
      : YGK_STATUSES) as any[]

    return db
      .select({
        id:                  applications.id,
        applicantId:         applications.applicantId,
        transferType:        applications.transferType,
        previousUniversity:  applications.previousUniversity,
        currentProgram:      applications.currentProgram,
        targetProgram:       applications.targetProgram,
        currentGpa:          applications.currentGpa,
        currentSemester:     applications.currentSemester,
        targetSemester:      applications.targetSemester,
        academicYear:        applications.academicYear,
        reasonForTransfer:   applications.reasonForTransfer,
        status:              applications.status,
        submittedAt:         applications.submittedAt,
        createdAt:           applications.createdAt,
        updatedAt:           applications.updatedAt,
        applicantFirstName:  users.firstName,
        applicantLastName:   users.lastName,
        applicantEmail:      users.email,
        applicantStudentId:  users.studentId,
      })
      .from(applications)
      .innerJoin(users, eq(applications.applicantId, users.id))
      .where(inArray(applications.status, statuses))
      .orderBy(desc(applications.updatedAt))
  },

  async getApplicationById(appId: string) {
    const [row] = await db
      .select({
        id:                  applications.id,
        applicantId:         applications.applicantId,
        transferType:        applications.transferType,
        previousUniversity:  applications.previousUniversity,
        currentProgram:      applications.currentProgram,
        targetProgram:       applications.targetProgram,
        currentGpa:          applications.currentGpa,
        currentSemester:     applications.currentSemester,
        targetSemester:      applications.targetSemester,
        academicYear:        applications.academicYear,
        reasonForTransfer:   applications.reasonForTransfer,
        status:              applications.status,
        evaluationScore:     applications.evaluationScore,
        evaluationNotes:     applications.evaluationNotes,
        submittedAt:         applications.submittedAt,
        createdAt:           applications.createdAt,
        updatedAt:           applications.updatedAt,
        applicantFirstName:  users.firstName,
        applicantLastName:   users.lastName,
        applicantEmail:      users.email,
        applicantStudentId:  users.studentId,
      })
      .from(applications)
      .innerJoin(users, eq(applications.applicantId, users.id))
      .where(eq(applications.id, appId))
      .limit(1)

    if (!row) throw new AppError(404, 'Application not found.')
    if (!YGK_STATUSES.includes(row.status)) throw new AppError(403, 'Access denied.')
    return row
  },

  // YE.1, RK.1, FF.1 — status transitions
  async updateStatus(
    ygkUserId: string,
    appId: string,
    newStatus: string,
    note?: string,
    evaluationScore?: number,
    evaluationNotes?: string,
  ) {
    const [app] = await db.select().from(applications).where(eq(applications.id, appId)).limit(1)
    if (!app) throw new AppError(404, 'Application not found.')

    const allowed = YGK_TRANSITIONS[app.status] || []
    if (!allowed.includes(newStatus)) {
      throw new AppError(400, `Cannot transition from ${app.status} to ${newStatus}.`)
    }

    // Only save evaluation fields when transitioning to ACADEMICALLY_EVALUATED
    const extraFields = newStatus === 'ACADEMICALLY_EVALUATED' ? {
      evaluationScore:  evaluationScore != null ? String(evaluationScore) : undefined,
      evaluationNotes:  evaluationNotes ?? undefined,
    } : {}

    const [updated] = await db.update(applications)
      .set({ status: newStatus as any, updatedAt: new Date(), ...extraFields })
      .where(eq(applications.id, appId))
      .returning()

    await writeAuditLog({
      userId: ygkUserId,
      action: `STATUS_CHANGED_TO_${newStatus}`,
      entityType: 'APPLICATION',
      entityId: appId,
      oldValue: app.status,
      newValue: newStatus,
    })

    const notif = STATUS_NOTIF[newStatus]
    if (notif) {
      notificationService.create(app.applicantId, notif.title, notif.message(note)).catch(() => {})
    }

    return updated
  },

  // CE.1 — Course equivalencies
  async getCourseEquivalencies(appId: string) {
    return db.select().from(courseEquivalencies)
      .where(eq(courseEquivalencies.applicationId, appId))
      .orderBy(courseEquivalencies.createdAt)
  },

  async createCourseEquivalency(ygkUserId: string, appId: string, data: {
    previousCourseCode: string
    previousCourseName: string
    previousCourseCredits: string
    targetCourseCode: string
    targetCourseName: string
    targetCourseCredits: string
    status: EquivalencyStatus
    notes?: string
  }) {
    const [app] = await db.select({ id: applications.id, status: applications.status })
      .from(applications).where(eq(applications.id, appId)).limit(1)
    if (!app) throw new AppError(404, 'Application not found.')

    const [eq_] = await db.insert(courseEquivalencies).values({
      applicationId:         appId,
      createdBy:             ygkUserId,
      previousCourseCode:    data.previousCourseCode,
      previousCourseName:    data.previousCourseName,
      previousCourseCredits: data.previousCourseCredits,
      targetCourseCode:      data.targetCourseCode,
      targetCourseName:      data.targetCourseName,
      targetCourseCredits:   data.targetCourseCredits,
      status:                data.status,
      notes:                 data.notes,
    }).returning()

    await writeAuditLog({ userId: ygkUserId, action: 'EQUIVALENCY_CREATED', entityType: 'EQUIVALENCY', entityId: eq_.id })
    return eq_
  },

  async updateCourseEquivalency(ygkUserId: string, eqId: string, data: Partial<{
    previousCourseCode: string
    previousCourseName: string
    previousCourseCredits: string
    targetCourseCode: string
    targetCourseName: string
    targetCourseCredits: string
    status: EquivalencyStatus
    notes: string
  }>) {
    const [existing] = await db.select().from(courseEquivalencies)
      .where(eq(courseEquivalencies.id, eqId)).limit(1)
    if (!existing) throw new AppError(404, 'Equivalency not found.')

    const [updated] = await db.update(courseEquivalencies)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(courseEquivalencies.id, eqId))
      .returning()

    return updated
  },

  async deleteCourseEquivalency(ygkUserId: string, eqId: string) {
    const [existing] = await db.select().from(courseEquivalencies)
      .where(eq(courseEquivalencies.id, eqId)).limit(1)
    if (!existing) throw new AppError(404, 'Equivalency not found.')

    await db.delete(courseEquivalencies).where(eq(courseEquivalencies.id, eqId))
    await writeAuditLog({ userId: ygkUserId, action: 'EQUIVALENCY_DELETED', entityType: 'EQUIVALENCY', entityId: eqId })
    return { message: 'Deleted.' }
  },

  // RK.1 — Save manual ranking position + justification
  async updateRanking(ygkUserId: string, appId: string, rankingPosition: number, rankingJustification?: string) {
    const [app] = await db.select({ id: applications.id, status: applications.status })
      .from(applications).where(eq(applications.id, appId)).limit(1)
    if (!app) throw new AppError(404, 'Application not found.')
    if (app.status !== 'ACADEMICALLY_EVALUATED') {
      throw new AppError(400, 'Ranking can only be set for ACADEMICALLY_EVALUATED applications.')
    }
    if (!Number.isInteger(rankingPosition) || rankingPosition < 1) {
      throw new AppError(400, 'rankingPosition must be a positive integer.')
    }

    const [updated] = await db.update(applications)
      .set({ rankingPosition, rankingJustification: rankingJustification ?? null, updatedAt: new Date() })
      .where(eq(applications.id, appId))
      .returning()

    await writeAuditLog({
      userId: ygkUserId,
      action: 'RANKING_UPDATED',
      entityType: 'APPLICATION',
      entityId: appId,
      newValue: String(rankingPosition),
    })

    return updated
  },

  // RK.1 — Ranked list of ACADEMICALLY_EVALUATED apps (sorted by GPA desc)
  async getRankedApplications(academicYear?: string, targetProgram?: string) {
    const rows = await db
      .select({
        id:                    applications.id,
        transferType:          applications.transferType,
        targetProgram:         applications.targetProgram,
        currentGpa:            applications.currentGpa,
        currentSemester:       applications.currentSemester,
        academicYear:          applications.academicYear,
        status:                applications.status,
        evaluationScore:       applications.evaluationScore,
        rankingPosition:       applications.rankingPosition,
        rankingJustification:  applications.rankingJustification,
        applicantFirstName:    users.firstName,
        applicantLastName:     users.lastName,
        applicantStudentId:    users.studentId,
      })
      .from(applications)
      .innerJoin(users, eq(applications.applicantId, users.id))
      .where(eq(applications.status, 'ACADEMICALLY_EVALUATED'))
      .orderBy(desc(applications.currentGpa))

    return rows
  },
}
