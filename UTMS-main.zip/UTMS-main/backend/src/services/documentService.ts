import { eq, and } from 'drizzle-orm'
import fs from 'fs/promises'
import { db } from '../db/index.js'
import { documents, applications } from '../db/schema/index.js'
import { AppError } from '../middleware/errorHandler.js'
import { writeAuditLog } from '../utils/auditLog.js'

const LOCKED_STATUSES = ['APPROVED', 'REJECTED', 'FINALIZED', 'WITHDRAWN']

export const documentService = {

  async upload(userId: string, applicationId: string, data: {
    type: 'TRANSCRIPT' | 'COURSE_DESCRIPTION' | 'STUDENT_ID' | 'ENGLISH_CERTIFICATE' | 'PLACEMENT_RESULT' | 'OTHER'
    fileName: string
    filePath: string
    fileSize: number
    mimeType: string
  }) {
    const [app] = await db.select().from(applications)
      .where(and(eq(applications.id, applicationId), eq(applications.applicantId, userId)))
      .limit(1)
    if (!app) throw new AppError(404, 'Application not found.')
    if (LOCKED_STATUSES.includes(app.status)) throw new AppError(400, 'Cannot upload documents to this application.')

    const [doc] = await db.insert(documents).values({
      applicationId, uploadedBy: userId,
      type: data.type, fileName: data.fileName,
      filePath: data.filePath, fileSize: data.fileSize,
      mimeType: data.mimeType, status: 'PENDING',
    }).returning()

    await writeAuditLog({ userId, action: 'DOCUMENT_UPLOADED', entityType: 'DOCUMENT', entityId: doc.id })
    return doc
  },

  async getByApplication(userId: string, applicationId: string) {
    const [app] = await db.select({ id: applications.id }).from(applications)
      .where(and(eq(applications.id, applicationId), eq(applications.applicantId, userId)))
      .limit(1)
    if (!app) throw new AppError(404, 'Application not found.')

    return db.select().from(documents)
      .where(eq(documents.applicationId, applicationId))
      .orderBy(documents.uploadedAt)
  },

  async delete(userId: string, documentId: string) {
    const [doc] = await db.select().from(documents)
      .where(and(eq(documents.id, documentId), eq(documents.uploadedBy, userId)))
      .limit(1)
    if (!doc) throw new AppError(404, 'Document not found.')
    if (doc.status === 'VERIFIED') throw new AppError(400, 'Cannot delete a verified document.')

    try { await fs.unlink(doc.filePath) } catch { /* already gone */ }

    await db.delete(documents).where(eq(documents.id, documentId))
    await writeAuditLog({ userId, action: 'DOCUMENT_DELETED', entityType: 'DOCUMENT', entityId: documentId })
    return { message: 'Document deleted.' }
  },

  async getFilePath(userId: string, documentId: string) {
    const [doc] = await db.select().from(documents)
      .where(eq(documents.id, documentId)).limit(1)
    if (!doc) throw new AppError(404, 'Document not found.')

    const [app] = await db.select({ id: applications.id }).from(applications)
      .where(and(eq(applications.id, doc.applicationId), eq(applications.applicantId, userId)))
      .limit(1)
    if (!app) throw new AppError(403, 'Access denied.')

    return { filePath: doc.filePath, fileName: doc.fileName, mimeType: doc.mimeType }
  },
}
