import { eq, desc, inArray } from 'drizzle-orm'
import { db } from '../db/index.js'
import { applications, users, documents } from '../db/schema/index.js'
import { AppError } from '../middleware/errorHandler.js'
import { writeAuditLog } from '../utils/auditLog.js'
import { notificationService } from './notificationService.js'

type ApplicationStatus =
  | 'DRAFT' | 'SUBMITTED' | 'UNDER_REVIEW' | 'RETURNED_FOR_CORRECTION'
  | 'PENDING_VERIFICATION' | 'PENDING_LANGUAGE_CHECK' | 'ELIGIBLE' | 'INELIGIBLE'
  | 'UNDER_YGK_EVALUATION' | 'ACADEMICALLY_EVALUATED'
  | 'RANKING_IN_PROGRESS' | 'FORWARDED_TO_FACULTY'
  | 'APPROVED' | 'REJECTED' | 'WITHDRAWN' | 'FINALIZED'

// Valid transitions from each status that ÖİDB staff can make
const OIDB_TRANSITIONS: Record<string, ApplicationStatus[]> = {
  SUBMITTED:               ['UNDER_REVIEW'],
  UNDER_REVIEW:            ['RETURNED_FOR_CORRECTION', 'PENDING_VERIFICATION', 'PENDING_LANGUAGE_CHECK', 'ELIGIBLE', 'INELIGIBLE'],
  RETURNED_FOR_CORRECTION: ['UNDER_REVIEW'],
  PENDING_VERIFICATION:    ['ELIGIBLE', 'INELIGIBLE', 'UNDER_REVIEW'],
  ELIGIBLE:                ['UNDER_YGK_EVALUATION'],
}

const STATUS_NOTIF: Record<string, { title: string; message: (note?: string) => string }> = {
  UNDER_YGK_EVALUATION: {
    title: 'Başvurunuz YGK\'ya Yönlendirildi',
    message: () => 'Transfer başvurunuz akademik değerlendirme için YGK\'ya iletildi.',
  },
  UNDER_REVIEW: {
    title: 'Başvurunuz İncelemeye Alındı',
    message: () => 'Transfer başvurunuz ÖİDB tarafından incelemeye alındı.',
  },
  RETURNED_FOR_CORRECTION: {
    title: 'Başvurunuzda Düzeltme Gerekiyor',
    message: (note) => note
      ? `Başvurunuz eksik/hatalı belgeler nedeniyle düzeltme için iade edildi. Not: ${note}`
      : 'Başvurunuz eksik/hatalı belgeler nedeniyle düzeltme için iade edildi.',
  },
  PENDING_VERIFICATION: {
    title: 'Belgeleriniz Doğrulamaya Alındı',
    message: () => 'Belgeleriniz doğrulama aşamasına geçirildi.',
  },
  PENDING_LANGUAGE_CHECK: {
    title: 'İngilizce Yeterlilik Kontrolü',
    message: () => 'Başvurunuz İngilizce yeterlilik kontrolü için YDYO\'ya yönlendirildi.',
  },
  ELIGIBLE: {
    title: 'Başvurunuz Uygun Bulundu',
    message: () => 'Ön değerlendirme sonucunda başvurunuz uygun bulunmuştur.',
  },
  INELIGIBLE: {
    title: 'Başvurunuz Uygun Bulunmadı',
    message: (note) => note
      ? `Ön değerlendirme sonucunda başvurunuz uygun bulunmamıştır. Gerekçe: ${note}`
      : 'Ön değerlendirme sonucunda başvurunuz uygun bulunmamıştır.',
  },
}

export const staffService = {

  async getAllApplications(statusFilter?: string[]) {
    // Join with user info to show applicant name
    const rows = await db
      .select({
        id:                  applications.id,
        applicantId:         applications.applicantId,
        transferType:        applications.transferType,
        previousUniversity:  applications.previousUniversity,
        currentProgram:      applications.currentProgram,
        targetProgram:       applications.targetProgram,
        currentGpa:          applications.currentGpa,
        currentSemester:     applications.currentSemester,
        targetSemester:      applications.targetSemester,
        academicYear:        applications.academicYear,
        reasonForTransfer:   applications.reasonForTransfer,
        status:              applications.status,
        isEligible:          applications.isEligible,
        submittedAt:         applications.submittedAt,
        createdAt:           applications.createdAt,
        updatedAt:           applications.updatedAt,
        applicantFirstName:  users.firstName,
        applicantLastName:   users.lastName,
        applicantEmail:      users.email,
        applicantStudentId:  users.studentId,
      })
      .from(applications)
      .innerJoin(users, eq(applications.applicantId, users.id))
      .where(
        statusFilter && statusFilter.length > 0
          ? inArray(applications.status, statusFilter as ApplicationStatus[])
          : undefined
      )
      .orderBy(desc(applications.updatedAt))

    return rows
  },

  async getApplicationById(appId: string) {
    const [row] = await db
      .select({
        id:                  applications.id,
        applicantId:         applications.applicantId,
        transferType:        applications.transferType,
        previousUniversity:  applications.previousUniversity,
        currentProgram:      applications.currentProgram,
        targetProgram:       applications.targetProgram,
        currentGpa:          applications.currentGpa,
        currentSemester:     applications.currentSemester,
        targetSemester:      applications.targetSemester,
        academicYear:        applications.academicYear,
        reasonForTransfer:   applications.reasonForTransfer,
        status:              applications.status,
        isEligible:          applications.isEligible,
        submittedAt:         applications.submittedAt,
        createdAt:           applications.createdAt,
        updatedAt:           applications.updatedAt,
        applicantFirstName:  users.firstName,
        applicantLastName:   users.lastName,
        applicantEmail:      users.email,
        applicantStudentId:  users.studentId,
      })
      .from(applications)
      .innerJoin(users, eq(applications.applicantId, users.id))
      .where(eq(applications.id, appId))
      .limit(1)

    if (!row) throw new AppError(404, 'Application not found.')
    return row
  },

  async updateStatus(staffId: string, appId: string, newStatus: ApplicationStatus, note?: string) {
    const [app] = await db.select().from(applications).where(eq(applications.id, appId)).limit(1)
    if (!app) throw new AppError(404, 'Application not found.')

    const allowed = OIDB_TRANSITIONS[app.status] || []
    if (!allowed.includes(newStatus)) {
      throw new AppError(400, `Cannot transition from ${app.status} to ${newStatus}.`)
    }

    const [updated] = await db.update(applications)
      .set({ status: newStatus, updatedAt: new Date() })
      .where(eq(applications.id, appId))
      .returning()

    await writeAuditLog({
      userId: staffId,
      action: `STATUS_CHANGED_TO_${newStatus}`,
      entityType: 'APPLICATION',
      entityId: appId,
      oldValue: app.status,
      newValue: newStatus,
    })

    // Notify the applicant
    const notif = STATUS_NOTIF[newStatus]
    if (notif) {
      notificationService.create(app.applicantId, notif.title, notif.message(note)).catch(() => {})
    }

    return updated
  },

  async getDocumentsByApplication(appId: string) {
    // Verify application exists
    const [app] = await db.select({ id: applications.id }).from(applications)
      .where(eq(applications.id, appId)).limit(1)
    if (!app) throw new AppError(404, 'Application not found.')

    return db.select().from(documents)
      .where(eq(documents.applicationId, appId))
      .orderBy(documents.uploadedAt)
  },

  async verifyDocument(staffId: string, docId: string) {
    const [doc] = await db.select().from(documents).where(eq(documents.id, docId)).limit(1)
    if (!doc) throw new AppError(404, 'Document not found.')
    if (doc.status === 'VERIFIED') throw new AppError(400, 'Document already verified.')

    const [updated] = await db.update(documents)
      .set({ status: 'VERIFIED', verifiedBy: staffId, verifiedAt: new Date(), rejectionReason: null })
      .where(eq(documents.id, docId))
      .returning()

    await writeAuditLog({ userId: staffId, action: 'DOCUMENT_VERIFIED', entityType: 'DOCUMENT', entityId: docId })

    // Notify applicant via application's applicantId
    const [app] = await db.select({ applicantId: applications.applicantId, targetProgram: applications.targetProgram })
      .from(applications).where(eq(applications.id, doc.applicationId)).limit(1)
    if (app) {
      notificationService.create(
        app.applicantId,
        'Belgeniz Doğrulandı',
        `"${doc.fileName}" adlı belgeniz ÖİDB tarafından doğrulandı.`
      ).catch(() => {})
    }

    return updated
  },

  async rejectDocument(staffId: string, docId: string, reason: string) {
    const [doc] = await db.select().from(documents).where(eq(documents.id, docId)).limit(1)
    if (!doc) throw new AppError(404, 'Document not found.')
    if (!reason?.trim()) throw new AppError(400, 'Rejection reason is required.')

    const [updated] = await db.update(documents)
      .set({ status: 'REJECTED', rejectionReason: reason, verifiedBy: staffId, verifiedAt: new Date() })
      .where(eq(documents.id, docId))
      .returning()

    await writeAuditLog({ userId: staffId, action: 'DOCUMENT_REJECTED', entityType: 'DOCUMENT', entityId: docId })

    const [app] = await db.select({ applicantId: applications.applicantId })
      .from(applications).where(eq(applications.id, doc.applicationId)).limit(1)
    if (app) {
      notificationService.create(
        app.applicantId,
        'Belgeniz Reddedildi',
        `"${doc.fileName}" adlı belgeniz reddedildi. Gerekçe: ${reason}`
      ).catch(() => {})
    }

    return updated
  },

  async getDocumentFilePath(docId: string) {
    const [doc] = await db.select().from(documents).where(eq(documents.id, docId)).limit(1)
    if (!doc) throw new AppError(404, 'Document not found.')
    return { filePath: doc.filePath, fileName: doc.fileName, mimeType: doc.mimeType }
  },
}
