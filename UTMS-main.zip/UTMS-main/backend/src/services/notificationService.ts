import { eq, and, desc } from 'drizzle-orm'
import { db } from '../db/index.js'
import { notifications } from '../db/schema/index.js'
import { AppError } from '../middleware/errorHandler.js'

export const notificationService = {

  async create(userId: string, title: string, message: string) {
    const [notif] = await db.insert(notifications).values({ userId, title, message }).returning()
    return notif
  },

  async getAll(userId: string) {
    return db.select().from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt))
  },

  async markAsRead(userId: string, notificationId: string) {
    const [notif] = await db.update(notifications)
      .set({ isRead: true })
      .where(and(eq(notifications.id, notificationId), eq(notifications.userId, userId)))
      .returning()
    if (!notif) throw new AppError(404, 'Notification not found.')
    return notif
  },

  async markAllAsRead(userId: string) {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.userId, userId))
    return { message: 'All notifications marked as read.' }
  },
}
