import { eq, desc, inArray } from 'drizzle-orm'
import { db } from '../db/index.js'
import { applications, users } from '../db/schema/index.js'
import { AppError } from '../middleware/errorHandler.js'
import { writeAuditLog } from '../utils/auditLog.js'
import { notificationService } from './notificationService.js'

type ApplicationStatus = 'FORWARDED_TO_FACULTY' | 'APPROVED' | 'REJECTED' | 'FINALIZED'

// Valid transitions that Faculty Board can make
const FACULTY_TRANSITIONS: Record<string, string[]> = {
  FORWARDED_TO_FACULTY: ['APPROVED', 'REJECTED'],
}

const FB_STATUSES = ['FORWARDED_TO_FACULTY', 'APPROVED', 'REJECTED', 'FINALIZED']

const STATUS_NOTIF: Record<string, { title: string; message: (note?: string) => string }> = {
  APPROVED: {
    title: 'Başvurunuz Onaylandı',
    message: (note) => note
      ? `Tebrikler! Transfer başvurunuz Fakülte Kurulu tarafından onaylanmıştır. Not: ${note}`
      : 'Tebrikler! Transfer başvurunuz Fakülte Kurulu tarafından onaylanmıştır.',
  },
  REJECTED: {
    title: 'Başvurunuz Reddedildi',
    message: (note) => note
      ? `Transfer başvurunuz Fakülte Kurulu tarafından reddedilmiştir. Gerekçe: ${note}`
      : 'Transfer başvurunuz Fakülte Kurulu tarafından reddedilmiştir.',
  },
}

// Shared select columns
const appCols = (u: typeof users, a: typeof applications) => ({
  id:                  a.id,
  applicantId:         a.applicantId,
  transferType:        a.transferType,
  previousUniversity:  a.previousUniversity,
  currentProgram:      a.currentProgram,
  targetProgram:       a.targetProgram,
  currentGpa:          a.currentGpa,
  currentSemester:     a.currentSemester,
  targetSemester:      a.targetSemester,
  academicYear:        a.academicYear,
  reasonForTransfer:   a.reasonForTransfer,
  status:              a.status,
  evaluationScore:     a.evaluationScore,
  evaluationNotes:     a.evaluationNotes,
  rankingPosition:     a.rankingPosition,
  submittedAt:         a.submittedAt,
  createdAt:           a.createdAt,
  updatedAt:           a.updatedAt,
  applicantFirstName:  u.firstName,
  applicantLastName:   u.lastName,
  applicantEmail:      u.email,
  applicantStudentId:  u.studentId,
})

export const facultyBoardService = {

  // FB.1 — list applications forwarded to faculty
  async getAllApplications(statusFilter?: string[]) {
    const statuses = (statusFilter && statusFilter.length > 0
      ? statusFilter
      : FB_STATUSES) as any[]

    return db
      .select(appCols(users, applications))
      .from(applications)
      .innerJoin(users, eq(applications.applicantId, users.id))
      .where(inArray(applications.status, statuses))
      .orderBy(desc(applications.updatedAt))
  },

  async getApplicationById(appId: string) {
    const [row] = await db
      .select(appCols(users, applications))
      .from(applications)
      .innerJoin(users, eq(applications.applicantId, users.id))
      .where(eq(applications.id, appId))
      .limit(1)

    if (!row) throw new AppError(404, 'Application not found.')
    if (!FB_STATUSES.includes(row.status)) throw new AppError(403, 'Access denied.')
    return row
  },

  // FB.2 — approve or reject
  async updateStatus(facultyUserId: string, appId: string, newStatus: string, note?: string) {
    const [app] = await db.select().from(applications).where(eq(applications.id, appId)).limit(1)
    if (!app) throw new AppError(404, 'Application not found.')

    const allowed = FACULTY_TRANSITIONS[app.status] || []
    if (!allowed.includes(newStatus)) {
      throw new AppError(400, `Cannot transition from ${app.status} to ${newStatus}.`)
    }

    const [updated] = await db.update(applications)
      .set({ status: newStatus as any, updatedAt: new Date() })
      .where(eq(applications.id, appId))
      .returning()

    await writeAuditLog({
      userId: facultyUserId,
      action: `STATUS_CHANGED_TO_${newStatus}`,
      entityType: 'APPLICATION',
      entityId: appId,
      oldValue: app.status,
      newValue: newStatus,
    })

    const notif = STATUS_NOTIF[newStatus]
    if (notif) {
      notificationService.create(app.applicantId, notif.title, notif.message(note)).catch(() => {})
    }

    return updated
  },
}
