import { eq, and, gt } from 'drizzle-orm'
import { hash, verify } from '@node-rs/argon2'
import { randomBytes } from 'crypto'
import { db } from '../db/index.js'
import { users, verificationTokens } from '../db/schema/index.js'
import { AppError } from '../middleware/errorHandler.js'
import { signToken } from '../utils/jwt.js'
import { sendVerificationEmail, sendPasswordResetEmail } from '../utils/mailer.js'
import { writeAuditLog } from '../utils/auditLog.js'

export const authService = {

  async register(data: {
    firstName: string; lastName: string; email: string; studentNumber: string; password: string
  }) {
    const existingEmail = await db.select({ id: users.id }).from(users)
      .where(eq(users.email, data.email.toLowerCase())).limit(1)
    if (existingEmail.length > 0) throw new AppError(409, 'An account with this email already exists.')

    const existingStudent = await db.select({ id: users.id }).from(users)
      .where(eq(users.studentId, data.studentNumber)).limit(1)
    if (existingStudent.length > 0) throw new AppError(409, 'An account with this student number already exists.')

    const passwordHash = await hash(data.password)

    const [user] = await db.insert(users).values({
      studentId: data.studentNumber, firstName: data.firstName, lastName: data.lastName,
      email: data.email.toLowerCase(), passwordHash, role: 'APPLICANT',
      isVerified: process.env.NODE_ENV === 'development' || process.env.SKIP_EMAIL_VERIFY === 'true',
    }).returning()

    const token = randomBytes(32).toString('hex')
    await db.insert(verificationTokens).values({
      userId: user.id, token, type: 'EMAIL_VERIFY',
      expiresAt: new Date(Date.now() + 30 * 60 * 1000),
    })

    sendVerificationEmail(user.email, token).catch((err) =>
      console.error('[Mailer] Verification email failed:', err)
    )

    await writeAuditLog({ userId: user.id, action: 'REGISTER', entityType: 'USER', entityId: user.id })
    return { message: 'Account created. Please check your email to verify your account.' }
  },

  async verifyEmail(token: string) {
    const now = new Date()
    const [record] = await db.select().from(verificationTokens)
      .where(and(eq(verificationTokens.token, token), eq(verificationTokens.type, 'EMAIL_VERIFY'), gt(verificationTokens.expiresAt, now)))
      .limit(1)

    if (!record || record.usedAt) throw new AppError(400, 'Invalid or expired verification link.')

    await db.update(users).set({ isVerified: true }).where(eq(users.id, record.userId))
    await db.update(verificationTokens).set({ usedAt: now }).where(eq(verificationTokens.id, record.id))
    return { message: 'Email verified successfully.' }
  },

  async login(studentId: string, password: string, ipAddress?: string) {
    const [user] = await db.select().from(users).where(eq(users.studentId, studentId)).limit(1)

    if (!user) {
      await writeAuditLog({ action: 'LOGIN_FAILED', entityType: 'USER', ipAddress })
      throw new AppError(401, 'Invalid student ID or password.')
    }

    const valid = await verify(user.passwordHash, password)
    if (!valid) {
      await writeAuditLog({ userId: user.id, action: 'LOGIN_FAILED', entityType: 'USER', entityId: user.id, ipAddress })
      throw new AppError(401, 'Invalid student ID or password.')
    }

    if (!user.isVerified) throw new AppError(403, 'Please verify your email before logging in.')

    const token = signToken({ userId: user.id, role: user.role, studentId: user.studentId })
    await writeAuditLog({ userId: user.id, action: 'LOGIN', entityType: 'USER', entityId: user.id, ipAddress })

    return {
      token,
      user: {
        id: user.id, studentId: user.studentId, firstName: user.firstName, lastName: user.lastName,
        email: user.email, role: user.role, isVerified: user.isVerified, createdAt: user.createdAt.toISOString(),
      },
    }
  },

  async forgotPassword(email: string) {
    const [user] = await db.select({ id: users.id, email: users.email, isVerified: users.isVerified })
      .from(users).where(eq(users.email, email.toLowerCase())).limit(1)

    if (!user || !user.isVerified) return { message: 'If an account exists, a reset link has been sent.' }

    const token = randomBytes(32).toString('hex')
    await db.insert(verificationTokens).values({
      userId: user.id, token, type: 'PASSWORD_RESET',
      expiresAt: new Date(Date.now() + 60 * 60 * 1000),
    })

    sendPasswordResetEmail(user.email, token).catch((err) =>
      console.error('[Mailer] Reset email failed:', err)
    )

    return { message: 'If an account exists, a reset link has been sent.' }
  },

  async resetPassword(token: string, newPassword: string) {
    const now = new Date()
    const [record] = await db.select().from(verificationTokens)
      .where(and(eq(verificationTokens.token, token), eq(verificationTokens.type, 'PASSWORD_RESET'), gt(verificationTokens.expiresAt, now)))
      .limit(1)

    if (!record || record.usedAt) throw new AppError(400, 'Invalid or expired reset link.')

    const passwordHash = await hash(newPassword)
    await db.update(users).set({ passwordHash }).where(eq(users.id, record.userId))
    await db.update(verificationTokens).set({ usedAt: now }).where(eq(verificationTokens.id, record.id))
    return { message: 'Password updated successfully.' }
  },

  async getMe(userId: string) {
    const [user] = await db.select({
      id: users.id, studentId: users.studentId, firstName: users.firstName,
      lastName: users.lastName, email: users.email, role: users.role,
      isVerified: users.isVerified, createdAt: users.createdAt,
    }).from(users).where(eq(users.id, userId)).limit(1)

    if (!user) throw new AppError(404, 'User not found.')
    return user
  },
}
