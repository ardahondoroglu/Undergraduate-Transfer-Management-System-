import { eq, and } from 'drizzle-orm'
import { db } from '../db/index.js'
import { applications } from '../db/schema/index.js'
import { AppError } from '../middleware/errorHandler.js'
import { writeAuditLog } from '../utils/auditLog.js'
import { notificationService } from './notificationService.js'

export const applicationService = {

  async create(userId: string, data: {
    transferType: 'INTERNAL' | 'EXTERNAL' | 'DOUBLE_MAJOR' | 'MINOR'
    previousUniversity: string
    currentProgram: string
    targetProgram: string
    currentGpa: string
    currentSemester: number
    targetSemester: number
    academicYear: string
    reasonForTransfer?: string
  }) {
    const [app] = await db.insert(applications).values({
      applicantId:        userId,
      transferType:       data.transferType,
      previousUniversity: data.previousUniversity,
      currentProgram:     data.currentProgram,
      targetProgram:      data.targetProgram,
      currentGpa:         data.currentGpa,
      currentSemester:    data.currentSemester,
      targetSemester:     data.targetSemester,
      academicYear:       data.academicYear,
      reasonForTransfer:  data.reasonForTransfer,
      status:             'DRAFT',
    }).returning()

    await writeAuditLog({ userId, action: 'APPLICATION_CREATED', entityType: 'APPLICATION', entityId: app.id })
    return app
  },

  async getAll(userId: string) {
    return db.select().from(applications)
      .where(eq(applications.applicantId, userId))
      .orderBy(applications.createdAt)
  },

  async getById(userId: string, applicationId: string) {
    const [app] = await db.select().from(applications)
      .where(and(eq(applications.id, applicationId), eq(applications.applicantId, userId)))
      .limit(1)
    if (!app) throw new AppError(404, 'Application not found.')
    return app
  },

  async update(userId: string, applicationId: string, data: Partial<{
    transferType: 'INTERNAL' | 'EXTERNAL' | 'DOUBLE_MAJOR' | 'MINOR'
    previousUniversity: string
    currentProgram: string
    targetProgram: string
    currentGpa: string
    currentSemester: number
    targetSemester: number
    academicYear: string
    reasonForTransfer: string
  }>) {
    const [app] = await db.select().from(applications)
      .where(and(eq(applications.id, applicationId), eq(applications.applicantId, userId)))
      .limit(1)
    if (!app) throw new AppError(404, 'Application not found.')
    const EDITABLE_STATUSES = ['DRAFT', 'SUBMITTED', 'RETURNED_FOR_CORRECTION']
    if (!EDITABLE_STATUSES.includes(app.status)) throw new AppError(400, 'This application cannot be edited in its current state.')

    const [updated] = await db.update(applications)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(applications.id, applicationId))
      .returning()

    await writeAuditLog({ userId, action: 'APPLICATION_UPDATED', entityType: 'APPLICATION', entityId: app.id })
    return updated
  },

  async submit(userId: string, applicationId: string) {
    const [app] = await db.select().from(applications)
      .where(and(eq(applications.id, applicationId), eq(applications.applicantId, userId)))
      .limit(1)
    if (!app) throw new AppError(404, 'Application not found.')
    if (app.status !== 'DRAFT') throw new AppError(400, 'Only draft applications can be submitted.')

    const [submitted] = await db.update(applications)
      .set({ status: 'SUBMITTED', submittedAt: new Date(), updatedAt: new Date() })
      .where(eq(applications.id, applicationId))
      .returning()

    await writeAuditLog({ userId, action: 'APPLICATION_SUBMITTED', entityType: 'APPLICATION', entityId: app.id })
    notificationService.create(userId, 'Başvurunuz Alındı', 'Transfer başvurunuz başarıyla sisteme iletildi. İnceleme sürecini başvuru sayfanızdan takip edebilirsiniz.').catch(() => {})
    return submitted
  },

  async withdraw(userId: string, applicationId: string) {
    const [app] = await db.select().from(applications)
      .where(and(eq(applications.id, applicationId), eq(applications.applicantId, userId)))
      .limit(1)
    if (!app) throw new AppError(404, 'Application not found.')
    if (!['DRAFT', 'SUBMITTED'].includes(app.status)) {
      throw new AppError(400, 'This application cannot be withdrawn.')
    }

    const [withdrawn] = await db.update(applications)
      .set({ status: 'WITHDRAWN', updatedAt: new Date() })
      .where(eq(applications.id, applicationId))
      .returning()

    await writeAuditLog({ userId, action: 'APPLICATION_WITHDRAWN', entityType: 'APPLICATION', entityId: app.id })
    notificationService.create(userId, 'Başvurunuz Geri Çekildi', 'Transfer başvurunuz sisteme geri çekildi.').catch(() => {})
    return withdrawn
  },
}
