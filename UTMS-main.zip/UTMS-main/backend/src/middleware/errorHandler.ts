import { Request, Response, NextFunction } from 'express'
import { ZodError } from 'zod'

export class AppError extends Error {
  constructor(public statusCode: number, message: string) {
    super(message)
    this.name = 'AppError'
  }
}

export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction) {
  if (err instanceof ZodError) {
    const errors: Record<string, string[]> = {}
    err.errors.forEach((e) => {
      const field = e.path.join('.')
      if (!errors[field]) errors[field] = []
      errors[field].push(e.message)
    })
    return res.status(400).json({ success: false, message: 'Validation failed', errors })
  }
  if (err instanceof AppError) {
    return res.status(err.statusCode).json({ success: false, message: err.message })
  }
  console.error('[Unhandled Error]', err)
  return res.status(500).json({ success: false, message: 'Internal server error' })
}
