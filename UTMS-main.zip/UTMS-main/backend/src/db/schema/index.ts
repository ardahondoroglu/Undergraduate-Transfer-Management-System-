import {
  pgTable,
  uuid,
  varchar,
  text,
  timestamp,
  boolean,
  numeric,
  integer,
  pgEnum,
} from 'drizzle-orm/pg-core'
import { relations } from 'drizzle-orm'

// ─── Enums ───────────────────────────────────────────────────────────────────

export const userRoleEnum = pgEnum('user_role', [
  'APPLICANT',
  'OIDB_STAFF',
  'YGK',
  'FACULTY_BOARD',
  'YDYO',
])

export const applicationStatusEnum = pgEnum('application_status', [
  'DRAFT',
  'SUBMITTED',
  'UNDER_REVIEW',
  'RETURNED_FOR_CORRECTION',
  'PENDING_LANGUAGE_CHECK',
  'PENDING_VERIFICATION',
  'ELIGIBLE',
  'INELIGIBLE',
  'UNDER_YGK_EVALUATION',
  'ACADEMICALLY_EVALUATED',
  'RANKING_IN_PROGRESS',
  'FORWARDED_TO_FACULTY',
  'APPROVED',
  'REJECTED',
  'WITHDRAWN',
  'FINALIZED',
])

export const transferTypeEnum = pgEnum('transfer_type', [
  'INTERNAL',
  'EXTERNAL',
  'DOUBLE_MAJOR',
  'MINOR',
])

export const documentTypeEnum = pgEnum('document_type', [
  'TRANSCRIPT',
  'COURSE_DESCRIPTION',
  'STUDENT_ID',
  'ENGLISH_CERTIFICATE',
  'PLACEMENT_RESULT',
  'OTHER',
])

export const documentStatusEnum = pgEnum('document_status', [
  'PENDING',
  'VERIFIED',
  'REJECTED',
])

export const equivalencyStatusEnum = pgEnum('equivalency_status', [
  'EQUIVALENT',
  'PARTIALLY_EQUIVALENT',
  'NOT_EQUIVALENT',
])

export const languageStatusEnum = pgEnum('language_status', [
  'NOT_CHECKED',
  'APPROVED',
  'EXAM_REQUIRED',
  'NOT_MET',
])

// ─── Tables ──────────────────────────────────────────────────────────────────

export const users = pgTable('users', {
  id:            uuid('id').primaryKey().defaultRandom(),
  studentId:     varchar('student_id', { length: 50 }).unique().notNull(),
  firstName:     varchar('first_name', { length: 50 }).notNull(),
  lastName:      varchar('last_name', { length: 50 }).notNull(),
  email:         varchar('email', { length: 255 }).unique().notNull(),
  passwordHash:  text('password_hash').notNull(),
  role:          userRoleEnum('role').default('APPLICANT').notNull(),
  isVerified:    boolean('is_verified').default(false).notNull(),
  createdAt:     timestamp('created_at').defaultNow().notNull(),
  updatedAt:     timestamp('updated_at').defaultNow().notNull(),
})

export const verificationTokens = pgTable('verification_tokens', {
  id:        uuid('id').primaryKey().defaultRandom(),
  userId:    uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  token:     text('token').unique().notNull(),
  type:      varchar('type', { length: 30 }).notNull(),
  expiresAt: timestamp('expires_at').notNull(),
  usedAt:    timestamp('used_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

export const applications = pgTable('applications', {
  id:                   uuid('id').primaryKey().defaultRandom(),
  applicantId:          uuid('applicant_id').references(() => users.id).notNull(),
  transferType:         transferTypeEnum('transfer_type').notNull(),
  previousUniversity:   varchar('previous_university', { length: 200 }).notNull(),
  currentProgram:       varchar('current_program', { length: 200 }).notNull(),
  targetProgram:        varchar('target_program', { length: 200 }).notNull(),
  currentGpa:           numeric('current_gpa', { precision: 4, scale: 2 }).notNull(),
  currentSemester:      integer('current_semester').notNull(),
  targetSemester:       integer('target_semester').notNull(),
  academicYear:         varchar('academic_year', { length: 20 }).notNull(),
  reasonForTransfer:    text('reason_for_transfer'),
  status:               applicationStatusEnum('status').default('DRAFT').notNull(),
  isEligible:           boolean('is_eligible'),
  eligibilityCheckedAt: timestamp('eligibility_checked_at'),
  submittedAt:          timestamp('submitted_at'),
  // YDYO fields
  languageStatus:       languageStatusEnum('language_status').default('NOT_CHECKED').notNull(),
  languageNotes:        text('language_notes'),
  // YGK evaluation fields
  evaluationScore:      numeric('evaluation_score', { precision: 5, scale: 2 }),
  evaluationNotes:      text('evaluation_notes'),
  // Ranking
  rankingPosition:      integer('ranking_position'),
  rankingJustification: text('ranking_justification'),
  createdAt:            timestamp('created_at').defaultNow().notNull(),
  updatedAt:            timestamp('updated_at').defaultNow().notNull(),
})

export const documents = pgTable('documents', {
  id:               uuid('id').primaryKey().defaultRandom(),
  applicationId:    uuid('application_id').references(() => applications.id, { onDelete: 'cascade' }).notNull(),
  uploadedBy:       uuid('uploaded_by').references(() => users.id).notNull(),
  type:             documentTypeEnum('type').notNull(),
  fileName:         varchar('file_name', { length: 255 }).notNull(),
  filePath:         text('file_path').notNull(),
  fileSize:         integer('file_size').notNull(),
  mimeType:         varchar('mime_type', { length: 100 }).notNull(),
  status:           documentStatusEnum('status').default('PENDING').notNull(),
  rejectionReason:  text('rejection_reason'),
  verifiedBy:       uuid('verified_by').references(() => users.id),
  verifiedAt:       timestamp('verified_at'),
  uploadedAt:       timestamp('uploaded_at').defaultNow().notNull(),
})

export const notifications = pgTable('notifications', {
  id:         uuid('id').primaryKey().defaultRandom(),
  userId:     uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  title:      varchar('title', { length: 200 }).notNull(),
  message:    text('message').notNull(),
  isRead:     boolean('is_read').default(false).notNull(),
  createdAt:  timestamp('created_at').defaultNow().notNull(),
})

export const courseEquivalencies = pgTable('course_equivalencies', {
  id:                    uuid('id').primaryKey().defaultRandom(),
  applicationId:         uuid('application_id').references(() => applications.id, { onDelete: 'cascade' }).notNull(),
  createdBy:             uuid('created_by').references(() => users.id).notNull(),
  previousCourseCode:    varchar('previous_course_code', { length: 20 }).notNull(),
  previousCourseName:    varchar('previous_course_name', { length: 200 }).notNull(),
  previousCourseCredits: numeric('previous_course_credits', { precision: 4, scale: 1 }).notNull(),
  targetCourseCode:      varchar('target_course_code', { length: 20 }).notNull(),
  targetCourseName:      varchar('target_course_name', { length: 200 }).notNull(),
  targetCourseCredits:   numeric('target_course_credits', { precision: 4, scale: 1 }).notNull(),
  status:                equivalencyStatusEnum('status').notNull(),
  notes:                 text('notes'),
  createdAt:             timestamp('created_at').defaultNow().notNull(),
  updatedAt:             timestamp('updated_at').defaultNow().notNull(),
})

export const auditLogs = pgTable('audit_logs', {
  id:           uuid('id').primaryKey().defaultRandom(),
  userId:       uuid('user_id').references(() => users.id),
  action:       varchar('action', { length: 100 }).notNull(),
  entityType:   varchar('entity_type', { length: 50 }).notNull(),
  entityId:     uuid('entity_id'),
  oldValue:     text('old_value'),
  newValue:     text('new_value'),
  ipAddress:    varchar('ip_address', { length: 45 }),
  userAgent:    text('user_agent'),
  createdAt:    timestamp('created_at').defaultNow().notNull(),
})

// ─── Relations ───────────────────────────────────────────────────────────────

export const usersRelations = relations(users, ({ many }) => ({
  applications:        many(applications),
  notifications:       many(notifications),
  verificationTokens:  many(verificationTokens),
}))

export const applicationsRelations = relations(applications, ({ one, many }) => ({
  applicant: one(users, { fields: [applications.applicantId], references: [users.id] }),
  documents: many(documents),
}))

export const documentsRelations = relations(documents, ({ one }) => ({
  application: one(applications, { fields: [documents.applicationId], references: [applications.id] }),
  uploadedBy:  one(users, { fields: [documents.uploadedBy], references: [users.id] }),
}))
