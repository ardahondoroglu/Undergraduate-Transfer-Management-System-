/**
 * Creates test staff accounts for ÖİDB and YGK.
 * Run: npx tsx src/scripts/createStaffUser.ts
 */
import 'dotenv/config'
import { db } from '../db/index.js'
import { users } from '../db/schema/index.js'
import { eq } from 'drizzle-orm'
import { hash } from '@node-rs/argon2'

const ACCOUNTS = [
  {
    email:      'oidb@iyte.edu.tr',
    password:   'Staff1234!',
    studentId:  'OIDB001',
    firstName:  'ÖİDB',
    lastName:   'Personel',
    role:       'OIDB_STAFF' as const,
  },
  {
    email:      'ygk@iyte.edu.tr',
    password:   'Ygk1234!',
    studentId:  'YGK001',
    firstName:  'YGK',
    lastName:   'Üyesi',
    role:       'YGK' as const,
  },
  {
    email:      'ydyo@iyte.edu.tr',
    password:   'Ydyo1234!',
    studentId:  'YDYO001',
    firstName:  'YDYO',
    lastName:   'Personel',
    role:       'YDYO' as const,
  },
  {
    email:      'faculty@iyte.edu.tr',
    password:   'Faculty1234!',
    studentId:  'FAC001',
    firstName:  'Fakülte',
    lastName:   'Kurulu',
    role:       'FACULTY_BOARD' as const,
  },
]

async function main() {
  for (const acc of ACCOUNTS) {
    const passwordHash = await hash(acc.password)
    const existing = await db.select({ id: users.id })
      .from(users).where(eq(users.email, acc.email)).limit(1)

    if (existing.length > 0) {
      await db.update(users)
        .set({ passwordHash, role: acc.role, isVerified: true })
        .where(eq(users.email, acc.email))
      console.log(`✅ Updated: ${acc.email}`)
    } else {
      await db.insert(users).values({
        studentId:    acc.studentId,
        firstName:    acc.firstName,
        lastName:     acc.lastName,
        email:        acc.email,
        passwordHash,
        role:         acc.role,
        isVerified:   true,
      })
      console.log(`✅ Created: ${acc.email}`)
    }
    console.log(`   Password: ${acc.password}`)
  }
  process.exit(0)
}

main().catch(e => { console.error(e); process.exit(1) })
