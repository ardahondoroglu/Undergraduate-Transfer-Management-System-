# UTMS — Undergraduate Transfer Management System

> IZTECH CENG316 Group 12 Project

Centralized web platform that digitizes and automates the entire undergraduate transfer process at IZTECH.

---

## Tech Stack

| Layer      | Technology                          |
|------------|-------------------------------------|
| Frontend   | React 18 + Vite + TypeScript        |
| State      | Zustand                             |
| Backend    | Node.js + Express + TypeScript      |
| ORM        | Drizzle ORM                         |
| Database   | PostgreSQL                          |
| Auth       | JWT (JSON Web Tokens)               |
| File Store | Local / Cloud Storage               |

---

## Project Structure

```
utms/
├── frontend/          # React + Vite SPA
│   └── src/
│       ├── components/   # Shared UI & layout components
│       ├── pages/        # Route-level page components
│       ├── store/        # Zustand global state
│       ├── api/          # Axios API client & endpoints
│       └── types/        # Shared TypeScript types
├── backend/           # Node.js + Express API
│   └── src/
│       ├── controllers/  # Request handlers
│       ├── services/     # Business logic
│       ├── routes/       # Express routers
│       ├── middleware/   # Auth, validation, error handling
│       └── db/           # Drizzle schema & migrations
└── package.json       # Root workspace config
```

---

## Getting Started

### Prerequisites
- Node.js >= 18
- PostgreSQL >= 15
- npm >= 9

### Setup

```bash
# 1. Clone the repo
git clone https://github.com/UTMSG12/UTMS.git
cd utms

# 2. Install all dependencies
npm install

# 3. Set up environment variables
cp frontend/.env.example frontend/.env
cp backend/.env.example backend/.env
# Edit both .env files with your values

# 4. Run database migrations
cd backend && npm run db:migrate

# 5. Start dev servers (both frontend & backend)
npm run dev
```

Frontend runs at: http://localhost:5173  
Backend API runs at: http://localhost:3000

---

## Actors & Use Cases

| Actor        | Role                                        |
|--------------|---------------------------------------------|
| Applicant    | Submits and tracks transfer applications    |
| ÖİDB Staff   | Reviews documents, routes applications      |
| YGK          | Academic evaluation & course equivalency    |
| Faculty Board| Final approval of transfer decisions        |
| YDYO         | English proficiency document evaluation     |

---

## Group Members

| Name                  | Student ID  | Role              |
|-----------------------|-------------|-------------------|
| Abdullah Semih Çetin  | 290201093   | Project Manager   |
| Eren Tetik            | 280201013   | Frontend          |
| Eray Özen             | 300201056   | Backend           |
| Sercan Utku Temelci   | 290201087   | Database / Backend|
| Vedat Demir           | 280201047   | Frontend          |
