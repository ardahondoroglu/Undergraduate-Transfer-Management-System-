/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // IZTECH brand colors
        iztech: {
          red: '#8B1A1A',
          dark: '#1a1a2e',
          gray: '#6B7280',
        },
        primary: {
          50:  '#fef2f2',
          100: '#fee2e2',
          500: '#8B1A1A',
          600: '#7a1717',
          700: '#6b1414',
          900: '#1a0505',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
