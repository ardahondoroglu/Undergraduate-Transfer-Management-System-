import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import {
  ArrowLeft, FileText, Download, CheckCircle, XCircle, ChevronDown,
} from 'lucide-react'
import { staffApi, type StaffApplication, type StaffDocument } from '@/api/staff'
import LoadingSpinner from '@/components/ui/LoadingSpinner'

// ─── Constants ───────────────────────────────────────────────────────────────

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  DRAFT:                   { label: 'Taslak',                color: 'bg-gray-100 text-gray-600' },
  SUBMITTED:               { label: 'Gönderildi',            color: 'bg-blue-100 text-blue-700' },
  UNDER_REVIEW:            { label: 'İnceleniyor',           color: 'bg-yellow-100 text-yellow-700' },
  RETURNED_FOR_CORRECTION: { label: 'Düzeltme Gerekli',      color: 'bg-orange-100 text-orange-700' },
  PENDING_VERIFICATION:    { label: 'Doğrulama Bekliyor',    color: 'bg-purple-100 text-purple-700' },
  PENDING_LANGUAGE_CHECK:  { label: 'Dil Kontrolü Bekliyor', color: 'bg-teal-100 text-teal-700' },
  ELIGIBLE:                { label: 'Uygun',                 color: 'bg-green-100 text-green-700' },
  INELIGIBLE:              { label: 'Uygun Değil',           color: 'bg-red-100 text-red-700' },
  UNDER_YGK_EVALUATION:    { label: 'YGK Değerlendirmesi',   color: 'bg-indigo-100 text-indigo-700' },
  APPROVED:                { label: 'Onaylandı',             color: 'bg-green-100 text-green-800' },
  REJECTED:                { label: 'Reddedildi',            color: 'bg-red-100 text-red-800' },
  WITHDRAWN:               { label: 'Geri Çekildi',          color: 'bg-gray-100 text-gray-500' },
  FINALIZED:               { label: 'Sonuçlandırıldı',       color: 'bg-gray-200 text-gray-700' },
}

const TRANSFER_LABELS: Record<string, string> = {
  INTERNAL: 'Kurum İçi', EXTERNAL: 'Kurum Dışı',
  DOUBLE_MAJOR: 'Çift Anadal', MINOR: 'Yandal',
}

const DOC_TYPE_LABELS: Record<string, string> = {
  TRANSCRIPT: 'Transkript', COURSE_DESCRIPTION: 'Ders İçerikleri',
  STUDENT_ID: 'Öğrenci Kimliği', ENGLISH_CERTIFICATE: 'İngilizce Belgesi',
  PLACEMENT_RESULT: 'Yerleştirme Sonucu', OTHER: 'Diğer',
}

// Status transitions ÖİDB can make
const NEXT_STATUSES: Record<string, { value: string; label: string; needsNote?: boolean }[]> = {
  SUBMITTED: [
    { value: 'UNDER_REVIEW', label: 'İncelemeye Al' },
  ],
  UNDER_REVIEW: [
    { value: 'RETURNED_FOR_CORRECTION', label: 'Düzeltmeye İade Et', needsNote: true },
    { value: 'PENDING_VERIFICATION',    label: 'Doğrulamaya Gönder' },
    { value: 'PENDING_LANGUAGE_CHECK',  label: 'YDYO\'ya Yönlendir' },
    { value: 'ELIGIBLE',               label: 'Uygun İşaretle' },
    { value: 'INELIGIBLE',             label: 'Uygun Değil İşaretle', needsNote: true },
  ],
  RETURNED_FOR_CORRECTION: [
    { value: 'UNDER_REVIEW', label: 'Tekrar İncelemeye Al' },
  ],
  PENDING_VERIFICATION: [
    { value: 'ELIGIBLE',    label: 'Uygun İşaretle' },
    { value: 'INELIGIBLE',  label: 'Uygun Değil İşaretle', needsNote: true },
    { value: 'UNDER_REVIEW', label: 'İncelemeye Geri Al' },
  ],
}

// ─── Component ───────────────────────────────────────────────────────────────

export default function StaffApplicationDetailPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()

  const [app, setApp] = useState<StaffApplication | null>(null)
  const [docs, setDocs] = useState<StaffDocument[]>([])
  const [loading, setLoading] = useState(true)

  // Status update panel
  const [showStatusPanel, setShowStatusPanel] = useState(false)
  const [selectedStatus, setSelectedStatus] = useState('')
  const [note, setNote] = useState('')
  const [updatingStatus, setUpdatingStatus] = useState(false)

  // Document action states
  const [docAction, setDocAction] = useState<{ id: string; type: 'reject' } | null>(null)
  const [rejectReason, setRejectReason] = useState('')
  const [processingDoc, setProcessingDoc] = useState<string | null>(null)

  useEffect(() => {
    if (!id) return
    Promise.all([staffApi.getApplication(id), staffApi.getDocuments(id)])
      .then(([appRes, docRes]) => {
        setApp(appRes.data.data!)
        setDocs(docRes.data.data || [])
      })
      .catch(() => toast.error('Başvuru yüklenemedi.'))
      .finally(() => setLoading(false))
  }, [id])

  // ── Status update ──────────────────────────────────────────────────────────

  const handleStatusUpdate = async () => {
    if (!id || !selectedStatus) return
    try {
      setUpdatingStatus(true)
      const res = await staffApi.updateStatus(id, selectedStatus, note || undefined)
      setApp(prev => prev ? { ...prev, status: res.data.data!.status } : prev)
      setShowStatusPanel(false)
      setSelectedStatus('')
      setNote('')
      toast.success('Durum güncellendi.')
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Güncelleme başarısız.')
    } finally {
      setUpdatingStatus(false)
    }
  }

  // ── Document actions ───────────────────────────────────────────────────────

  const handleVerify = async (docId: string) => {
    try {
      setProcessingDoc(docId)
      const res = await staffApi.verifyDocument(docId)
      setDocs(prev => prev.map(d => d.id === docId ? res.data.data! : d))
      toast.success('Belge doğrulandı.')
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'İşlem başarısız.')
    } finally {
      setProcessingDoc(null)
    }
  }

  const handleReject = async () => {
    if (!docAction) return
    if (!rejectReason.trim()) { toast.error('Red gerekçesi zorunludur.'); return }
    try {
      setProcessingDoc(docAction.id)
      const res = await staffApi.rejectDocument(docAction.id, rejectReason)
      setDocs(prev => prev.map(d => d.id === docAction.id ? res.data.data! : d))
      setDocAction(null)
      setRejectReason('')
      toast.success('Belge reddedildi.')
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'İşlem başarısız.')
    } finally {
      setProcessingDoc(null)
    }
  }

  // ── Render ─────────────────────────────────────────────────────────────────

  if (loading) return (
    <div className="flex items-center justify-center h-48"><LoadingSpinner size="lg" /></div>
  )
  if (!app) return (
    <div className="text-center text-gray-400 py-16"><p>Başvuru bulunamadı.</p></div>
  )

  const statusInfo = STATUS_LABELS[app.status] || { label: app.status, color: 'bg-gray-100 text-gray-600' }
  const nextStatuses = NEXT_STATUSES[app.status] || []
  const selectedStatusObj = nextStatuses.find(s => s.value === selectedStatus)

  return (
    <div className="max-w-3xl mx-auto space-y-5">

      {/* Header */}
      <div className="flex items-center justify-between">
        <button onClick={() => navigate('/staff/applications')}
          className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-900">
          <ArrowLeft size={16} /> Başvurular
        </button>
        {nextStatuses.length > 0 && (
          <button
            onClick={() => setShowStatusPanel(!showStatusPanel)}
            className="flex items-center gap-1.5 text-sm bg-gray-900 text-white px-4 py-2 rounded-lg hover:bg-gray-800"
          >
            Durum Güncelle <ChevronDown size={14} />
          </button>
        )}
      </div>

      {/* Status update panel */}
      {showStatusPanel && (
        <div className="card p-5 border-2 border-gray-900">
          <h3 className="font-semibold text-gray-900 mb-3">Durum Güncelle</h3>
          <div className="flex flex-wrap gap-2 mb-3">
            {nextStatuses.map(s => (
              <button
                key={s.value}
                onClick={() => { setSelectedStatus(s.value); setNote('') }}
                className={`text-sm px-3 py-1.5 rounded-lg border transition-colors ${
                  selectedStatus === s.value
                    ? 'bg-gray-900 text-white border-gray-900'
                    : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
          {selectedStatus && (
            <>
              {selectedStatusObj?.needsNote && (
                <textarea
                  value={note}
                  onChange={e => setNote(e.target.value)}
                  rows={3}
                  className="input-field resize-none mb-3"
                  placeholder={selectedStatus === 'RETURNED_FOR_CORRECTION'
                    ? 'Düzeltme gerekçesini yazın (öğrenciye iletilecek)...'
                    : 'Gerekçe yazın (opsiyonel)...'}
                />
              )}
              <div className="flex gap-2">
                <button
                  onClick={() => { setShowStatusPanel(false); setSelectedStatus(''); setNote('') }}
                  className="flex-1 border border-gray-300 text-gray-700 py-2 rounded-lg text-sm hover:bg-gray-50"
                >
                  İptal
                </button>
                <button
                  onClick={handleStatusUpdate}
                  disabled={updatingStatus || (selectedStatusObj?.needsNote && !note.trim())}
                  className="flex-1 bg-gray-900 text-white py-2 rounded-lg text-sm hover:bg-gray-800 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {updatingStatus ? <LoadingSpinner size="sm" /> : null}
                  Güncelle
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {/* Application Info */}
      <div className="card p-5">
        <div className="flex items-start justify-between mb-4">
          <div>
            <p className="text-xs text-gray-500 mb-1">
              {TRANSFER_LABELS[app.transferType]} • {app.academicYear}
            </p>
            <h2 className="text-lg font-semibold text-gray-900">{app.targetProgram}</h2>
            <p className="text-sm text-gray-500">{app.previousUniversity} — {app.currentProgram}</p>
          </div>
          <span className={`text-xs font-medium px-3 py-1 rounded-full ${statusInfo.color}`}>
            {statusInfo.label}
          </span>
        </div>

        {/* Applicant info */}
        <div className="bg-gray-50 rounded-lg p-3 mb-4">
          <p className="text-xs text-gray-500 mb-1">Başvuran</p>
          <p className="text-sm font-medium text-gray-900">
            {app.applicantFirstName} {app.applicantLastName}
            <span className="font-normal text-gray-500"> — #{app.applicantStudentId}</span>
          </p>
          <p className="text-xs text-gray-500">{app.applicantEmail}</p>
        </div>

        <div className="grid grid-cols-3 gap-4 pt-3 border-t border-gray-100">
          <div>
            <p className="text-xs text-gray-400">GPA</p>
            <p className="text-sm font-medium">{app.currentGpa}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400">Mevcut Dönem</p>
            <p className="text-sm font-medium">{app.currentSemester}. Dönem</p>
          </div>
          <div>
            <p className="text-xs text-gray-400">Hedef Dönem</p>
            <p className="text-sm font-medium">{app.targetSemester}. Dönem</p>
          </div>
        </div>

        {app.reasonForTransfer && (
          <div className="mt-4 pt-3 border-t border-gray-100">
            <p className="text-xs text-gray-400 mb-1">Geçiş Gerekçesi</p>
            <p className="text-sm text-gray-700">{app.reasonForTransfer}</p>
          </div>
        )}

        {app.submittedAt && (
          <p className="text-xs text-gray-400 mt-3">
            Gönderildi: {new Date(app.submittedAt).toLocaleString('tr-TR')}
          </p>
        )}
      </div>

      {/* Documents — VD.1 */}
      <div className="card p-5">
        <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <FileText size={16} /> Belgeler
        </h3>

        {docs.length === 0 ? (
          <p className="text-sm text-gray-400 text-center py-4">Henüz belge yüklenmemiş.</p>
        ) : (
          <div className="space-y-3">
            {docs.map(doc => (
              <div key={doc.id} className="border border-gray-200 rounded-lg p-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{doc.fileName}</p>
                    <p className="text-xs text-gray-400">
                      {DOC_TYPE_LABELS[doc.type]} • {(doc.fileSize / 1024).toFixed(0)} KB
                    </p>
                    {doc.status === 'REJECTED' && doc.rejectionReason && (
                      <p className="text-xs text-red-600 mt-1">Red: {doc.rejectionReason}</p>
                    )}
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    {/* Status badge */}
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      doc.status === 'VERIFIED' ? 'bg-green-100 text-green-700' :
                      doc.status === 'REJECTED' ? 'bg-red-100 text-red-700' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {doc.status === 'VERIFIED' ? 'Doğrulandı' :
                       doc.status === 'REJECTED' ? 'Reddedildi' : 'Beklemede'}
                    </span>

                    {/* Download */}
                    <a href={staffApi.getDownloadUrl(doc.id)} target="_blank" rel="noreferrer"
                      className="text-gray-400 hover:text-gray-700 p-1">
                      <Download size={14} />
                    </a>

                    {/* Verify / Reject — only for PENDING */}
                    {doc.status === 'PENDING' && (
                      <>
                        <button
                          onClick={() => handleVerify(doc.id)}
                          disabled={processingDoc === doc.id}
                          title="Doğrula"
                          className="text-green-600 hover:text-green-800 p-1 disabled:opacity-50"
                        >
                          {processingDoc === doc.id ? <LoadingSpinner size="sm" /> : <CheckCircle size={16} />}
                        </button>
                        <button
                          onClick={() => { setDocAction({ id: doc.id, type: 'reject' }); setRejectReason('') }}
                          disabled={processingDoc === doc.id}
                          title="Reddet"
                          className="text-red-500 hover:text-red-700 p-1 disabled:opacity-50"
                        >
                          <XCircle size={16} />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Reject reason modal */}
      {docAction && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-sm w-full mx-4 shadow-xl">
            <h3 className="font-semibold text-gray-900 mb-2">Belgeyi Reddet</h3>
            <p className="text-sm text-gray-500 mb-3">Red gerekçesini yazın. Başvurana bildirim gönderilecektir.</p>
            <textarea
              value={rejectReason}
              onChange={e => setRejectReason(e.target.value)}
              rows={3}
              className="input-field resize-none mb-4"
              placeholder="Örn: Belge eksik/okunamıyor, son 3 ay içinde alınmamış..."
              autoFocus
            />
            <div className="flex gap-3">
              <button
                onClick={() => { setDocAction(null); setRejectReason('') }}
                className="flex-1 border border-gray-300 text-gray-700 py-2 rounded-lg text-sm hover:bg-gray-50"
              >
                İptal
              </button>
              <button
                onClick={handleReject}
                disabled={!rejectReason.trim() || processingDoc !== null}
                className="flex-1 bg-red-600 text-white py-2 rounded-lg text-sm hover:bg-red-700 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {processingDoc ? <LoadingSpinner size="sm" /> : null}
                Reddet
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
