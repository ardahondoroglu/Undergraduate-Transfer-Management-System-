import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { ArrowLeft, CheckCircle, XCircle } from 'lucide-react'
import { facultyApi } from '@/api/faculty'
import type { StaffApplication } from '@/api/staff'
import LoadingSpinner from '@/components/ui/LoadingSpinner'

// ─── Constants ────────────────────────────────────────────────────────────────

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  FORWARDED_TO_FACULTY: { label: 'Karar Bekliyor',  color: 'bg-sky-100 text-sky-700' },
  APPROVED:             { label: 'Onaylandı',       color: 'bg-green-100 text-green-700' },
  REJECTED:             { label: 'Reddedildi',      color: 'bg-red-100 text-red-700' },
  FINALIZED:            { label: 'Sonuçlandı',      color: 'bg-gray-100 text-gray-600' },
}

const TRANSFER_LABELS: Record<string, string> = {
  INTERNAL: 'Kurum İçi', EXTERNAL: 'Kurum Dışı',
  DOUBLE_MAJOR: 'Çift Anadal', MINOR: 'Yandal',
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function FacultyApplicationDetailPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()

  const [app, setApp] = useState<StaffApplication | null>(null)
  const [loading, setLoading] = useState(true)

  // Decision panel
  const [decision, setDecision] = useState<'APPROVED' | 'REJECTED' | ''>('')
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!id) return
    facultyApi.getApplication(id)
      .then(res => setApp(res.data.data))
      .catch(() => toast.error('Başvuru yüklenemedi.'))
      .finally(() => setLoading(false))
  }, [id])

  const handleDecision = async () => {
    if (!id || !decision) return
    if (decision === 'REJECTED' && !note.trim()) {
      toast.error('Ret gerekçesi zorunludur.')
      return
    }
    setSaving(true)
    try {
      const res = await facultyApi.updateStatus(id, decision, note || undefined)
      setApp(res.data.data)
      toast.success(decision === 'APPROVED' ? 'Başvuru onaylandı.' : 'Başvuru reddedildi.')
      setDecision('')
      setNote('')
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Bir hata oluştu.')
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return <div className="flex items-center justify-center h-64"><LoadingSpinner size="lg" /></div>
  }
  if (!app) {
    return <div className="card p-10 text-center text-gray-400"><p>Başvuru bulunamadı.</p></div>
  }

  const statusInfo = STATUS_LABELS[app.status] || { label: app.status, color: 'bg-gray-100 text-gray-600' }
  const isPending  = app.status === 'FORWARDED_TO_FACULTY'

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => navigate('/faculty/applications')} className="p-1.5 rounded-lg hover:bg-gray-100">
          <ArrowLeft size={18} className="text-gray-500" />
        </button>
        <div>
          <h2 className="text-lg font-semibold text-gray-900">
            {app.applicantFirstName} {app.applicantLastName}
          </h2>
          <p className="text-sm text-gray-400">#{app.applicantStudentId} · {app.applicantEmail}</p>
        </div>
        <span className={`ml-auto text-xs font-medium px-2.5 py-1 rounded-full ${statusInfo.color}`}>
          {statusInfo.label}
        </span>
      </div>

      {/* Application Info */}
      <div className="card p-5">
        <h3 className="text-sm font-semibold text-gray-700 mb-4">Başvuru Bilgileri</h3>
        <div className="grid grid-cols-2 gap-x-8 gap-y-3 text-sm">
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Transfer Türü</p>
            <p className="text-gray-800 font-medium">{TRANSFER_LABELS[app.transferType]}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Akademik Yıl</p>
            <p className="text-gray-800 font-medium">{app.academicYear}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Önceki Üniversite</p>
            <p className="text-gray-800 font-medium">{app.previousUniversity}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Mevcut Program</p>
            <p className="text-gray-800 font-medium">{app.currentProgram}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Hedef Program</p>
            <p className="text-gray-800 font-medium">{app.targetProgram}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-0.5">GPA</p>
            <p className="text-gray-800 font-medium">{app.currentGpa}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Mevcut Dönem</p>
            <p className="text-gray-800 font-medium">{app.currentSemester}. dönem</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Hedef Dönem</p>
            <p className="text-gray-800 font-medium">{app.targetSemester}. dönem</p>
          </div>

          {(app as any).evaluationScore && (
            <div>
              <p className="text-xs text-gray-400 mb-0.5">YGK Değerlendirme Puanı</p>
              <p className="text-gray-800 font-medium">{(app as any).evaluationScore}</p>
            </div>
          )}
          {(app as any).evaluationNotes && (
            <div className="col-span-2">
              <p className="text-xs text-gray-400 mb-0.5">YGK Değerlendirme Notu</p>
              <p className="text-gray-800">{(app as any).evaluationNotes}</p>
            </div>
          )}
          {(app as any).rankingPosition && (
            <div>
              <p className="text-xs text-gray-400 mb-0.5">Sıralama Pozisyonu</p>
              <p className="text-gray-800 font-medium">#{(app as any).rankingPosition}</p>
            </div>
          )}
          {app.reasonForTransfer && (
            <div className="col-span-2">
              <p className="text-xs text-gray-400 mb-0.5">Transfer Gerekçesi</p>
              <p className="text-gray-800">{app.reasonForTransfer}</p>
            </div>
          )}
        </div>
      </div>

      {/* FB.2 — Decision panel */}
      {isPending && (
        <div className="card p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">Karar Ver</h3>

          <div className="flex gap-3 mb-4">
            <button
              onClick={() => setDecision('APPROVED')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg border-2 font-medium text-sm transition-all ${
                decision === 'APPROVED'
                  ? 'border-green-500 bg-green-50 text-green-700'
                  : 'border-gray-200 text-gray-500 hover:border-gray-300'
              }`}
            >
              <CheckCircle size={18} />
              Onayla
            </button>
            <button
              onClick={() => setDecision('REJECTED')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg border-2 font-medium text-sm transition-all ${
                decision === 'REJECTED'
                  ? 'border-red-500 bg-red-50 text-red-700'
                  : 'border-gray-200 text-gray-500 hover:border-gray-300'
              }`}
            >
              <XCircle size={18} />
              Reddet
            </button>
          </div>

          {decision && (
            <div className="space-y-3">
              <div>
                <label className="label">
                  {decision === 'REJECTED' ? 'Ret Gerekçesi (zorunlu)' : 'Not (opsiyonel)'}
                </label>
                <textarea
                  value={note}
                  onChange={e => setNote(e.target.value)}
                  rows={3}
                  placeholder={
                    decision === 'REJECTED'
                      ? 'Ret gerekçesini yazın...'
                      : 'Onay notu (opsiyonel)...'
                  }
                  className="input-field resize-none"
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => { setDecision(''); setNote('') }}
                  className="flex-1 border border-gray-300 text-gray-700 py-2 rounded-lg text-sm hover:bg-gray-50"
                >
                  İptal
                </button>
                <button
                  onClick={handleDecision}
                  disabled={saving}
                  className={`flex-1 text-white py-2 rounded-lg text-sm disabled:opacity-50 flex items-center justify-center gap-2 ${
                    decision === 'APPROVED'
                      ? 'bg-green-600 hover:bg-green-700'
                      : 'bg-red-600 hover:bg-red-700'
                  }`}
                >
                  {saving ? <LoadingSpinner size="sm" /> : null}
                  {decision === 'APPROVED' ? 'Onayla' : 'Reddet'}
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Finalized state */}
      {!isPending && (
        <div className={`card p-5 border-2 ${app.status === 'APPROVED' ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}`}>
          <div className="flex items-center gap-2">
            {app.status === 'APPROVED'
              ? <CheckCircle size={20} className="text-green-600" />
              : <XCircle size={20} className="text-red-600" />
            }
            <p className={`text-sm font-medium ${app.status === 'APPROVED' ? 'text-green-700' : 'text-red-700'}`}>
              Bu başvuru {app.status === 'APPROVED' ? 'onaylanmıştır' : 'reddedilmiştir'}.
            </p>
          </div>
        </div>
      )}
    </div>
  )
}
