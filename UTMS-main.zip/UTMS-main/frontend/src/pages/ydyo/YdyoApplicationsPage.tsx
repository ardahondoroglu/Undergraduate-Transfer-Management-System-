import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { ChevronRight, Search } from 'lucide-react'
import { ydyoApi } from '@/api/ydyo'
import type { StaffApplication } from '@/api/staff'
import LoadingSpinner from '@/components/ui/LoadingSpinner'

const LANGUAGE_STATUS_LABELS: Record<string, { label: string; color: string }> = {
  NOT_CHECKED:   { label: 'Kontrol Edilmedi',  color: 'bg-gray-100 text-gray-600' },
  APPROVED:      { label: 'Onaylandı',         color: 'bg-green-100 text-green-700' },
  EXAM_REQUIRED: { label: 'Sınav Gerekli',     color: 'bg-yellow-100 text-yellow-700' },
  NOT_MET:       { label: 'Karşılanamadı',     color: 'bg-red-100 text-red-700' },
}

const TRANSFER_LABELS: Record<string, string> = {
  INTERNAL: 'Kurum İçi', EXTERNAL: 'Kurum Dışı',
  DOUBLE_MAJOR: 'Çift Anadal', MINOR: 'Yandal',
}

export default function YdyoApplicationsPage() {
  const navigate = useNavigate()
  const [applications, setApplications] = useState<StaffApplication[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    ydyoApi.getApplications()
      .then(res => setApplications(res.data.data || []))
      .catch(() => toast.error('Başvurular yüklenemedi.'))
      .finally(() => setLoading(false))
  }, [])

  const filtered = applications.filter(app => {
    if (!search) return true
    const q = search.toLowerCase()
    return (
      app.applicantFirstName.toLowerCase().includes(q) ||
      app.applicantLastName.toLowerCase().includes(q) ||
      app.applicantStudentId.toLowerCase().includes(q) ||
      app.targetProgram.toLowerCase().includes(q)
    )
  })

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900">İngilizce Yeterlilik Kontrolü</h2>
        <p className="text-sm text-gray-500 mt-1">
          Dil yeterlilik kontrolü bekleyen başvuruları değerlendirin.
        </p>
      </div>

      <div className="mb-5">
        <div className="relative max-w-sm">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Ad, öğrenci no, program..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="input-field pl-9"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48"><LoadingSpinner size="lg" /></div>
      ) : filtered.length === 0 ? (
        <div className="card p-10 text-center text-gray-400">
          <p className="text-sm">Dil kontrolü bekleyen başvuru bulunmuyor.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(app => {
            const langInfo = LANGUAGE_STATUS_LABELS[(app as any).languageStatus || 'NOT_CHECKED']
            return (
              <div
                key={app.id}
                onClick={() => navigate(`/ydyo/applications/${app.id}`)}
                className="card p-4 cursor-pointer hover:shadow-md transition-shadow flex items-center gap-4"
              >
                <div className="w-10 h-10 bg-teal-50 rounded-full flex items-center justify-center text-sm font-semibold text-teal-600 flex-shrink-0">
                  {app.applicantFirstName[0]}{app.applicantLastName[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-gray-900">
                      {app.applicantFirstName} {app.applicantLastName}
                    </p>
                    <span className="text-xs text-gray-400">#{app.applicantStudentId}</span>
                  </div>
                  <p className="text-sm text-gray-500 truncate">
                    {TRANSFER_LABELS[app.transferType]} • {app.targetProgram}
                  </p>
                  <p className="text-xs text-gray-400">
                    {app.previousUniversity} • {app.academicYear}
                  </p>
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${langInfo.color}`}>
                    {langInfo.label}
                  </span>
                  <ChevronRight size={16} className="text-gray-400" />
                </div>
              </div>
            )
          })}
        </div>
      )}
      <p className="text-xs text-gray-400 mt-4 text-right">{filtered.length} başvuru</p>
    </div>
  )
}
