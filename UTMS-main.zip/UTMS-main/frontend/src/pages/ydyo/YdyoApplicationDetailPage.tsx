import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { ArrowLeft, ChevronDown } from 'lucide-react'
import { ydyoApi, type LanguageStatus } from '@/api/ydyo'
import type { StaffApplication } from '@/api/staff'
import LoadingSpinner from '@/components/ui/LoadingSpinner'

// ─── Constants ────────────────────────────────────────────────────────────────

const APP_STATUS_LABELS: Record<string, { label: string; color: string }> = {
  PENDING_LANGUAGE_CHECK: { label: 'Dil Kontrolü Bekliyor', color: 'bg-yellow-100 text-yellow-700' },
  ELIGIBLE:               { label: 'Uygun',                 color: 'bg-green-100 text-green-700' },
  INELIGIBLE:             { label: 'Uygun Değil',           color: 'bg-red-100 text-red-700' },
}

const LANG_STATUS_LABELS: Record<string, { label: string; color: string }> = {
  NOT_CHECKED:   { label: 'Kontrol Edilmedi',  color: 'bg-gray-100 text-gray-600' },
  APPROVED:      { label: 'Onaylandı',         color: 'bg-green-100 text-green-700' },
  EXAM_REQUIRED: { label: 'Sınav Gerekli',     color: 'bg-yellow-100 text-yellow-700' },
  NOT_MET:       { label: 'Karşılanamadı',     color: 'bg-red-100 text-red-700' },
}

const TRANSFER_LABELS: Record<string, string> = {
  INTERNAL: 'Kurum İçi', EXTERNAL: 'Kurum Dışı',
  DOUBLE_MAJOR: 'Çift Anadal', MINOR: 'Yandal',
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function YdyoApplicationDetailPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()

  const [app, setApp] = useState<StaffApplication | null>(null)
  const [loading, setLoading] = useState(true)

  // SFL.02 — evaluate panel
  const [evalOpen, setEvalOpen] = useState(false)
  const [selectedLangStatus, setSelectedLangStatus] = useState<LanguageStatus>('APPROVED')
  const [evalNotes, setEvalNotes] = useState('')
  const [evalLoading, setEvalLoading] = useState(false)

  // SFL.03 — exam result panel
  const [examOpen, setExamOpen] = useState(false)
  const [examPassed, setExamPassed] = useState<boolean>(true)
  const [examScore, setExamScore] = useState('')
  const [examNotes, setExamNotes] = useState('')
  const [examLoading, setExamLoading] = useState(false)

  useEffect(() => {
    if (!id) return
    ydyoApi.getApplication(id)
      .then(res => setApp(res.data.data))
      .catch(() => toast.error('Başvuru yüklenemedi.'))
      .finally(() => setLoading(false))
  }, [id])

  const handleEvaluate = async () => {
    if (!id) return
    setEvalLoading(true)
    try {
      const res = await ydyoApi.evaluate(id, selectedLangStatus, evalNotes || undefined)
      setApp(res.data.data)
      toast.success('Dil yeterlilik değerlendirmesi kaydedildi.')
      setEvalOpen(false)
      setEvalNotes('')
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Bir hata oluştu.')
    } finally {
      setEvalLoading(false)
    }
  }

  const handleExamResult = async () => {
    if (!id) return
    setExamLoading(true)
    try {
      const score = examScore ? parseFloat(examScore) : undefined
      const res = await ydyoApi.recordExamResult(id, examPassed, score, examNotes || undefined)
      setApp(res.data.data)
      toast.success('Sınav sonucu kaydedildi.')
      setExamOpen(false)
      setExamNotes('')
      setExamScore('')
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Bir hata oluştu.')
    } finally {
      setExamLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  if (!app) {
    return (
      <div className="card p-10 text-center text-gray-400">
        <p>Başvuru bulunamadı.</p>
      </div>
    )
  }

  const appStatus   = APP_STATUS_LABELS[app.status]  || { label: app.status,                             color: 'bg-gray-100 text-gray-600' }
  const langStatus  = LANG_STATUS_LABELS[(app as any).languageStatus || 'NOT_CHECKED']
  const isPending   = app.status === 'PENDING_LANGUAGE_CHECK'
  const isExamMode  = isPending && (app as any).languageStatus === 'EXAM_REQUIRED'

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => navigate('/ydyo/applications')} className="p-1.5 rounded-lg hover:bg-gray-100">
          <ArrowLeft size={18} className="text-gray-500" />
        </button>
        <div>
          <h2 className="text-lg font-semibold text-gray-900">
            {app.applicantFirstName} {app.applicantLastName}
          </h2>
          <p className="text-sm text-gray-400">#{app.applicantStudentId} · {app.applicantEmail}</p>
        </div>
        <div className="ml-auto flex gap-2">
          <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${appStatus.color}`}>
            {appStatus.label}
          </span>
          <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${langStatus.color}`}>
            Dil: {langStatus.label}
          </span>
        </div>
      </div>

      {/* Application Info */}
      <div className="card p-5">
        <h3 className="text-sm font-semibold text-gray-700 mb-4">Başvuru Bilgileri</h3>
        <div className="grid grid-cols-2 gap-x-8 gap-y-3 text-sm">
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Transfer Türü</p>
            <p className="text-gray-800 font-medium">{TRANSFER_LABELS[app.transferType]}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Akademik Yıl</p>
            <p className="text-gray-800 font-medium">{app.academicYear}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Önceki Üniversite</p>
            <p className="text-gray-800 font-medium">{app.previousUniversity}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Mevcut Program</p>
            <p className="text-gray-800 font-medium">{app.currentProgram}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Hedef Program</p>
            <p className="text-gray-800 font-medium">{app.targetProgram}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-0.5">GPA</p>
            <p className="text-gray-800 font-medium">{app.currentGpa}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Mevcut Dönem</p>
            <p className="text-gray-800 font-medium">{app.currentSemester}. dönem</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Hedef Dönem</p>
            <p className="text-gray-800 font-medium">{app.targetSemester}. dönem</p>
          </div>
          {(app as any).languageNotes && (
            <div className="col-span-2">
              <p className="text-xs text-gray-400 mb-0.5">Dil Notu</p>
              <p className="text-gray-800">{(app as any).languageNotes}</p>
            </div>
          )}
        </div>
      </div>

      {/* SFL.02 — Evaluate panel */}
      {isPending && (
        <div className="card overflow-hidden">
          <button
            onClick={() => setEvalOpen(v => !v)}
            className="w-full flex items-center justify-between px-5 py-4 hover:bg-gray-50 transition-colors"
          >
            <span className="text-sm font-semibold text-gray-700">İngilizce Yeterlilik Değerlendirmesi</span>
            <ChevronDown
              size={16}
              className={`text-gray-400 transition-transform ${evalOpen ? 'rotate-180' : ''}`}
            />
          </button>

          {evalOpen && (
            <div className="px-5 pb-5 space-y-4 border-t border-gray-100">
              <div className="mt-4">
                <label className="label">Yeterlilik Durumu</label>
                <div className="flex gap-2 mt-2 flex-wrap">
                  {([
                    { value: 'APPROVED',      label: 'Onaylandı',     cls: 'border-green-400 bg-green-50 text-green-700'  },
                    { value: 'EXAM_REQUIRED', label: 'Sınav Gerekli', cls: 'border-yellow-400 bg-yellow-50 text-yellow-700' },
                    { value: 'NOT_MET',       label: 'Karşılanamadı', cls: 'border-red-400 bg-red-50 text-red-700'       },
                  ] as { value: LanguageStatus; label: string; cls: string }[]).map(opt => (
                    <button
                      key={opt.value}
                      onClick={() => setSelectedLangStatus(opt.value)}
                      className={`text-sm px-4 py-2 rounded-lg border-2 font-medium transition-all ${
                        selectedLangStatus === opt.value
                          ? opt.cls
                          : 'border-gray-200 text-gray-500 hover:border-gray-300'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="label">Not (opsiyonel)</label>
                <textarea
                  value={evalNotes}
                  onChange={e => setEvalNotes(e.target.value)}
                  rows={3}
                  placeholder="Değerlendirme notu..."
                  className="input-field resize-none"
                />
              </div>

              <button
                onClick={handleEvaluate}
                disabled={evalLoading}
                className="btn-primary"
              >
                {evalLoading ? 'Kaydediliyor...' : 'Değerlendirmeyi Kaydet'}
              </button>
            </div>
          )}
        </div>
      )}

      {/* SFL.03 — Exam result panel (only when EXAM_REQUIRED) */}
      {isExamMode && (
        <div className="card overflow-hidden">
          <button
            onClick={() => setExamOpen(v => !v)}
            className="w-full flex items-center justify-between px-5 py-4 hover:bg-gray-50 transition-colors"
          >
            <span className="text-sm font-semibold text-gray-700">Sınav Sonucu Gir</span>
            <ChevronDown
              size={16}
              className={`text-gray-400 transition-transform ${examOpen ? 'rotate-180' : ''}`}
            />
          </button>

          {examOpen && (
            <div className="px-5 pb-5 space-y-4 border-t border-gray-100">
              <div className="mt-4">
                <label className="label">Sınav Sonucu</label>
                <div className="flex gap-2 mt-2">
                  <button
                    onClick={() => setExamPassed(true)}
                    className={`flex-1 text-sm py-2 rounded-lg border-2 font-medium transition-all ${
                      examPassed
                        ? 'border-green-400 bg-green-50 text-green-700'
                        : 'border-gray-200 text-gray-500 hover:border-gray-300'
                    }`}
                  >
                    Geçti
                  </button>
                  <button
                    onClick={() => setExamPassed(false)}
                    className={`flex-1 text-sm py-2 rounded-lg border-2 font-medium transition-all ${
                      !examPassed
                        ? 'border-red-400 bg-red-50 text-red-700'
                        : 'border-gray-200 text-gray-500 hover:border-gray-300'
                    }`}
                  >
                    Kaldı
                  </button>
                </div>
              </div>

              <div>
                <label className="label">Puan (opsiyonel)</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  step={0.5}
                  value={examScore}
                  onChange={e => setExamScore(e.target.value)}
                  placeholder="ör. 72.5"
                  className="input-field"
                />
              </div>

              <div>
                <label className="label">Not (opsiyonel)</label>
                <textarea
                  value={examNotes}
                  onChange={e => setExamNotes(e.target.value)}
                  rows={3}
                  placeholder="Sınav notu..."
                  className="input-field resize-none"
                />
              </div>

              <button
                onClick={handleExamResult}
                disabled={examLoading}
                className="btn-primary"
              >
                {examLoading ? 'Kaydediliyor...' : 'Sonucu Kaydet'}
              </button>
            </div>
          )}
        </div>
      )}

      {/* Finalized state */}
      {!isPending && (
        <div className="card p-5">
          <p className="text-sm text-gray-500 text-center">
            Bu başvuru için dil yeterlilik değerlendirmesi tamamlanmıştır.
          </p>
        </div>
      )}
    </div>
  )
}
