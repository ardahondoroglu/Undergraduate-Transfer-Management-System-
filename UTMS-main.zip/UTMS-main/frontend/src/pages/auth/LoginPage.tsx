import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import toast from 'react-hot-toast'
import { authApi } from '@/api/auth'
import { useAuthStore } from '@/store/authStore'
import LoadingSpinner from '@/components/ui/LoadingSpinner'

interface FormData {
  studentId: string
  password: string
}

export default function LoginPage() {
  const navigate = useNavigate()
  const setAuth = useAuthStore((s) => s.setAuth)
  const [isLoading, setIsLoading] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>()

  const onSubmit = async (data: FormData) => {
    setIsLoading(true)
    try {
      const res = await authApi.login(data)
      const { user, token } = res.data.data!
      setAuth(user, token)
      toast.success(`Welcome back, ${user.firstName}!`)
      navigate('/dashboard')
    } catch (err: any) {
      const msg = err.response?.data?.message || 'Invalid credentials. Please try again.'
      toast.error(msg)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center px-4">
      {/* Logo */}
      <div className="mb-6 text-center">
        <div className="w-20 h-20 mx-auto mb-4 rounded-full border-2 border-primary-500 flex items-center justify-center bg-primary-50">
          <img
            src="/iztech-logo.png"
            alt="IZTECH"
            className="w-16 h-16 object-contain"
            onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }}
          />
        </div>
        <h1 className="text-xl font-bold text-gray-900">Student Portal</h1>
        <p className="text-sm text-gray-500 mt-1">Sign in to access your account</p>
      </div>

      {/* Card */}
      <div className="card w-full max-w-sm p-6">
        <h2 className="text-lg font-semibold text-gray-900">Login</h2>
        <p className="text-sm text-gray-500 mb-5">Enter your credentials to continue</p>

        <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
          {/* Student ID */}
          <div>
            <label className="label" htmlFor="studentId">Student ID</label>
            <input
              id="studentId"
              type="text"
              placeholder="Enter your student ID"
              className={`input-field ${errors.studentId ? 'input-error' : ''}`}
              {...register('studentId', {
                required: 'Student ID is required',
                minLength: { value: 3, message: 'Student ID must be at least 3 characters' },
              })}
            />
            {errors.studentId && (
              <p className="error-message">{errors.studentId.message}</p>
            )}
          </div>

          {/* Password */}
          <div>
            <label className="label" htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              placeholder="Enter your password"
              className={`input-field ${errors.password ? 'input-error' : ''}`}
              {...register('password', {
                required: 'Password is required',
                minLength: { value: 6, message: 'Password must be at least 6 characters' },
              })}
            />
            {errors.password && (
              <p className="error-message">{errors.password.message}</p>
            )}
          </div>

          {/* Forgot password */}
          <div className="flex justify-end">
            <Link
              to="/forgot-password"
              className="text-sm text-gray-600 hover:text-gray-900 hover:underline"
            >
              Forgot Password?
            </Link>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={isLoading}
            className="btn-primary flex items-center justify-center gap-2"
          >
            {isLoading ? <LoadingSpinner size="sm" /> : null}
            {isLoading ? 'Signing in...' : 'Login'}
          </button>
        </form>
      </div>

      {/* Help */}
      <p className="mt-6 text-sm text-gray-400">
        Need help?{' '}
        <a href="mailto:support@iyte.edu.tr" className="hover:text-gray-600 underline">
          Contact support@iyte.edu.tr
        </a>
      </p>
    </div>
  )
}
