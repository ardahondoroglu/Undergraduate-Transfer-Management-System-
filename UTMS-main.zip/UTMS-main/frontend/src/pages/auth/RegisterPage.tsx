import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import toast from 'react-hot-toast'
import { authApi } from '@/api/auth'
import LoadingSpinner from '@/components/ui/LoadingSpinner'

interface FormData {
  firstName: string
  lastName: string
  email: string
  studentNumber: string
  password: string
  confirmPassword: string
}

export default function RegisterPage() {
  const navigate = useNavigate()
  const [isLoading, setIsLoading] = useState(false)

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<FormData>()

  const password = watch('password')

  const onSubmit = async (data: FormData) => {
    setIsLoading(true)
    try {
      await authApi.register({
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        studentNumber: data.studentNumber,
        password: data.password,
      })
      toast.success('Account created! Please check your email to verify your account.')
      navigate('/login')
    } catch (err: any) {
      const msg = err.response?.data?.message || 'Registration failed. Please try again.'
      toast.error(msg)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center px-4 py-10">
      {/* Logo */}
      <div className="mb-6 text-center">
        <div className="w-16 h-16 mx-auto mb-3 rounded-full border-2 border-primary-500 flex items-center justify-center bg-primary-50">
          <img
            src="/iztech-logo.png"
            alt="IZTECH"
            className="w-12 h-12 object-contain"
            onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }}
          />
        </div>
        <h1 className="text-xl font-bold text-gray-900">Create Your Account</h1>
        <p className="text-sm text-gray-500 mt-1">
          Join the Student Portal to access your academic resources
        </p>
      </div>

      {/* Card */}
      <div className="card w-full max-w-lg p-6">
        <h2 className="text-base font-semibold text-gray-900">Applicant Registration</h2>
        <p className="text-sm text-gray-500 mb-5">Fill in your information to create a new account</p>

        <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
          {/* Name row */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label" htmlFor="firstName">First Name</label>
              <input
                id="firstName"
                type="text"
                placeholder="Enter your first name"
                className={`input-field ${errors.firstName ? 'input-error' : ''}`}
                {...register('firstName', {
                  required: 'First name is required',
                  minLength: { value: 2, message: 'Minimum 2 characters' },
                  maxLength: { value: 50, message: 'Maximum 50 characters' },
                  pattern: {
                    value: /^[a-zA-ZğüşıöçĞÜŞİÖÇ\s'-]+$/,
                    message: 'Only letters allowed',
                  },
                })}
              />
              {errors.firstName && <p className="error-message">{errors.firstName.message}</p>}
            </div>

            <div>
              <label className="label" htmlFor="lastName">Last Name</label>
              <input
                id="lastName"
                type="text"
                placeholder="Enter your last name"
                className={`input-field ${errors.lastName ? 'input-error' : ''}`}
                {...register('lastName', {
                  required: 'Last name is required',
                  minLength: { value: 2, message: 'Minimum 2 characters' },
                  maxLength: { value: 50, message: 'Maximum 50 characters' },
                  pattern: {
                    value: /^[a-zA-ZğüşıöçĞÜŞİÖÇ\s'-]+$/,
                    message: 'Only letters allowed',
                  },
                })}
              />
              {errors.lastName && <p className="error-message">{errors.lastName.message}</p>}
            </div>
          </div>

          {/* Email */}
          <div>
            <label className="label" htmlFor="email">Email Address</label>
            <input
              id="email"
              type="email"
              placeholder="student@university.edu"
              className={`input-field ${errors.email ? 'input-error' : ''}`}
              {...register('email', {
                required: 'Email is required',
                pattern: {
                  value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                  message: 'Invalid email format',
                },
              })}
            />
            {errors.email && <p className="error-message">{errors.email.message}</p>}
          </div>

          {/* Student Number */}
          <div>
            <label className="label" htmlFor="studentNumber">Student Number</label>
            <input
              id="studentNumber"
              type="text"
              placeholder="Enter your student number"
              className={`input-field ${errors.studentNumber ? 'input-error' : ''}`}
              {...register('studentNumber', {
                required: 'Student number is required',
                minLength: { value: 6, message: 'Student number must be at least 6 characters' },
              })}
            />
            {errors.studentNumber && <p className="error-message">{errors.studentNumber.message}</p>}
          </div>

          {/* Password row */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label" htmlFor="password">Password</label>
              <input
                id="password"
                type="password"
                placeholder="Create a password"
                className={`input-field ${errors.password ? 'input-error' : ''}`}
                {...register('password', {
                  required: 'Password is required',
                  minLength: { value: 8, message: 'Minimum 8 characters' },
                  pattern: {
                    value: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
                    message: 'Must include uppercase, lowercase and number',
                  },
                })}
              />
              {errors.password && <p className="error-message">{errors.password.message}</p>}
            </div>

            <div>
              <label className="label" htmlFor="confirmPassword">Confirm Password</label>
              <input
                id="confirmPassword"
                type="password"
                placeholder="Re-enter password"
                className={`input-field ${errors.confirmPassword ? 'input-error' : ''}`}
                {...register('confirmPassword', {
                  required: 'Please confirm your password',
                  validate: (value) =>
                    value === password || 'Passwords do not match',
                })}
              />
              {errors.confirmPassword && <p className="error-message">{errors.confirmPassword.message}</p>}
            </div>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={isLoading}
            className="btn-primary flex items-center justify-center gap-2 mt-2"
          >
            {isLoading ? <LoadingSpinner size="sm" /> : null}
            {isLoading ? 'Creating Account...' : 'Create Account'}
          </button>
        </form>
      </div>

      {/* Already have account */}
      <p className="mt-5 text-sm text-gray-500">
        Already have an account?{' '}
        <Link to="/login" className="font-semibold text-gray-900 hover:underline">
          Sign in here
        </Link>
      </p>
    </div>
  )
}
