import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import toast from 'react-hot-toast'
import { authApi } from '@/api/auth'
import LoadingSpinner from '@/components/ui/LoadingSpinner'
import { ArrowLeft, Mail } from 'lucide-react'

interface FormData {
  email: string
}

export default function ForgotPasswordPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [sent, setSent] = useState(false)

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>()

  const onSubmit = async (data: FormData) => {
    setIsLoading(true)
    try {
      await authApi.forgotPassword(data)
      setSent(true)
    } catch {
      // Generic message for security — don't reveal if email exists
      setSent(true)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center px-4">
      <div className="mb-6 text-center">
        <div className="w-16 h-16 mx-auto mb-3 rounded-full border-2 border-primary-500 flex items-center justify-center bg-primary-50">
          <img src="/iztech-logo.png" alt="IZTECH" className="w-12 h-12 object-contain"
            onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }} />
        </div>
        <h1 className="text-xl font-bold text-gray-900">Reset Password</h1>
        <p className="text-sm text-gray-500 mt-1">We'll send a reset link to your email</p>
      </div>

      <div className="card w-full max-w-sm p-6">
        {sent ? (
          <div className="text-center py-4">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <Mail size={20} className="text-green-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-1">Check your email</h3>
            <p className="text-sm text-gray-500">
              If an account exists for that email, you'll receive a password reset link shortly.
            </p>
            <Link
              to="/login"
              className="mt-4 inline-flex items-center gap-1 text-sm text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft size={14} /> Back to Login
            </Link>
          </div>
        ) : (
          <>
            <h2 className="text-base font-semibold text-gray-900 mb-1">Forgot Password?</h2>
            <p className="text-sm text-gray-500 mb-5">
              Enter your registered email address to receive a reset link.
            </p>
            <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
              <div>
                <label className="label" htmlFor="email">Email Address</label>
                <input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  className={`input-field ${errors.email ? 'input-error' : ''}`}
                  {...register('email', {
                    required: 'Email is required',
                    pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Invalid email' },
                  })}
                />
                {errors.email && <p className="error-message">{errors.email.message}</p>}
              </div>
              <button type="submit" disabled={isLoading} className="btn-primary flex items-center justify-center gap-2">
                {isLoading && <LoadingSpinner size="sm" />}
                {isLoading ? 'Sending...' : 'Send Reset Link'}
              </button>
            </form>
            <div className="mt-4 text-center">
              <Link to="/login" className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-gray-900">
                <ArrowLeft size={14} /> Back to Login
              </Link>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
