import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { ChevronRight, Search } from 'lucide-react'
import { ygkApi } from '@/api/ygk'
import type { StaffApplication } from '@/api/staff'
import LoadingSpinner from '@/components/ui/LoadingSpinner'

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  UNDER_YGK_EVALUATION:   { label: 'Değerlendiriliyor',         color: 'bg-indigo-100 text-indigo-700' },
  ACADEMICALLY_EVALUATED: { label: 'Akademik Değerlendirildi',  color: 'bg-teal-100 text-teal-700' },
  RANKING_IN_PROGRESS:    { label: 'Sıralamada',                color: 'bg-cyan-100 text-cyan-700' },
  FORWARDED_TO_FACULTY:   { label: 'Fakülteye Yönlendirildi',   color: 'bg-sky-100 text-sky-700' },
  APPROVED:               { label: 'Onaylandı',                 color: 'bg-green-100 text-green-800' },
  REJECTED:               { label: 'Reddedildi',                color: 'bg-red-100 text-red-800' },
}

const TRANSFER_LABELS: Record<string, string> = {
  INTERNAL: 'Kurum İçi', EXTERNAL: 'Kurum Dışı',
  DOUBLE_MAJOR: 'Çift Anadal', MINOR: 'Yandal',
}

const FILTER_OPTIONS = [
  { value: '', label: 'Tümü' },
  { value: 'UNDER_YGK_EVALUATION',   label: 'Değerlendirme' },
  { value: 'ACADEMICALLY_EVALUATED', label: 'Değerlendirildi' },
  { value: 'RANKING_IN_PROGRESS',    label: 'Sıralama' },
  { value: 'FORWARDED_TO_FACULTY',   label: 'Fakülte' },
]

export default function YgkApplicationsPage() {
  const navigate = useNavigate()
  const [applications, setApplications] = useState<StaffApplication[]>([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('')
  const [search, setSearch] = useState('')

  useEffect(() => {
    setLoading(true)
    ygkApi.getApplications(statusFilter || undefined)
      .then(res => setApplications(res.data.data || []))
      .catch(() => toast.error('Başvurular yüklenemedi.'))
      .finally(() => setLoading(false))
  }, [statusFilter])

  const filtered = applications.filter(app => {
    if (!search) return true
    const q = search.toLowerCase()
    return (
      app.applicantFirstName.toLowerCase().includes(q) ||
      app.applicantLastName.toLowerCase().includes(q) ||
      app.applicantStudentId.toLowerCase().includes(q) ||
      app.targetProgram.toLowerCase().includes(q)
    )
  })

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900">Akademik Değerlendirme</h2>
        <p className="text-sm text-gray-500 mt-1">YGK kapsamındaki başvuruları değerlendirin.</p>
      </div>

      <div className="flex flex-wrap gap-3 mb-5">
        <div className="relative flex-1 min-w-48">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Ad, öğrenci no, program..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="input-field pl-9"
          />
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {FILTER_OPTIONS.map(opt => (
            <button
              key={opt.value}
              onClick={() => setStatusFilter(opt.value)}
              className={`text-xs px-3 py-1.5 rounded-full border font-medium transition-colors ${
                statusFilter === opt.value
                  ? 'bg-gray-900 text-white border-gray-900'
                  : 'border-gray-300 text-gray-600 hover:bg-gray-50'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48"><LoadingSpinner size="lg" /></div>
      ) : filtered.length === 0 ? (
        <div className="card p-10 text-center text-gray-400">
          <p className="text-sm">Bu kriterlere uygun başvuru bulunamadı.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(app => {
            const statusInfo = STATUS_LABELS[app.status] || { label: app.status, color: 'bg-gray-100 text-gray-600' }
            return (
              <div
                key={app.id}
                onClick={() => navigate(`/ygk/applications/${app.id}`)}
                className="card p-4 cursor-pointer hover:shadow-md transition-shadow flex items-center gap-4"
              >
                <div className="w-10 h-10 bg-indigo-50 rounded-full flex items-center justify-center text-sm font-semibold text-indigo-600 flex-shrink-0">
                  {app.applicantFirstName[0]}{app.applicantLastName[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-gray-900">
                      {app.applicantFirstName} {app.applicantLastName}
                    </p>
                    <span className="text-xs text-gray-400">#{app.applicantStudentId}</span>
                  </div>
                  <p className="text-sm text-gray-500 truncate">
                    {TRANSFER_LABELS[app.transferType]} • {app.targetProgram}
                  </p>
                  <p className="text-xs text-gray-400">
                    GPA {app.currentGpa} • {app.academicYear}
                  </p>
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${statusInfo.color}`}>
                    {statusInfo.label}
                  </span>
                  <ChevronRight size={16} className="text-gray-400" />
                </div>
              </div>
            )
          })}
        </div>
      )}
      <p className="text-xs text-gray-400 mt-4 text-right">{filtered.length} başvuru</p>
    </div>
  )
}
