import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { Trophy, ChevronRight, Pencil, X, Check } from 'lucide-react'
import { ygkApi, type RankedApplication } from '@/api/ygk'
import LoadingSpinner from '@/components/ui/LoadingSpinner'

const TRANSFER_LABELS: Record<string, string> = {
  INTERNAL: 'Kurum İçi', EXTERNAL: 'Kurum Dışı',
  DOUBLE_MAJOR: 'Çift Anadal', MINOR: 'Yandal',
}

// Inline editable ranking row
function RankRow({
  app,
  autoRank,
  onSaved,
  onNavigate,
}: {
  app: RankedApplication
  autoRank: number
  onSaved: (updated: RankedApplication) => void
  onNavigate: () => void
}) {
  const [editing, setEditing] = useState(false)
  const [pos, setPos] = useState(String(app.rankingPosition ?? autoRank))
  const [justification, setJustification] = useState(app.rankingJustification ?? '')
  const [saving, setSaving] = useState(false)

  const displayRank = app.rankingPosition ?? autoRank

  const handleSave = async (e: React.MouseEvent) => {
    e.stopPropagation()
    const num = parseInt(pos, 10)
    if (isNaN(num) || num < 1) { toast.error('Geçerli bir pozisyon girin.'); return }
    setSaving(true)
    try {
      const res = await ygkApi.updateRanking(app.id, num, justification || undefined)
      onSaved(res.data.data!)
      setEditing(false)
      toast.success('Sıralama güncellendi.')
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Güncellenemedi.')
    } finally {
      setSaving(false)
    }
  }

  const handleCancel = (e: React.MouseEvent) => {
    e.stopPropagation()
    setPos(String(app.rankingPosition ?? autoRank))
    setJustification(app.rankingJustification ?? '')
    setEditing(false)
  }

  return (
    <div className="border-b border-gray-100 last:border-0">
      <div
        className="flex items-center gap-4 px-5 py-3 cursor-pointer hover:bg-gray-50 transition-colors"
        onClick={editing ? undefined : onNavigate}
      >
        {/* Rank badge */}
        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${
          displayRank === 1 ? 'bg-yellow-100 text-yellow-700' :
          displayRank === 2 ? 'bg-gray-100 text-gray-600' :
          displayRank === 3 ? 'bg-orange-100 text-orange-700' :
          'bg-gray-50 text-gray-500'
        }`}>
          {displayRank}
        </div>

        <div className="flex-1 min-w-0">
          <p className="font-medium text-gray-900">
            {app.applicantFirstName} {app.applicantLastName}
            <span className="text-xs text-gray-400 ml-2">#{app.applicantStudentId}</span>
          </p>
          <p className="text-xs text-gray-500">
            {TRANSFER_LABELS[app.transferType]} • {app.currentSemester}. dönem
          </p>
          {app.rankingJustification && !editing && (
            <p className="text-xs text-indigo-600 mt-0.5 italic">"{app.rankingJustification}"</p>
          )}
        </div>

        <div className="flex items-center gap-3 flex-shrink-0">
          {app.evaluationScore && (
            <div className="text-right">
              <p className="text-sm font-semibold text-indigo-700">{Number(app.evaluationScore).toFixed(2)}</p>
              <p className="text-xs text-gray-400">Puan</p>
            </div>
          )}
          <div className="text-right">
            <p className="text-lg font-bold text-gray-900">{Number(app.currentGpa).toFixed(2)}</p>
            <p className="text-xs text-gray-400">GPA</p>
          </div>

          {/* Edit button */}
          {!editing ? (
            <button
              onClick={e => { e.stopPropagation(); setEditing(true) }}
              className="p-1.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded"
            >
              <Pencil size={14} />
            </button>
          ) : (
            <div className="flex gap-1">
              <button onClick={handleSave} disabled={saving}
                className="p-1.5 text-green-600 hover:bg-green-50 rounded">
                {saving ? <LoadingSpinner size="sm" /> : <Check size={14} />}
              </button>
              <button onClick={handleCancel}
                className="p-1.5 text-red-500 hover:bg-red-50 rounded">
                <X size={14} />
              </button>
            </div>
          )}

          {!editing && <ChevronRight size={16} className="text-gray-400" />}
        </div>
      </div>

      {/* Inline edit form */}
      {editing && (
        <div
          className="px-5 pb-4 bg-indigo-50 space-y-2"
          onClick={e => e.stopPropagation()}
        >
          <div className="flex gap-3 items-end">
            <div>
              <label className="text-xs font-medium text-gray-600">Sıra No</label>
              <input
                type="number"
                min={1}
                value={pos}
                onChange={e => setPos(e.target.value)}
                className="input-field w-24 text-center"
              />
            </div>
            <div className="flex-1">
              <label className="text-xs font-medium text-gray-600">Gerekçe (opsiyonel)</label>
              <input
                type="text"
                value={justification}
                onChange={e => setJustification(e.target.value)}
                placeholder="Manuel sıralama gerekçesi..."
                className="input-field"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function RankingPage() {
  const navigate = useNavigate()
  const [apps, setApps] = useState<RankedApplication[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    ygkApi.getRanking()
      .then(res => setApps(res.data.data || []))
      .catch(() => toast.error('Sıralama yüklenemedi.'))
      .finally(() => setLoading(false))
  }, [])

  const handleSaved = (updated: RankedApplication) => {
    setApps(prev => prev.map(a => a.id === updated.id ? { ...a, ...updated } : a))
  }

  // Sort by manual rankingPosition first, then by GPA desc
  const sorted = [...apps].sort((a, b) => {
    if (a.rankingPosition != null && b.rankingPosition != null) return a.rankingPosition - b.rankingPosition
    if (a.rankingPosition != null) return -1
    if (b.rankingPosition != null) return 1
    return Number(b.currentGpa) - Number(a.currentGpa)
  })

  // Group by targetProgram + academicYear
  const groups = sorted.reduce<Record<string, RankedApplication[]>>((acc, app) => {
    const key = `${app.targetProgram} — ${app.academicYear}`
    if (!acc[key]) acc[key] = []
    acc[key].push(app)
    return acc
  }, {})

  if (loading) return (
    <div className="flex items-center justify-center h-48"><LoadingSpinner size="lg" /></div>
  )

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
          <Trophy size={20} /> Sıralama Listesi
        </h2>
        <p className="text-sm text-gray-500 mt-1">
          Akademik değerlendirmesi tamamlanmış başvurular. Kalem ikonuna tıklayarak sıra ve gerekçe düzenleyebilirsiniz.
        </p>
      </div>

      {Object.keys(groups).length === 0 ? (
        <div className="card p-10 text-center text-gray-400">
          <Trophy size={32} className="mx-auto mb-3 text-gray-300" />
          <p className="text-sm">Henüz sıralanacak başvuru yok.</p>
          <p className="text-xs mt-1">Akademik değerlendirmesi tamamlananlar burada görünür.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(groups).map(([groupKey, groupApps]) => (
            <div key={groupKey} className="card overflow-hidden">
              <div className="px-5 py-3 bg-gray-50 border-b border-gray-200">
                <p className="text-sm font-semibold text-gray-900">{groupKey}</p>
                <p className="text-xs text-gray-400">{groupApps.length} başvuru</p>
              </div>
              <div>
                {groupApps.map((app, index) => (
                  <RankRow
                    key={app.id}
                    app={app}
                    autoRank={index + 1}
                    onSaved={handleSaved}
                    onNavigate={() => navigate(`/ygk/applications/${app.id}`)}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
