import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { ArrowLeft, Plus, Pencil, Trash2, ChevronDown, BookOpen } from 'lucide-react'
import { ygkApi, type CourseEquivalency, type EquivalencyStatus } from '@/api/ygk'
import type { StaffApplication } from '@/api/staff'
import LoadingSpinner from '@/components/ui/LoadingSpinner'

// ─── Constants ───────────────────────────────────────────────────────────────

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  UNDER_YGK_EVALUATION:   { label: 'Değerlendiriliyor',         color: 'bg-indigo-100 text-indigo-700' },
  ACADEMICALLY_EVALUATED: { label: 'Akademik Değerlendirildi',  color: 'bg-teal-100 text-teal-700' },
  RANKING_IN_PROGRESS:    { label: 'Sıralamada',                color: 'bg-cyan-100 text-cyan-700' },
  FORWARDED_TO_FACULTY:   { label: 'Fakülteye Yönlendirildi',   color: 'bg-sky-100 text-sky-700' },
  APPROVED:               { label: 'Onaylandı',                 color: 'bg-green-100 text-green-800' },
  REJECTED:               { label: 'Reddedildi',                color: 'bg-red-100 text-red-800' },
}

const TRANSFER_LABELS: Record<string, string> = {
  INTERNAL: 'Kurum İçi', EXTERNAL: 'Kurum Dışı',
  DOUBLE_MAJOR: 'Çift Anadal', MINOR: 'Yandal',
}

const EQ_STATUS_LABELS: Record<EquivalencyStatus, { label: string; color: string }> = {
  EQUIVALENT:           { label: 'Eşdeğer',          color: 'bg-green-100 text-green-700' },
  PARTIALLY_EQUIVALENT: { label: 'Kısmen Eşdeğer',   color: 'bg-yellow-100 text-yellow-700' },
  NOT_EQUIVALENT:       { label: 'Eşdeğer Değil',    color: 'bg-red-100 text-red-700' },
}

const NEXT_STATUSES: Record<string, { value: string; label: string; needsNote?: boolean }[]> = {
  UNDER_YGK_EVALUATION:   [{ value: 'ACADEMICALLY_EVALUATED', label: 'Değerlendirmeyi Tamamla' }],
  ACADEMICALLY_EVALUATED: [{ value: 'RANKING_IN_PROGRESS',    label: 'Sıralamaya Al' }],
  RANKING_IN_PROGRESS:    [{ value: 'FORWARDED_TO_FACULTY',   label: 'Fakülte Kuruluna İlet' }],
}

// ─── Equivalency Form ─────────────────────────────────────────────────────────

const EMPTY_FORM = {
  previousCourseCode:    '',
  previousCourseName:    '',
  previousCourseCredits: '',
  targetCourseCode:      '',
  targetCourseName:      '',
  targetCourseCredits:   '',
  status:                'EQUIVALENT' as EquivalencyStatus,
  notes:                 '',
}

// ─── Component ───────────────────────────────────────────────────────────────

export default function YgkApplicationDetailPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()

  const [app, setApp] = useState<StaffApplication | null>(null)
  const [equivalencies, setEquivalencies] = useState<CourseEquivalency[]>([])
  const [loading, setLoading] = useState(true)

  // Status panel
  const [showStatusPanel, setShowStatusPanel] = useState(false)
  const [selectedStatus, setSelectedStatus] = useState('')
  const [note, setNote] = useState('')
  const [evalScore, setEvalScore] = useState('')
  const [evalNotes, setEvalNotes] = useState('')
  const [updatingStatus, setUpdatingStatus] = useState(false)

  // Equivalency form
  const [showEqForm, setShowEqForm] = useState(false)
  const [editingEq, setEditingEq] = useState<CourseEquivalency | null>(null)
  const [eqForm, setEqForm] = useState(EMPTY_FORM)
  const [savingEq, setSavingEq] = useState(false)
  const [deletingEq, setDeletingEq] = useState<string | null>(null)

  useEffect(() => {
    if (!id) return
    Promise.all([ygkApi.getApplication(id), ygkApi.getEquivalencies(id)])
      .then(([appRes, eqRes]) => {
        setApp(appRes.data.data!)
        setEquivalencies(eqRes.data.data || [])
      })
      .catch(() => toast.error('Başvuru yüklenemedi.'))
      .finally(() => setLoading(false))
  }, [id])

  // ── Status update ──────────────────────────────────────────────────────────

  const handleStatusUpdate = async () => {
    if (!id || !selectedStatus) return
    try {
      setUpdatingStatus(true)
      const score = evalScore ? parseFloat(evalScore) : undefined
      const res = await ygkApi.updateStatus(
        id, selectedStatus, note || undefined,
        score, evalNotes || undefined,
      )
      setApp(prev => prev ? { ...prev, status: res.data.data!.status } : prev)
      setShowStatusPanel(false)
      setSelectedStatus('')
      setNote('')
      setEvalScore('')
      setEvalNotes('')
      toast.success('Durum güncellendi.')
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Güncelleme başarısız.')
    } finally {
      setUpdatingStatus(false)
    }
  }

  // ── Equivalency CRUD ───────────────────────────────────────────────────────

  const openNewForm = () => {
    setEditingEq(null)
    setEqForm(EMPTY_FORM)
    setShowEqForm(true)
  }

  const openEditForm = (eq: CourseEquivalency) => {
    setEditingEq(eq)
    setEqForm({
      previousCourseCode:    eq.previousCourseCode,
      previousCourseName:    eq.previousCourseName,
      previousCourseCredits: eq.previousCourseCredits,
      targetCourseCode:      eq.targetCourseCode,
      targetCourseName:      eq.targetCourseName,
      targetCourseCredits:   eq.targetCourseCredits,
      status:                eq.status,
      notes:                 eq.notes || '',
    })
    setShowEqForm(true)
  }

  const handleSaveEq = async () => {
    if (!id) return
    if (!eqForm.previousCourseCode || !eqForm.previousCourseName ||
        !eqForm.targetCourseCode || !eqForm.targetCourseName) {
      toast.error('Ders kodu ve adı zorunludur.')
      return
    }
    try {
      setSavingEq(true)
      if (editingEq) {
        const res = await ygkApi.updateEquivalency(editingEq.id, eqForm)
        setEquivalencies(prev => prev.map(e => e.id === editingEq.id ? res.data.data! : e))
        toast.success('Eşdeğerlik güncellendi.')
      } else {
        const res = await ygkApi.createEquivalency(id, eqForm)
        setEquivalencies(prev => [...prev, res.data.data!])
        toast.success('Eşdeğerlik eklendi.')
      }
      setShowEqForm(false)
      setEditingEq(null)
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'İşlem başarısız.')
    } finally {
      setSavingEq(false)
    }
  }

  const handleDeleteEq = async (eqId: string) => {
    try {
      setDeletingEq(eqId)
      await ygkApi.deleteEquivalency(eqId)
      setEquivalencies(prev => prev.filter(e => e.id !== eqId))
      toast.success('Eşdeğerlik silindi.')
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Silinemedi.')
    } finally {
      setDeletingEq(null)
    }
  }

  // ── Render ─────────────────────────────────────────────────────────────────

  if (loading) return (
    <div className="flex items-center justify-center h-48"><LoadingSpinner size="lg" /></div>
  )
  if (!app) return (
    <div className="text-center text-gray-400 py-16"><p>Başvuru bulunamadı.</p></div>
  )

  const statusInfo = STATUS_LABELS[app.status] || { label: app.status, color: 'bg-gray-100 text-gray-600' }
  const nextStatuses = NEXT_STATUSES[app.status] || []
  const isLocked = ['FORWARDED_TO_FACULTY', 'APPROVED', 'REJECTED', 'FINALIZED'].includes(app.status)

  return (
    <div className="max-w-3xl mx-auto space-y-5">

      {/* Header */}
      <div className="flex items-center justify-between">
        <button onClick={() => navigate('/ygk/applications')}
          className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-900">
          <ArrowLeft size={16} /> Başvurular
        </button>
        {nextStatuses.length > 0 && (
          <button
            onClick={() => setShowStatusPanel(!showStatusPanel)}
            className="flex items-center gap-1.5 text-sm bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"
          >
            Durum Güncelle <ChevronDown size={14} />
          </button>
        )}
      </div>

      {/* Status update panel */}
      {showStatusPanel && (
        <div className="card p-5 border-2 border-indigo-600">
          <h3 className="font-semibold text-gray-900 mb-3">Durum Güncelle</h3>
          <div className="flex flex-wrap gap-2 mb-3">
            {nextStatuses.map(s => (
              <button key={s.value}
                onClick={() => { setSelectedStatus(s.value); setNote('') }}
                className={`text-sm px-3 py-1.5 rounded-lg border transition-colors ${
                  selectedStatus === s.value
                    ? 'bg-indigo-600 text-white border-indigo-600'
                    : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
          {selectedStatus === 'ACADEMICALLY_EVALUATED' && (
            <div className="space-y-3 mb-3 border-t border-gray-100 pt-3">
              <div>
                <label className="label">Değerlendirme Puanı (opsiyonel)</label>
                <input
                  type="number"
                  min={0} max={100} step={0.01}
                  value={evalScore}
                  onChange={e => setEvalScore(e.target.value)}
                  placeholder="ör. 87.50"
                  className="input-field"
                />
              </div>
              <div>
                <label className="label">Değerlendirme Notu (opsiyonel)</label>
                <textarea
                  value={evalNotes}
                  onChange={e => setEvalNotes(e.target.value)}
                  rows={3}
                  placeholder="Akademik değerlendirme açıklaması..."
                  className="input-field resize-none"
                />
              </div>
            </div>
          )}
          {selectedStatus && (
            <div className="flex gap-2">
              <button onClick={() => { setShowStatusPanel(false); setSelectedStatus(''); setEvalScore(''); setEvalNotes('') }}
                className="flex-1 border border-gray-300 text-gray-700 py-2 rounded-lg text-sm hover:bg-gray-50">
                İptal
              </button>
              <button onClick={handleStatusUpdate} disabled={updatingStatus}
                className="flex-1 bg-indigo-600 text-white py-2 rounded-lg text-sm hover:bg-indigo-700 disabled:opacity-50 flex items-center justify-center gap-2">
                {updatingStatus ? <LoadingSpinner size="sm" /> : null}
                Onayla
              </button>
            </div>
          )}
        </div>
      )}

      {/* Application Info */}
      <div className="card p-5">
        <div className="flex items-start justify-between mb-4">
          <div>
            <p className="text-xs text-gray-500 mb-1">{TRANSFER_LABELS[app.transferType]} • {app.academicYear}</p>
            <h2 className="text-lg font-semibold text-gray-900">{app.targetProgram}</h2>
            <p className="text-sm text-gray-500">{app.previousUniversity} — {app.currentProgram}</p>
          </div>
          <span className={`text-xs font-medium px-3 py-1 rounded-full ${statusInfo.color}`}>
            {statusInfo.label}
          </span>
        </div>

        <div className="bg-gray-50 rounded-lg p-3 mb-4">
          <p className="text-xs text-gray-500 mb-1">Başvuran</p>
          <p className="text-sm font-medium text-gray-900">
            {app.applicantFirstName} {app.applicantLastName}
            <span className="font-normal text-gray-500"> — #{app.applicantStudentId}</span>
          </p>
          <p className="text-xs text-gray-500">{app.applicantEmail}</p>
        </div>

        <div className="grid grid-cols-3 gap-4 pt-3 border-t border-gray-100">
          <div><p className="text-xs text-gray-400">GPA</p><p className="text-sm font-medium">{app.currentGpa}</p></div>
          <div><p className="text-xs text-gray-400">Mevcut Dönem</p><p className="text-sm font-medium">{app.currentSemester}. Dönem</p></div>
          <div><p className="text-xs text-gray-400">Hedef Dönem</p><p className="text-sm font-medium">{app.targetSemester}. Dönem</p></div>
        </div>

        {app.reasonForTransfer && (
          <div className="mt-3 pt-3 border-t border-gray-100">
            <p className="text-xs text-gray-400 mb-1">Geçiş Gerekçesi</p>
            <p className="text-sm text-gray-700">{app.reasonForTransfer}</p>
          </div>
        )}
      </div>

      {/* Course Equivalencies — CE.1 */}
      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-gray-900 flex items-center gap-2">
            <BookOpen size={16} /> Ders Eşdeğerlikleri
          </h3>
          {!isLocked && (
            <button onClick={openNewForm}
              className="flex items-center gap-1 text-sm border border-gray-300 text-gray-700 px-3 py-1.5 rounded-lg hover:bg-gray-50">
              <Plus size={14} /> Ders Ekle
            </button>
          )}
        </div>

        {equivalencies.length === 0 ? (
          <p className="text-sm text-gray-400 text-center py-4">
            Henüz ders eşdeğerliği girilmedi.
          </p>
        ) : (
          <div className="space-y-2">
            {/* Header row */}
            <div className="grid grid-cols-12 gap-2 text-xs text-gray-400 font-medium px-1">
              <span className="col-span-5">Önceki Ders</span>
              <span className="col-span-5">Hedef Ders</span>
              <span className="col-span-2 text-center">Durum</span>
            </div>
            {equivalencies.map(eq => {
              const eqStatus = EQ_STATUS_LABELS[eq.status]
              return (
                <div key={eq.id} className="grid grid-cols-12 gap-2 items-center border border-gray-200 rounded-lg p-3 text-sm">
                  <div className="col-span-5">
                    <p className="font-medium text-gray-900">{eq.previousCourseCode}</p>
                    <p className="text-xs text-gray-500 truncate">{eq.previousCourseName}</p>
                    <p className="text-xs text-gray-400">{eq.previousCourseCredits} kr.</p>
                  </div>
                  <div className="col-span-5">
                    <p className="font-medium text-gray-900">{eq.targetCourseCode}</p>
                    <p className="text-xs text-gray-500 truncate">{eq.targetCourseName}</p>
                    <p className="text-xs text-gray-400">{eq.targetCourseCredits} kr.</p>
                  </div>
                  <div className="col-span-2 flex flex-col items-center gap-1">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium text-center ${eqStatus.color}`}>
                      {eqStatus.label}
                    </span>
                    {!isLocked && (
                      <div className="flex gap-1">
                        <button onClick={() => openEditForm(eq)} className="text-gray-400 hover:text-gray-700 p-0.5">
                          <Pencil size={12} />
                        </button>
                        <button
                          onClick={() => handleDeleteEq(eq.id)}
                          disabled={deletingEq === eq.id}
                          className="text-gray-400 hover:text-red-600 p-0.5 disabled:opacity-50"
                        >
                          {deletingEq === eq.id ? <LoadingSpinner size="sm" /> : <Trash2 size={12} />}
                        </button>
                      </div>
                    )}
                  </div>
                  {eq.notes && (
                    <p className="col-span-12 text-xs text-gray-500 border-t border-gray-100 pt-2 mt-1">
                      Not: {eq.notes}
                    </p>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Equivalency Form Modal */}
      {showEqForm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 max-w-lg w-full shadow-xl max-h-[90vh] overflow-y-auto">
            <h3 className="font-semibold text-gray-900 mb-4">
              {editingEq ? 'Eşdeğerliği Düzenle' : 'Yeni Ders Eşdeğerliği'}
            </h3>

            <div className="space-y-4">
              {/* Previous course */}
              <div>
                <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Önceki Ders</p>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="label">Kod</label>
                    <input value={eqForm.previousCourseCode}
                      onChange={e => setEqForm(f => ({ ...f, previousCourseCode: e.target.value }))}
                      className="input-field" placeholder="BLM101" />
                  </div>
                  <div className="col-span-2">
                    <label className="label">Ders Adı</label>
                    <input value={eqForm.previousCourseName}
                      onChange={e => setEqForm(f => ({ ...f, previousCourseName: e.target.value }))}
                      className="input-field" placeholder="Veri Yapıları" />
                  </div>
                </div>
                <div className="mt-2">
                  <label className="label">Kredi</label>
                  <input type="number" step="0.5" value={eqForm.previousCourseCredits}
                    onChange={e => setEqForm(f => ({ ...f, previousCourseCredits: e.target.value }))}
                    className="input-field" placeholder="3" />
                </div>
              </div>

              {/* Target course */}
              <div>
                <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Hedef Ders (IZTECH)</p>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="label">Kod</label>
                    <input value={eqForm.targetCourseCode}
                      onChange={e => setEqForm(f => ({ ...f, targetCourseCode: e.target.value }))}
                      className="input-field" placeholder="CENG301" />
                  </div>
                  <div className="col-span-2">
                    <label className="label">Ders Adı</label>
                    <input value={eqForm.targetCourseName}
                      onChange={e => setEqForm(f => ({ ...f, targetCourseName: e.target.value }))}
                      className="input-field" placeholder="Data Structures" />
                  </div>
                </div>
                <div className="mt-2">
                  <label className="label">Kredi</label>
                  <input type="number" step="0.5" value={eqForm.targetCourseCredits}
                    onChange={e => setEqForm(f => ({ ...f, targetCourseCredits: e.target.value }))}
                    className="input-field" placeholder="3" />
                </div>
              </div>

              {/* Status */}
              <div>
                <label className="label">Eşdeğerlik Durumu</label>
                <select value={eqForm.status}
                  onChange={e => setEqForm(f => ({ ...f, status: e.target.value as EquivalencyStatus }))}
                  className="input-field">
                  <option value="EQUIVALENT">Eşdeğer</option>
                  <option value="PARTIALLY_EQUIVALENT">Kısmen Eşdeğer</option>
                  <option value="NOT_EQUIVALENT">Eşdeğer Değil</option>
                </select>
              </div>

              {/* Notes */}
              <div>
                <label className="label">Notlar (opsiyonel)</label>
                <textarea value={eqForm.notes}
                  onChange={e => setEqForm(f => ({ ...f, notes: e.target.value }))}
                  rows={2} className="input-field resize-none"
                  placeholder="Ek açıklama..." />
              </div>
            </div>

            <div className="flex gap-3 mt-5">
              <button onClick={() => { setShowEqForm(false); setEditingEq(null) }}
                className="flex-1 border border-gray-300 text-gray-700 py-2 rounded-lg text-sm hover:bg-gray-50">
                İptal
              </button>
              <button onClick={handleSaveEq} disabled={savingEq}
                className="flex-1 bg-indigo-600 text-white py-2 rounded-lg text-sm hover:bg-indigo-700 disabled:opacity-50 flex items-center justify-center gap-2">
                {savingEq ? <LoadingSpinner size="sm" /> : null}
                {editingEq ? 'Güncelle' : 'Ekle'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
