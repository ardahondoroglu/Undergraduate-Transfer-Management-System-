import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '@/store/authStore'
import { applicationsApi } from '@/api/applications'
import { notificationsApi } from '@/api/notifications'

export default function DashboardPage() {
  const user = useAuthStore((s) => s.user)
  const navigate = useNavigate()
  const [activeApps, setActiveApps] = useState(0)
  const [unreadNotifs, setUnreadNotifs] = useState(0)
  const [hasApps, setHasApps] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      applicationsApi.getAll(),
      notificationsApi.getAll(),
    ]).then(([appsRes, notifsRes]) => {
      const apps = appsRes.data.data || []
      const notifs = notifsRes.data.data || []
      const active = apps.filter(a =>
        !['WITHDRAWN', 'FINALIZED', 'APPROVED', 'REJECTED'].includes(a.status)
      )
      setActiveApps(active.length)
      setUnreadNotifs(notifs.filter(n => !n.isRead).length)
      setHasApps(apps.length > 0)
    }).catch(() => {}).finally(() => setLoading(false))
  }, [])

  const stats = [
    {
      label: 'Aktif Başvuru',
      value: loading ? '–' : String(activeApps),
      color: 'text-blue-700',
      onClick: () => navigate('/applications'),
    },
    {
      label: 'Okunmamış Bildirim',
      value: loading ? '–' : String(unreadNotifs),
      color: 'text-purple-700',
      onClick: () => navigate('/notifications'),
    },
  ]

  return (
    <div>
      <h2 className="text-xl font-semibold text-gray-900 mb-1">
        Hoş geldin, {user?.firstName}
      </h2>
      <p className="text-sm text-gray-500 mb-6">
        Yatay geçiş başvurularınıza genel bakış.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {stats.map((stat) => (
          <button
            key={stat.label}
            onClick={stat.onClick}
            className="card p-5 text-left hover:border-gray-300 transition-colors"
          >
            <p className="text-sm text-gray-500">{stat.label}</p>
            <p className={`text-3xl font-bold mt-1 ${stat.color}`}>{stat.value}</p>
          </button>
        ))}
      </div>

      {!loading && !hasApps && (
        <div className="card p-6 text-center text-gray-400">
          <p className="text-sm">Henüz başvurunuz yok.</p>
          <button
            onClick={() => navigate('/applications/new')}
            className="mt-2 inline-block text-sm text-gray-700 font-medium underline"
          >
            Yeni başvuru oluştur →
          </button>
        </div>
      )}

      {!loading && hasApps && (
        <div className="card p-6 text-center">
          <button
            onClick={() => navigate('/applications')}
            className="text-sm text-gray-700 font-medium underline"
          >
            Tüm başvurularımı görüntüle →
          </button>
        </div>
      )}
    </div>
  )
}
