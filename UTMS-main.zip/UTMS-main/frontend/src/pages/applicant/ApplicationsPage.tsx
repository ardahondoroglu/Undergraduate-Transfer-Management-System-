import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { applicationsApi } from '@/api/applications'
import type { Application } from '@/types'

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  DRAFT:                  { label: 'Taslak',               color: 'bg-gray-100 text-gray-700' },
  SUBMITTED:              { label: 'Gönderildi',           color: 'bg-blue-100 text-blue-700' },
  UNDER_REVIEW:           { label: 'İnceleniyor',          color: 'bg-yellow-100 text-yellow-700' },
  RETURNED_FOR_CORRECTION:{ label: 'Düzeltme Gerekli',     color: 'bg-orange-100 text-orange-700' },
  PENDING_VERIFICATION:   { label: 'Doğrulama Bekliyor',   color: 'bg-purple-100 text-purple-700' },
  ELIGIBLE:               { label: 'Uygun',                color: 'bg-green-100 text-green-700' },
  INELIGIBLE:             { label: 'Uygun Değil',          color: 'bg-red-100 text-red-700' },
  UNDER_YGK_EVALUATION:   { label: 'YGK Değerlendirmesi',  color: 'bg-indigo-100 text-indigo-700' },
  ACADEMICALLY_EVALUATED: { label: 'Akademik Değerlendirildi', color: 'bg-teal-100 text-teal-700' },
  RANKING_IN_PROGRESS:    { label: 'Sıralama Yapılıyor',   color: 'bg-cyan-100 text-cyan-700' },
  FORWARDED_TO_FACULTY:   { label: 'Fakülteye Yönlendirildi', color: 'bg-sky-100 text-sky-700' },
  APPROVED:               { label: 'Onaylandı',            color: 'bg-green-100 text-green-800' },
  REJECTED:               { label: 'Reddedildi',           color: 'bg-red-100 text-red-800' },
  WITHDRAWN:              { label: 'Geri Çekildi',         color: 'bg-gray-100 text-gray-500' },
  FINALIZED:              { label: 'Sonuçlandırıldı',      color: 'bg-gray-200 text-gray-700' },
}

const TRANSFER_LABELS: Record<string, string> = {
  INTERNAL:     'Kurum İçi',
  EXTERNAL:     'Kurum Dışı',
  DOUBLE_MAJOR: 'Çift Anadal',
  MINOR:        'Yandal',
}

export default function ApplicationsPage() {
  const navigate = useNavigate()
  const [applications, setApplications] = useState<Application[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    applicationsApi.getAll()
      .then(res => setApplications(res.data.data || []))
      .catch(() => toast.error('Başvurular yüklenemedi.'))
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-48">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-gray-900">Başvurularım</h2>
          <p className="text-sm text-gray-500 mt-1">Tüm transfer başvurularınızı buradan takip edebilirsiniz.</p>
        </div>
        <button onClick={() => navigate('/applications/new')} className="btn-primary">
          + Yeni Başvuru
        </button>
      </div>

      {applications.length === 0 ? (
        <div className="card p-10 text-center text-gray-400">
          <p className="text-sm mb-3">Henüz bir başvurunuz yok.</p>
          <button onClick={() => navigate('/applications/new')}
            className="text-sm text-blue-600 font-medium hover:underline">
            İlk başvurunuzu oluşturun →
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {applications.map(app => {
            const statusInfo = STATUS_LABELS[app.status] || { label: app.status, color: 'bg-gray-100 text-gray-700' }
            return (
              <div key={app.id}
                onClick={() => navigate(`/applications/${app.id}`)}
                className="card p-5 cursor-pointer hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium text-gray-500">
                        {TRANSFER_LABELS[app.transferType]}
                      </span>
                      <span className="text-gray-300">•</span>
                      <span className="text-xs text-gray-500">{app.academicYear}</span>
                    </div>
                    <p className="font-medium text-gray-900">{app.targetProgram}</p>
                    <p className="text-sm text-gray-500 mt-0.5">
                      {app.previousUniversity} — {app.currentProgram}
                    </p>
                  </div>
                  <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${statusInfo.color}`}>
                    {statusInfo.label}
                  </span>
                </div>
                <p className="text-xs text-gray-400 mt-3">
                  {app.submittedAt
                    ? `Gönderildi: ${new Date(app.submittedAt).toLocaleDateString('tr-TR')}`
                    : `Oluşturuldu: ${new Date(app.createdAt).toLocaleDateString('tr-TR')}`}
                </p>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
