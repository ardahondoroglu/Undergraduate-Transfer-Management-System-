import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import toast from 'react-hot-toast'
import { ArrowLeft } from 'lucide-react'
import { applicationsApi, type CreateApplicationRequest } from '@/api/applications'
import LoadingSpinner from '@/components/ui/LoadingSpinner'

const TRANSFER_TYPES = [
  { value: 'INTERNAL',     label: 'Kurum İçi Yatay Geçiş' },
  { value: 'EXTERNAL',     label: 'Kurum Dışı Yatay Geçiş' },
  { value: 'DOUBLE_MAJOR', label: 'Çift Anadal' },
  { value: 'MINOR',        label: 'Yandal' },
] as const

const CURRENT_YEAR = new Date().getFullYear()
const ACADEMIC_YEARS = [
  `${CURRENT_YEAR}-${CURRENT_YEAR + 1}`,
  `${CURRENT_YEAR - 1}-${CURRENT_YEAR}`,
]

export default function EditApplicationPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)

  const { register, handleSubmit, reset, formState: { errors } } = useForm<CreateApplicationRequest>()

  useEffect(() => {
    if (!id) return
    applicationsApi.getById(id)
      .then(res => {
        const app = res.data.data!
        reset({
          transferType:       app.transferType,
          academicYear:       app.academicYear,
          previousUniversity: app.previousUniversity,
          currentProgram:     app.currentProgram,
          targetProgram:      app.targetProgram,
          currentGpa:         String(app.currentGpa),
          currentSemester:    app.currentSemester,
          targetSemester:     app.targetSemester,
          reasonForTransfer:  app.reasonForTransfer,
        })
      })
      .catch(() => toast.error('Başvuru yüklenemedi.'))
      .finally(() => setLoading(false))
  }, [id, reset])

  const onSave = handleSubmit(async (data) => {
    if (!id) return
    try {
      setSubmitting(true)
      await applicationsApi.update(id, data)
      toast.success('Başvuru güncellendi.')
      navigate(`/applications/${id}`)
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Bir hata oluştu.')
    } finally {
      setSubmitting(false)
    }
  })

  if (loading) return (
    <div className="flex items-center justify-center h-48">
      <LoadingSpinner size="lg" />
    </div>
  )

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6 flex items-center gap-3">
        <button onClick={() => navigate(`/applications/${id}`)}
          className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-900">
          <ArrowLeft size={16} />
        </button>
        <div>
          <h2 className="text-xl font-semibold text-gray-900">Başvuruyu Düzenle</h2>
          <p className="text-sm text-gray-500 mt-0.5">Bilgileri güncelleyip kaydedin.</p>
        </div>
      </div>

      <div className="card p-6 space-y-5">
        {/* Transfer Type */}
        <div>
          <label className="label">Başvuru Türü *</label>
          <select {...register('transferType', { required: true })} className="input-field">
            {TRANSFER_TYPES.map(t => (
              <option key={t.value} value={t.value}>{t.label}</option>
            ))}
          </select>
        </div>

        {/* Academic Year */}
        <div>
          <label className="label">Akademik Yıl *</label>
          <select {...register('academicYear', { required: true })} className="input-field">
            {ACADEMIC_YEARS.map(y => <option key={y} value={y}>{y}</option>)}
          </select>
        </div>

        {/* Previous University */}
        <div>
          <label className="label">Kayıtlı Olduğunuz Üniversite *</label>
          <input
            {...register('previousUniversity', { required: 'Bu alan zorunludur.' })}
            className={`input-field ${errors.previousUniversity ? 'input-error' : ''}`}
            placeholder="İstanbul Teknik Üniversitesi"
          />
          {errors.previousUniversity && <p className="error-message">{errors.previousUniversity.message}</p>}
        </div>

        {/* Current Program */}
        <div>
          <label className="label">Kayıtlı Olduğunuz Program *</label>
          <input
            {...register('currentProgram', { required: 'Bu alan zorunludur.' })}
            className={`input-field ${errors.currentProgram ? 'input-error' : ''}`}
            placeholder="Bilgisayar Mühendisliği"
          />
          {errors.currentProgram && <p className="error-message">{errors.currentProgram.message}</p>}
        </div>

        {/* Target Program */}
        <div>
          <label className="label">Geçmek İstediğiniz Program *</label>
          <input
            {...register('targetProgram', { required: 'Bu alan zorunludur.' })}
            className={`input-field ${errors.targetProgram ? 'input-error' : ''}`}
            placeholder="Elektrik-Elektronik Mühendisliği"
          />
          {errors.targetProgram && <p className="error-message">{errors.targetProgram.message}</p>}
        </div>

        {/* GPA & Semesters */}
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="label">GPA (0–4) *</label>
            <input
              {...register('currentGpa', {
                required: 'Zorunlu.',
                pattern: { value: /^\d+(\.\d{1,2})?$/, message: 'Örn: 3.50' },
                validate: v => (parseFloat(v) >= 0 && parseFloat(v) <= 4) || '0–4 arası',
              })}
              className={`input-field ${errors.currentGpa ? 'input-error' : ''}`}
              placeholder="3.50"
            />
            {errors.currentGpa && <p className="error-message">{errors.currentGpa.message}</p>}
          </div>
          <div>
            <label className="label">Mevcut Dönem *</label>
            <input
              type="number"
              {...register('currentSemester', { required: true, min: 1, max: 12, valueAsNumber: true })}
              className="input-field"
              min={1} max={12}
            />
          </div>
          <div>
            <label className="label">Hedef Dönem *</label>
            <input
              type="number"
              {...register('targetSemester', { required: true, min: 1, max: 12, valueAsNumber: true })}
              className="input-field"
              min={1} max={12}
            />
          </div>
        </div>

        {/* Reason */}
        <div>
          <label className="label">Geçiş Gerekçesi</label>
          <textarea
            {...register('reasonForTransfer')}
            rows={4}
            className="input-field resize-none"
            placeholder="Neden bu programa geçmek istediğinizi açıklayın..."
          />
        </div>

        {/* Actions */}
        <div className="flex gap-3 pt-2">
          <button
            type="button"
            onClick={() => navigate(`/applications/${id}`)}
            disabled={submitting}
            className="flex-1 border border-gray-300 text-gray-700 py-3 px-4 rounded-lg font-medium hover:bg-gray-50 transition-colors disabled:opacity-50"
          >
            İptal
          </button>
          <button
            type="button"
            onClick={onSave}
            disabled={submitting}
            className="flex-1 btn-primary flex items-center justify-center gap-2"
          >
            {submitting ? <LoadingSpinner size="sm" /> : null}
            {submitting ? 'Kaydediliyor...' : 'Değişiklikleri Kaydet'}
          </button>
        </div>
      </div>
    </div>
  )
}
