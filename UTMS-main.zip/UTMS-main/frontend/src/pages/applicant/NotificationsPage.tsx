import { useEffect } from 'react'
import toast from 'react-hot-toast'
import { Bell, CheckCheck } from 'lucide-react'
import { notificationsApi } from '@/api/notifications'
import { useNotificationStore } from '@/store/notificationStore'
import LoadingSpinner from '@/components/ui/LoadingSpinner'
import { useState } from 'react'

export default function NotificationsPage() {
  const notifications = useNotificationStore((s) => s.notifications)
  const unreadCount = useNotificationStore((s) => s.unreadCount)
  const setNotifications = useNotificationStore((s) => s.setNotifications)
  const markAsRead = useNotificationStore((s) => s.markAsRead)
  const markAllAsRead = useNotificationStore((s) => s.markAllAsRead)
  const [loading, setLoading] = useState(true)
  const [markingAll, setMarkingAll] = useState(false)

  useEffect(() => {
    notificationsApi.getAll()
      .then(res => setNotifications(res.data.data || []))
      .catch(() => toast.error('Bildirimler yüklenemedi.'))
      .finally(() => setLoading(false))
  }, [setNotifications])

  const handleMarkAsRead = async (id: string) => {
    try {
      await notificationsApi.markAsRead(id)
      markAsRead(id)
    } catch {
      toast.error('İşlem başarısız.')
    }
  }

  const handleMarkAllAsRead = async () => {
    try {
      setMarkingAll(true)
      await notificationsApi.markAllAsRead()
      markAllAsRead()
      toast.success('Tüm bildirimler okundu olarak işaretlendi.')
    } catch {
      toast.error('İşlem başarısız.')
    } finally {
      setMarkingAll(false)
    }
  }

  if (loading) return (
    <div className="flex items-center justify-center h-48">
      <LoadingSpinner size="lg" />
    </div>
  )

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
            <Bell size={20} /> Bildirimler
            {unreadCount > 0 && (
              <span className="text-xs bg-gray-900 text-white rounded-full px-2 py-0.5">
                {unreadCount}
              </span>
            )}
          </h2>
          <p className="text-sm text-gray-500 mt-1">Başvurularınızla ilgili güncellemeler</p>
        </div>
        {unreadCount > 0 && (
          <button
            onClick={handleMarkAllAsRead}
            disabled={markingAll}
            className="flex items-center gap-1.5 text-sm border border-gray-300 text-gray-700 px-3 py-1.5 rounded-lg hover:bg-gray-50 disabled:opacity-50"
          >
            {markingAll ? <LoadingSpinner size="sm" /> : <CheckCheck size={14} />}
            Tümünü Okundu İşaretle
          </button>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="card p-12 text-center">
          <Bell size={32} className="mx-auto text-gray-300 mb-3" />
          <p className="text-sm text-gray-400">Henüz bildiriminiz yok.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {notifications.map(notification => (
            <div
              key={notification.id}
              className={`card p-4 flex items-start gap-3 transition-colors ${
                !notification.isRead ? 'border-gray-300 bg-blue-50/40' : ''
              }`}
            >
              <div className={`mt-1 w-2 h-2 rounded-full flex-shrink-0 ${
                !notification.isRead ? 'bg-blue-500' : 'bg-transparent'
              }`} />
              <div className="flex-1 min-w-0">
                <p className={`text-sm text-gray-900 ${!notification.isRead ? 'font-semibold' : 'font-medium'}`}>
                  {notification.title}
                </p>
                <p className="text-sm text-gray-600 mt-0.5">{notification.message}</p>
                <p className="text-xs text-gray-400 mt-1">
                  {new Date(notification.createdAt).toLocaleString('tr-TR')}
                </p>
              </div>
              {!notification.isRead && (
                <button
                  onClick={() => handleMarkAsRead(notification.id)}
                  className="text-xs text-gray-500 hover:text-gray-900 whitespace-nowrap flex-shrink-0"
                >
                  Okundu
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
