import { useEffect, useState, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { FileText, Upload, Trash2, Download, ArrowLeft, Edit, XCircle } from 'lucide-react'
import { applicationsApi } from '@/api/applications'
import { documentsApi } from '@/api/documents'
import type { Application, Document, DocumentType } from '@/types'
import LoadingSpinner from '@/components/ui/LoadingSpinner'

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  DRAFT:                   { label: 'Taslak',                color: 'bg-gray-100 text-gray-700' },
  SUBMITTED:               { label: 'Gönderildi',            color: 'bg-blue-100 text-blue-700' },
  UNDER_REVIEW:            { label: 'İnceleniyor',           color: 'bg-yellow-100 text-yellow-700' },
  RETURNED_FOR_CORRECTION: { label: 'Düzeltme Gerekli',      color: 'bg-orange-100 text-orange-700' },
  PENDING_VERIFICATION:    { label: 'Doğrulama Bekliyor',    color: 'bg-purple-100 text-purple-700' },
  ELIGIBLE:                { label: 'Uygun',                 color: 'bg-green-100 text-green-700' },
  INELIGIBLE:              { label: 'Uygun Değil',           color: 'bg-red-100 text-red-700' },
  UNDER_YGK_EVALUATION:    { label: 'YGK Değerlendirmesi',   color: 'bg-indigo-100 text-indigo-700' },
  ACADEMICALLY_EVALUATED:  { label: 'Akademik Değerlendirildi', color: 'bg-teal-100 text-teal-700' },
  RANKING_IN_PROGRESS:     { label: 'Sıralama Yapılıyor',    color: 'bg-cyan-100 text-cyan-700' },
  FORWARDED_TO_FACULTY:    { label: 'Fakülteye Yönlendirildi', color: 'bg-sky-100 text-sky-700' },
  APPROVED:                { label: 'Onaylandı',             color: 'bg-green-100 text-green-800' },
  REJECTED:                { label: 'Reddedildi',            color: 'bg-red-100 text-red-800' },
  WITHDRAWN:               { label: 'Geri Çekildi',          color: 'bg-gray-100 text-gray-500' },
  FINALIZED:               { label: 'Sonuçlandırıldı',       color: 'bg-gray-200 text-gray-700' },
}

const TRANSFER_LABELS: Record<string, string> = {
  INTERNAL: 'Kurum İçi', EXTERNAL: 'Kurum Dışı',
  DOUBLE_MAJOR: 'Çift Anadal', MINOR: 'Yandal',
}

const DOC_TYPE_LABELS: Record<string, string> = {
  TRANSCRIPT: 'Transkript', COURSE_DESCRIPTION: 'Ders İçerikleri',
  STUDENT_ID: 'Öğrenci Kimliği', ENGLISH_CERTIFICATE: 'İngilizce Belgesi',
  PLACEMENT_RESULT: 'Yerleştirme Sonucu', OTHER: 'Diğer',
}

const DOC_STATUS_STYLES: Record<string, string> = {
  PENDING: 'bg-yellow-100 text-yellow-700',
  VERIFIED: 'bg-green-100 text-green-700',
  REJECTED: 'bg-red-100 text-red-700',
}

const EDITABLE_STATUSES = ['DRAFT', 'SUBMITTED', 'RETURNED_FOR_CORRECTION']
const WITHDRAWABLE_STATUSES = ['DRAFT', 'SUBMITTED', 'RETURNED_FOR_CORRECTION', 'PENDING_VERIFICATION']

export default function ApplicationDetailPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const fileRef = useRef<HTMLInputElement>(null)

  const [app, setApp] = useState<Application | null>(null)
  const [docs, setDocs] = useState<Document[]>([])
  const [loading, setLoading] = useState(true)
  const [uploading, setUploading] = useState(false)
  const [withdrawing, setWithdrawing] = useState(false)
  const [selectedType, setSelectedType] = useState<DocumentType>('TRANSCRIPT')
  const [showWithdrawConfirm, setShowWithdrawConfirm] = useState(false)

  useEffect(() => {
    if (!id) return
    Promise.all([
      applicationsApi.getById(id),
      documentsApi.getByApplication(id),
    ]).then(([appRes, docRes]) => {
      setApp(appRes.data.data!)
      setDocs(docRes.data.data || [])
    }).catch(() => toast.error('Başvuru yüklenemedi.'))
    .finally(() => setLoading(false))
  }, [id])

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !id) return
    try {
      setUploading(true)
      const res = await documentsApi.upload(id, file, selectedType)
      setDocs(prev => [...prev, res.data.data!])
      toast.success('Belge yüklendi.')
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Yükleme başarısız.')
    } finally {
      setUploading(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  const handleDelete = async (docId: string) => {
    try {
      await documentsApi.delete(docId)
      setDocs(prev => prev.filter(d => d.id !== docId))
      toast.success('Belge silindi.')
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Silinemedi.')
    }
  }

  const handleWithdraw = async () => {
    if (!id) return
    try {
      setWithdrawing(true)
      const res = await applicationsApi.withdraw(id)
      setApp(res.data.data!)
      setShowWithdrawConfirm(false)
      toast.success('Başvurunuz geri çekildi.')
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Geri çekme başarısız.')
    } finally {
      setWithdrawing(false)
    }
  }

  if (loading) return (
    <div className="flex items-center justify-center h-48">
      <LoadingSpinner size="lg" />
    </div>
  )

  if (!app) return (
    <div className="text-center text-gray-400 py-16">
      <p>Başvuru bulunamadı.</p>
    </div>
  )

  const statusInfo = STATUS_LABELS[app.status] || { label: app.status, color: 'bg-gray-100 text-gray-700' }
  const canEdit = EDITABLE_STATUSES.includes(app.status)
  const canWithdraw = WITHDRAWABLE_STATUSES.includes(app.status)

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button onClick={() => navigate('/applications')}
          className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-900">
          <ArrowLeft size={16} /> Başvurular
        </button>
        <div className="flex gap-2">
          {canEdit && (
            <button onClick={() => navigate(`/applications/${id}/edit`)}
              className="flex items-center gap-1.5 text-sm border border-gray-300 text-gray-700 px-3 py-1.5 rounded-lg hover:bg-gray-50">
              <Edit size={14} /> Düzenle
            </button>
          )}
          {canWithdraw && (
            <button onClick={() => setShowWithdrawConfirm(true)}
              className="flex items-center gap-1.5 text-sm border border-red-300 text-red-600 px-3 py-1.5 rounded-lg hover:bg-red-50">
              <XCircle size={14} /> Geri Çek
            </button>
          )}
        </div>
      </div>

      {/* Status Card */}
      <div className="card p-5">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs text-gray-500 mb-1">{TRANSFER_LABELS[app.transferType]} • {app.academicYear}</p>
            <h2 className="text-lg font-semibold text-gray-900">{app.targetProgram}</h2>
            <p className="text-sm text-gray-500">{app.previousUniversity} — {app.currentProgram}</p>
          </div>
          <span className={`text-xs font-medium px-3 py-1 rounded-full ${statusInfo.color}`}>
            {statusInfo.label}
          </span>
        </div>

        <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-gray-100">
          <div>
            <p className="text-xs text-gray-400">GPA</p>
            <p className="text-sm font-medium">{app.currentGpa}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400">Mevcut Dönem</p>
            <p className="text-sm font-medium">{app.currentSemester}. Dönem</p>
          </div>
          <div>
            <p className="text-xs text-gray-400">Hedef Dönem</p>
            <p className="text-sm font-medium">{app.targetSemester}. Dönem</p>
          </div>
        </div>

        {app.reasonForTransfer && (
          <div className="mt-4 pt-4 border-t border-gray-100">
            <p className="text-xs text-gray-400 mb-1">Geçiş Gerekçesi</p>
            <p className="text-sm text-gray-700">{app.reasonForTransfer}</p>
          </div>
        )}

        {app.submittedAt && (
          <p className="text-xs text-gray-400 mt-4">
            Gönderildi: {new Date(app.submittedAt).toLocaleString('tr-TR')}
          </p>
        )}
      </div>

      {/* Documents */}
      <div className="card p-5">
        <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <FileText size={16} /> Belgeler
        </h3>

        {docs.length === 0 ? (
          <p className="text-sm text-gray-400 text-center py-4">Henüz belge yüklenmedi.</p>
        ) : (
          <div className="space-y-2 mb-4">
            {docs.map(doc => (
              <div key={doc.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">{doc.fileName}</p>
                  <p className="text-xs text-gray-400">
                    {DOC_TYPE_LABELS[doc.type]} • {(doc.fileSize / 1024).toFixed(0)} KB
                  </p>
                </div>
                <div className="flex items-center gap-2 ml-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${DOC_STATUS_STYLES[doc.status]}`}>
                    {doc.status === 'PENDING' ? 'Beklemede' : doc.status === 'VERIFIED' ? 'Doğrulandı' : 'Reddedildi'}
                  </span>
                  <a href={documentsApi.getDownloadUrl(doc.id)} target="_blank" rel="noreferrer"
                    className="text-gray-400 hover:text-gray-700 p-1">
                    <Download size={14} />
                  </a>
                  {doc.status !== 'VERIFIED' && (
                    <button onClick={() => handleDelete(doc.id)}
                      className="text-gray-400 hover:text-red-600 p-1">
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Upload area */}
        {!['APPROVED', 'REJECTED', 'FINALIZED', 'WITHDRAWN'].includes(app.status) && (
          <div className="border-t border-gray-100 pt-4">
            <div className="flex gap-2">
              <select value={selectedType} onChange={e => setSelectedType(e.target.value as DocumentType)}
                className="input-field flex-1">
                {Object.entries(DOC_TYPE_LABELS).map(([val, lbl]) => (
                  <option key={val} value={val}>{lbl}</option>
                ))}
              </select>
              <input ref={fileRef} type="file" accept=".pdf,.jpg,.jpeg,.png"
                className="hidden" onChange={handleUpload} />
              <button onClick={() => fileRef.current?.click()} disabled={uploading}
                className="flex items-center gap-1.5 border border-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm hover:bg-gray-50 disabled:opacity-50 whitespace-nowrap">
                {uploading ? <LoadingSpinner size="sm" /> : <Upload size={14} />}
                {uploading ? 'Yükleniyor...' : 'Belge Yükle'}
              </button>
            </div>
            <p className="text-xs text-gray-400 mt-2">PDF, JPG veya PNG • Maks. 10 MB</p>
          </div>
        )}
      </div>

      {/* Withdraw Confirm Dialog */}
      {showWithdrawConfirm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-sm w-full mx-4 shadow-xl">
            <h3 className="font-semibold text-gray-900 mb-2">Başvuruyu Geri Çek</h3>
            <p className="text-sm text-gray-500 mb-5">
              Bu işlem geri alınamaz. Başvurunuz kalıcı olarak geri çekilecek ve değerlendirme süreci sona erecektir.
            </p>
            <div className="flex gap-3">
              <button onClick={() => setShowWithdrawConfirm(false)}
                className="flex-1 border border-gray-300 text-gray-700 py-2 rounded-lg text-sm hover:bg-gray-50">
                İptal
              </button>
              <button onClick={handleWithdraw} disabled={withdrawing}
                className="flex-1 bg-red-600 text-white py-2 rounded-lg text-sm hover:bg-red-700 disabled:opacity-50">
                {withdrawing ? 'Geri Çekiliyor...' : 'Evet, Geri Çek'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
