// ─── User & Auth ────────────────────────────────────────────────────────────

export type UserRole = 'APPLICANT' | 'OIDB_STAFF' | 'YGK' | 'FACULTY_BOARD' | 'YDYO'

export interface User {
  id: string
  studentId: string
  firstName: string
  lastName: string
  email: string
  role: UserRole
  isVerified: boolean
  createdAt: string
}

export interface AuthState {
  user: User | null
  token: string | null
  isAuthenticated: boolean
}

// ─── Application ────────────────────────────────────────────────────────────

export type ApplicationStatus =
  | 'DRAFT'
  | 'SUBMITTED'
  | 'UNDER_REVIEW'
  | 'RETURNED_FOR_CORRECTION'
  | 'PENDING_VERIFICATION'
  | 'ELIGIBLE'
  | 'INELIGIBLE'
  | 'UNDER_YGK_EVALUATION'
  | 'ACADEMICALLY_EVALUATED'
  | 'RANKING_IN_PROGRESS'
  | 'FORWARDED_TO_FACULTY'
  | 'APPROVED'
  | 'REJECTED'
  | 'WITHDRAWN'
  | 'FINALIZED'

export type TransferType = 'INTERNAL' | 'EXTERNAL' | 'DOUBLE_MAJOR' | 'MINOR'

export interface Application {
  id: string
  applicantId: string
  transferType: TransferType
  previousUniversity: string
  currentProgram: string
  targetProgram: string
  currentGpa: number
  currentSemester: number
  targetSemester: number
  academicYear: string
  reasonForTransfer?: string
  status: ApplicationStatus
  submittedAt?: string
  createdAt: string
  updatedAt: string
}

// ─── Document ────────────────────────────────────────────────────────────────

export type DocumentType =
  | 'TRANSCRIPT'
  | 'COURSE_DESCRIPTION'
  | 'STUDENT_ID'
  | 'ENGLISH_CERTIFICATE'
  | 'PLACEMENT_RESULT'
  | 'OTHER'

export type DocumentStatus = 'PENDING' | 'VERIFIED' | 'REJECTED'

export interface Document {
  id: string
  applicationId: string
  type: DocumentType
  fileName: string
  fileSize: number
  mimeType: string
  status: DocumentStatus
  uploadedAt: string
  verifiedAt?: string
  rejectionReason?: string
}

// ─── Notification ────────────────────────────────────────────────────────────

export interface Notification {
  id: string
  userId: string
  title: string
  message: string
  isRead: boolean
  createdAt: string
}

// ─── API Response ────────────────────────────────────────────────────────────

export interface ApiResponse<T> {
  success: boolean
  data?: T
  message?: string
  errors?: Record<string, string[]>
}

export interface PaginatedResponse<T> {
  data: T[]
  total: number
  page: number
  limit: number
  totalPages: number
}
