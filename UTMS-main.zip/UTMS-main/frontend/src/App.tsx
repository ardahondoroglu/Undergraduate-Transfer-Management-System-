import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuthStore } from '@/store/authStore'

// Layouts
import AppLayout from '@/components/layout/AppLayout'

// Auth pages
import LoginPage from '@/pages/auth/LoginPage'
import RegisterPage from '@/pages/auth/RegisterPage'
import ForgotPasswordPage from '@/pages/auth/ForgotPasswordPage'
import VerifyEmailPage from '@/pages/auth/VerifyEmailPage'

// Applicant pages
import DashboardPage from '@/pages/applicant/DashboardPage'
import ApplicationsPage from '@/pages/applicant/ApplicationsPage'
import NewApplicationPage from '@/pages/applicant/NewApplicationPage'
import ApplicationDetailPage from '@/pages/applicant/ApplicationDetailPage'
import EditApplicationPage from '@/pages/applicant/EditApplicationPage'
import NotificationsPage from '@/pages/applicant/NotificationsPage'

// Staff pages
import StaffApplicationsPage from '@/pages/staff/StaffApplicationsPage'
import StaffApplicationDetailPage from '@/pages/staff/StaffApplicationDetailPage'

// YGK pages
import YgkApplicationsPage from '@/pages/ygk/YgkApplicationsPage'
import YgkApplicationDetailPage from '@/pages/ygk/YgkApplicationDetailPage'
import RankingPage from '@/pages/ygk/RankingPage'

// YDYO pages
import YdyoApplicationsPage from '@/pages/ydyo/YdyoApplicationsPage'
import YdyoApplicationDetailPage from '@/pages/ydyo/YdyoApplicationDetailPage'

// Faculty Board pages
import FacultyApplicationsPage from '@/pages/faculty/FacultyApplicationsPage'
import FacultyApplicationDetailPage from '@/pages/faculty/FacultyApplicationDetailPage'

// Route guard
function PrivateRoute({ children }: { children: React.ReactNode }) {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" replace />
}

function PublicRoute({ children }: { children: React.ReactNode }) {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)
  return !isAuthenticated ? <>{children}</> : <Navigate to="/dashboard" replace />
}

export default function App() {
  return (
    <Routes>
      {/* Public routes */}
      <Route path="/login" element={<PublicRoute><LoginPage /></PublicRoute>} />
      <Route path="/register" element={<PublicRoute><RegisterPage /></PublicRoute>} />
      <Route path="/forgot-password" element={<PublicRoute><ForgotPasswordPage /></PublicRoute>} />
      <Route path="/verify-email" element={<VerifyEmailPage />} />

      {/* Protected routes */}
      <Route
        element={
          <PrivateRoute>
            <AppLayout />
          </PrivateRoute>
        }
      >
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/applications" element={<ApplicationsPage />} />
        <Route path="/applications/new" element={<NewApplicationPage />} />
        <Route path="/applications/:id" element={<ApplicationDetailPage />} />
        <Route path="/applications/:id/edit" element={<EditApplicationPage />} />
        <Route path="/notifications" element={<NotificationsPage />} />

        {/* ÖİDB Staff routes */}
        <Route path="/staff/applications" element={<StaffApplicationsPage />} />
        <Route path="/staff/applications/:id" element={<StaffApplicationDetailPage />} />

        {/* YGK routes */}
        <Route path="/ygk/applications" element={<YgkApplicationsPage />} />
        <Route path="/ygk/applications/:id" element={<YgkApplicationDetailPage />} />
        <Route path="/ygk/ranking" element={<RankingPage />} />

        {/* YDYO routes */}
        <Route path="/ydyo/applications" element={<YdyoApplicationsPage />} />
        <Route path="/ydyo/applications/:id" element={<YdyoApplicationDetailPage />} />

        {/* Faculty Board routes */}
        <Route path="/faculty/applications" element={<FacultyApplicationsPage />} />
        <Route path="/faculty/applications/:id" element={<FacultyApplicationDetailPage />} />
      </Route>

      {/* Default redirect */}
      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  )
}
