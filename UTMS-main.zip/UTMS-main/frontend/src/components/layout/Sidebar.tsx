import { NavLink, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard,
  FileText,
  Bell,
  LogOut,
  ClipboardList,
  Trophy,
  Languages,
  Scale,
} from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { useNotificationStore } from '@/store/notificationStore'
import { authApi } from '@/api/auth'
import clsx from 'clsx'

const APPLICANT_NAV = [
  { to: '/dashboard',     label: 'Ana Sayfa',      icon: LayoutDashboard },
  { to: '/applications',  label: 'Başvurularım',   icon: FileText },
  { to: '/notifications', label: 'Bildirimler',    icon: Bell, badge: true },
]

const STAFF_NAV = [
  { to: '/dashboard',            label: 'Ana Sayfa',   icon: LayoutDashboard },
  { to: '/staff/applications',   label: 'Başvurular',  icon: ClipboardList },
  { to: '/notifications',        label: 'Bildirimler', icon: Bell, badge: true },
]

const YGK_NAV = [
  { to: '/dashboard',          label: 'Ana Sayfa',      icon: LayoutDashboard },
  { to: '/ygk/applications',   label: 'Başvurular',     icon: ClipboardList },
  { to: '/ygk/ranking',        label: 'Sıralama',       icon: Trophy },
  { to: '/notifications',      label: 'Bildirimler',    icon: Bell, badge: true },
]

const YDYO_NAV = [
  { to: '/dashboard',           label: 'Ana Sayfa',    icon: LayoutDashboard },
  { to: '/ydyo/applications',   label: 'Başvurular',   icon: Languages },
  { to: '/notifications',       label: 'Bildirimler',  icon: Bell, badge: true },
]

const FACULTY_NAV = [
  { to: '/dashboard',              label: 'Ana Sayfa',    icon: LayoutDashboard },
  { to: '/faculty/applications',   label: 'Başvurular',   icon: Scale },
  { to: '/notifications',          label: 'Bildirimler',  icon: Bell, badge: true },
]

export default function Sidebar() {
  const navigate = useNavigate()
  const user = useAuthStore((s) => s.user)
  const logout = useAuthStore((s) => s.logout)
  const unreadCount = useNotificationStore((s) => s.unreadCount)

  const handleLogout = async () => {
    try { await authApi.logout() } catch { /* ignore */ }
    logout()
    navigate('/login')
  }

  const navItems =
    user?.role === 'OIDB_STAFF'    ? STAFF_NAV :
    user?.role === 'YGK'           ? YGK_NAV :
    user?.role === 'YDYO'          ? YDYO_NAV :
    user?.role === 'FACULTY_BOARD' ? FACULTY_NAV :
    APPLICANT_NAV

  return (
    <aside className="w-56 min-h-screen bg-white border-r border-gray-200 flex flex-col">
      {/* Logo */}
      <div className="px-4 py-5 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <img src="/iztech-logo.png" alt="IZTECH" className="w-7 h-7 object-contain" />
          <span className="text-xs font-semibold text-gray-700 leading-tight">
            UTMS<br />
            <span className="font-normal text-gray-400">
              {user?.role === 'OIDB_STAFF'    ? 'ÖİDB Paneli' :
             user?.role === 'YGK'           ? 'YGK Paneli' :
             user?.role === 'YDYO'          ? 'YDYO Paneli' :
             user?.role === 'FACULTY_BOARD' ? 'Fakülte Paneli' :
             'Transfer Portal'}
            </span>
          </span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-2 py-4 space-y-0.5">
        {navItems.map(({ to, label, icon: Icon, badge }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              clsx('sidebar-link', isActive && 'active')
            }
          >
            <Icon size={17} />
            <span>{label}</span>
            {badge && unreadCount > 0 && (
              <span className="ml-auto bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Role badge + Logout */}
      <div className="px-2 py-4 border-t border-gray-100 space-y-1">
        {user?.role === 'OIDB_STAFF' && (
          <div className="px-4 py-1.5 mb-1">
            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-medium">
              ÖİDB Personeli
            </span>
          </div>
        )}
        {user?.role === 'YGK' && (
          <div className="px-4 py-1.5 mb-1">
            <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full font-medium">
              YGK Üyesi
            </span>
          </div>
        )}
        {user?.role === 'YDYO' && (
          <div className="px-4 py-1.5 mb-1">
            <span className="text-xs bg-teal-100 text-teal-700 px-2 py-0.5 rounded-full font-medium">
              YDYO Personeli
            </span>
          </div>
        )}
        {user?.role === 'FACULTY_BOARD' && (
          <div className="px-4 py-1.5 mb-1">
            <span className="text-xs bg-sky-100 text-sky-700 px-2 py-0.5 rounded-full font-medium">
              Fakülte Kurulu
            </span>
          </div>
        )}
        <button
          onClick={handleLogout}
          className="sidebar-link w-full text-red-600 hover:bg-red-50 hover:text-red-700"
        >
          <LogOut size={17} />
          <span>Çıkış Yap</span>
        </button>
      </div>
    </aside>
  )
}
