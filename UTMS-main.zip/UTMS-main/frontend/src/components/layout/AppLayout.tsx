import { useEffect } from 'react'
import { Outlet } from 'react-router-dom'
import Sidebar from './Sidebar'
import Header from './Header'
import { notificationsApi } from '@/api/notifications'
import { useNotificationStore } from '@/store/notificationStore'

export default function AppLayout() {
  const setNotifications = useNotificationStore((s) => s.setNotifications)

  useEffect(() => {
    notificationsApi.getAll()
      .then(res => setNotifications(res.data.data || []))
      .catch(() => {})
  }, [setNotifications])

  return (
    <div className="flex h-screen overflow-hidden bg-gray-50">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
        <footer className="py-3 px-6 text-center text-xs text-gray-400 border-t border-gray-100 bg-white">
          Need assistance? Contact{' '}
          <a href="mailto:admissions@iyte.edu.tr" className="text-gray-600 hover:underline">
            admissions@iyte.edu.tr
          </a>{' '}
          or call (232) 750 60 00
        </footer>
      </div>
    </div>
  )
}
