import { Search, ChevronDown } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { useState } from 'react'

export default function Header() {
  const user = useAuthStore((s) => s.user)
  const [searchValue, setSearchValue] = useState('')

  return (
    <header className="h-14 bg-white border-b border-gray-200 flex items-center justify-between px-6">
      {/* System name */}
      <h1 className="text-sm font-semibold text-gray-800 hidden md:block">
        UTMS – Undergraduate Transfer Management System
      </h1>

      <div className="flex items-center gap-4 ml-auto">
        {/* Search */}
        <div className="relative hidden md:block">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search applications, documents..."
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            className="pl-9 pr-4 py-2 text-sm border border-gray-200 rounded-lg bg-gray-50
                       focus:outline-none focus:ring-2 focus:ring-gray-300 focus:bg-white w-64 transition"
          />
        </div>

        {/* User info */}
        <div className="flex items-center gap-2 cursor-pointer group">
          <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
            <span className="text-xs font-semibold text-gray-600">
              {user?.firstName?.[0]}{user?.lastName?.[0]}
            </span>
          </div>
          <div className="hidden md:block text-right">
            <p className="text-sm font-medium text-gray-900 leading-none">
              {user?.firstName} {user?.lastName}
            </p>
            <p className="text-xs text-gray-500 capitalize">{user?.role?.toLowerCase().replace('_', ' ')}</p>
          </div>
          <ChevronDown size={14} className="text-gray-400 group-hover:text-gray-600 transition" />
        </div>
      </div>
    </header>
  )
}
