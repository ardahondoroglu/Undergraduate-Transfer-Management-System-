import clsx from 'clsx'
import type { ApplicationStatus } from '@/types'

const STATUS_MAP: Record<ApplicationStatus, { label: string; className: string }> = {
  DRAFT:                    { label: 'Draft',                   className: 'bg-yellow-100 text-yellow-700' },
  SUBMITTED:                { label: 'Submitted',               className: 'bg-blue-100 text-blue-700' },
  UNDER_REVIEW:             { label: 'Under Review',            className: 'bg-purple-100 text-purple-700' },
  RETURNED_FOR_CORRECTION:  { label: 'Correction Required',     className: 'bg-orange-100 text-orange-700' },
  PENDING_VERIFICATION:     { label: 'Pending Verification',    className: 'bg-indigo-100 text-indigo-700' },
  ELIGIBLE:                 { label: 'Eligible',                className: 'bg-green-100 text-green-700' },
  INELIGIBLE:               { label: 'Ineligible',              className: 'bg-red-100 text-red-700' },
  UNDER_YGK_EVALUATION:     { label: 'YGK Evaluation',          className: 'bg-purple-100 text-purple-700' },
  ACADEMICALLY_EVALUATED:   { label: 'Academically Evaluated',  className: 'bg-teal-100 text-teal-700' },
  RANKING_IN_PROGRESS:      { label: 'Ranking',                 className: 'bg-cyan-100 text-cyan-700' },
  FORWARDED_TO_FACULTY:     { label: 'At Faculty Board',        className: 'bg-violet-100 text-violet-700' },
  APPROVED:                 { label: 'Approved',                className: 'bg-green-100 text-green-800' },
  REJECTED:                 { label: 'Rejected',                className: 'bg-red-100 text-red-800' },
  WITHDRAWN:                { label: 'Withdrawn',               className: 'bg-gray-100 text-gray-600' },
  FINALIZED:                { label: 'Finalized',               className: 'bg-gray-900 text-white' },
}

interface Props {
  status: ApplicationStatus
  size?: 'sm' | 'md'
}

export default function StatusBadge({ status, size = 'sm' }: Props) {
  const { label, className } = STATUS_MAP[status] ?? { label: status, className: 'bg-gray-100 text-gray-600' }

  return (
    <span
      className={clsx(
        'inline-flex items-center rounded-full font-medium',
        size === 'sm' ? 'px-2.5 py-0.5 text-xs' : 'px-3 py-1 text-sm',
        className
      )}
    >
      {label}
    </span>
  )
}
