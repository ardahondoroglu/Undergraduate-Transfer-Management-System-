import { apiClient } from './client'
import type { ApiResponse, Notification } from '@/types'

export const notificationsApi = {
  getAll: () =>
    apiClient.get<ApiResponse<Notification[]>>('/notifications'),

  markAsRead: (id: string) =>
    apiClient.patch<ApiResponse<Notification>>(`/notifications/${id}/read`),

  markAllAsRead: () =>
    apiClient.patch<ApiResponse<{ message: string }>>('/notifications/read-all'),
}
