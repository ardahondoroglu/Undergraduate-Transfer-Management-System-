import { apiClient } from './client'
import type { ApiResponse, Application } from '@/types'

export interface CreateApplicationRequest {
  transferType: 'INTERNAL' | 'EXTERNAL' | 'DOUBLE_MAJOR' | 'MINOR'
  previousUniversity: string
  currentProgram: string
  targetProgram: string
  currentGpa: string
  currentSemester: number
  targetSemester: number
  academicYear: string
  reasonForTransfer?: string
}

export const applicationsApi = {
  getAll: () =>
    apiClient.get<ApiResponse<Application[]>>('/applications'),

  getById: (id: string) =>
    apiClient.get<ApiResponse<Application>>(`/applications/${id}`),

  create: (data: CreateApplicationRequest) =>
    apiClient.post<ApiResponse<Application>>('/applications', data),

  update: (id: string, data: Partial<CreateApplicationRequest>) =>
    apiClient.patch<ApiResponse<Application>>(`/applications/${id}`, data),

  submit: (id: string) =>
    apiClient.post<ApiResponse<Application>>(`/applications/${id}/submit`),

  withdraw: (id: string) =>
    apiClient.post<ApiResponse<Application>>(`/applications/${id}/withdraw`),
}
