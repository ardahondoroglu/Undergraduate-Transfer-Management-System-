import { apiClient } from './client'
import type { ApiResponse, User } from '@/types'

export interface LoginRequest {
  studentId: string
  password: string
}

export interface LoginResponse {
  user: User
  token: string
}

export interface RegisterRequest {
  firstName: string
  lastName: string
  email: string
  studentNumber: string
  password: string
}

export interface ForgotPasswordRequest {
  email: string
}

export interface ResetPasswordRequest {
  token: string
  newPassword: string
}

export const authApi = {
  login: (data: LoginRequest) =>
    apiClient.post<ApiResponse<LoginResponse>>('/auth/login', data),

  register: (data: RegisterRequest) =>
    apiClient.post<ApiResponse<{ message: string }>>('/auth/register', data),

  verifyEmail: (token: string) =>
    apiClient.get<ApiResponse<{ message: string }>>(`/auth/verify-email?token=${token}`),

  forgotPassword: (data: ForgotPasswordRequest) =>
    apiClient.post<ApiResponse<{ message: string }>>('/auth/forgot-password', data),

  resetPassword: (data: ResetPasswordRequest) =>
    apiClient.post<ApiResponse<{ message: string }>>('/auth/reset-password', data),

  getMe: () =>
    apiClient.get<ApiResponse<User>>('/auth/me'),

  logout: () =>
    apiClient.post<ApiResponse<null>>('/auth/logout'),
}
