import { apiClient } from './client'
import type { ApiResponse } from '@/types'
import type { StaffApplication } from './staff'

export type EquivalencyStatus = 'EQUIVALENT' | 'PARTIALLY_EQUIVALENT' | 'NOT_EQUIVALENT'

export interface CourseEquivalency {
  id: string
  applicationId: string
  createdBy: string
  previousCourseCode: string
  previousCourseName: string
  previousCourseCredits: string
  targetCourseCode: string
  targetCourseName: string
  targetCourseCredits: string
  status: EquivalencyStatus
  notes?: string
  createdAt: string
  updatedAt: string
}

export interface RankedApplication {
  id: string
  transferType: string
  targetProgram: string
  currentGpa: string
  currentSemester: number
  academicYear: string
  status: string
  evaluationScore?: string | null
  rankingPosition?: number | null
  rankingJustification?: string | null
  applicantFirstName: string
  applicantLastName: string
  applicantStudentId: string
}

export const ygkApi = {
  // Applications
  getApplications: (status?: string) =>
    apiClient.get<ApiResponse<StaffApplication[]>>('/ygk/applications', {
      params: status ? { status } : undefined,
    }),

  getApplication: (id: string) =>
    apiClient.get<ApiResponse<StaffApplication>>(`/ygk/applications/${id}`),

  updateStatus: (id: string, status: string, note?: string, evaluationScore?: number, evaluationNotes?: string) =>
    apiClient.patch<ApiResponse<{ status: string }>>(`/ygk/applications/${id}/status`, {
      status, note, evaluationScore, evaluationNotes,
    }),

  // Course equivalencies
  getEquivalencies: (appId: string) =>
    apiClient.get<ApiResponse<CourseEquivalency[]>>(`/ygk/applications/${appId}/equivalencies`),

  createEquivalency: (appId: string, data: Omit<CourseEquivalency, 'id' | 'applicationId' | 'createdBy' | 'createdAt' | 'updatedAt'>) =>
    apiClient.post<ApiResponse<CourseEquivalency>>(`/ygk/applications/${appId}/equivalencies`, data),

  updateEquivalency: (eqId: string, data: Partial<CourseEquivalency>) =>
    apiClient.patch<ApiResponse<CourseEquivalency>>(`/ygk/equivalencies/${eqId}`, data),

  deleteEquivalency: (eqId: string) =>
    apiClient.delete<ApiResponse<void>>(`/ygk/equivalencies/${eqId}`),

  // Ranking
  getRanking: () =>
    apiClient.get<ApiResponse<RankedApplication[]>>('/ygk/ranking'),

  updateRanking: (appId: string, rankingPosition: number, rankingJustification?: string) =>
    apiClient.patch<ApiResponse<RankedApplication>>(`/ygk/applications/${appId}/ranking`, {
      rankingPosition, rankingJustification,
    }),
}
