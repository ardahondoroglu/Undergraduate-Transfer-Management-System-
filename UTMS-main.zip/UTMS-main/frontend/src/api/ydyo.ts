import { apiClient } from './client'
import type { ApiResponse } from '@/types'
import type { StaffApplication } from './staff'

export type LanguageStatus = 'NOT_CHECKED' | 'APPROVED' | 'EXAM_REQUIRED' | 'NOT_MET'

export const ydyoApi = {
  getApplications: () =>
    apiClient.get<ApiResponse<StaffApplication[]>>('/ydyo/applications'),

  getApplication: (id: string) =>
    apiClient.get<ApiResponse<StaffApplication>>(`/ydyo/applications/${id}`),

  // SFL.02 — evaluate (APPROVED / EXAM_REQUIRED / NOT_MET)
  evaluate: (id: string, languageStatus: LanguageStatus, notes?: string) =>
    apiClient.patch<ApiResponse<StaffApplication>>(`/ydyo/applications/${id}/evaluate`, {
      languageStatus,
      notes,
    }),

  // SFL.03 — record exam result
  recordExamResult: (id: string, passed: boolean, score?: number, notes?: string) =>
    apiClient.patch<ApiResponse<StaffApplication>>(`/ydyo/applications/${id}/exam-result`, {
      passed,
      score,
      notes,
    }),
}
