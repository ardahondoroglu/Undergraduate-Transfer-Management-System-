import { apiClient } from './client'
import type { ApiResponse } from '@/types'
import type { StaffApplication } from './staff'

export const facultyApi = {
  getApplications: (status?: string) =>
    apiClient.get<ApiResponse<StaffApplication[]>>('/faculty/applications', {
      params: status ? { status } : undefined,
    }),

  getApplication: (id: string) =>
    apiClient.get<ApiResponse<StaffApplication>>(`/faculty/applications/${id}`),

  // FB.2 — approve or reject
  updateStatus: (id: string, status: 'APPROVED' | 'REJECTED', note?: string) =>
    apiClient.patch<ApiResponse<StaffApplication>>(`/faculty/applications/${id}/status`, {
      status, note,
    }),
}
