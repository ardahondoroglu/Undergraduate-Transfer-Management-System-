import { apiClient } from './client'
import type { ApiResponse } from '@/types'

export interface StaffApplication {
  id: string
  applicantId: string
  transferType: string
  previousUniversity: string
  currentProgram: string
  targetProgram: string
  currentGpa: string
  currentSemester: number
  targetSemester: number
  academicYear: string
  reasonForTransfer?: string
  status: string
  isEligible?: boolean
  submittedAt?: string
  createdAt: string
  updatedAt: string
  applicantFirstName: string
  applicantLastName: string
  applicantEmail: string
  applicantStudentId: string
}

export interface StaffDocument {
  id: string
  applicationId: string
  uploadedBy: string
  type: string
  fileName: string
  filePath: string
  fileSize: number
  mimeType: string
  status: 'PENDING' | 'VERIFIED' | 'REJECTED'
  rejectionReason?: string
  verifiedBy?: string
  verifiedAt?: string
  uploadedAt: string
}

export const staffApi = {
  // RV.1
  getApplications: (status?: string) =>
    apiClient.get<ApiResponse<StaffApplication[]>>('/staff/applications', {
      params: status ? { status } : undefined,
    }),

  getApplication: (id: string) =>
    apiClient.get<ApiResponse<StaffApplication>>(`/staff/applications/${id}`),

  updateStatus: (id: string, status: string, note?: string) =>
    apiClient.patch<ApiResponse<StaffApplication>>(`/staff/applications/${id}/status`, { status, note }),

  // VD.1
  getDocuments: (applicationId: string) =>
    apiClient.get<ApiResponse<StaffDocument[]>>(`/staff/applications/${applicationId}/documents`),

  verifyDocument: (docId: string) =>
    apiClient.patch<ApiResponse<StaffDocument>>(`/staff/documents/${docId}/verify`),

  rejectDocument: (docId: string, reason: string) =>
    apiClient.patch<ApiResponse<StaffDocument>>(`/staff/documents/${docId}/reject`, { reason }),

  getDownloadUrl: (docId: string) =>
    `${apiClient.defaults.baseURL}/staff/documents/${docId}/download`,
}
