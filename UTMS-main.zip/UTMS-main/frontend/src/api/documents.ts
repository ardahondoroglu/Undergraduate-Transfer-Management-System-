import { apiClient } from './client'
import type { ApiResponse, Document, DocumentType } from '@/types'

export const documentsApi = {
  upload: (applicationId: string, file: File, type: DocumentType) => {
    const form = new FormData()
    form.append('file', file)
    form.append('type', type)
    return apiClient.post<ApiResponse<Document>>(
      `/applications/${applicationId}/documents`, form,
      { headers: { 'Content-Type': 'multipart/form-data' } }
    )
  },

  getByApplication: (applicationId: string) =>
    apiClient.get<ApiResponse<Document[]>>(`/applications/${applicationId}/documents`),

  delete: (documentId: string) =>
    apiClient.delete<ApiResponse<{ message: string }>>(`/documents/${documentId}`),

  getDownloadUrl: (documentId: string) =>
    `${apiClient.defaults.baseURL}/documents/${documentId}/download`,
}
